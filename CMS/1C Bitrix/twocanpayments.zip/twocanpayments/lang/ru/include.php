<?
$MESS['BUTTON_CONFIRM_PAYMENT'] ='Подтвердить списание средств';
$MESS['BUTTON_CHECK_PAYMENT'] ='Проверить оплату';
$MESS['BUTTON_PAYMENT_ACTIONS'] ='2Can.ru';
$MESS['BUTTON_PAYMENT_ACTIONS_TITLE'] ='Действия с платежами';

$MESS['WINDOW_CHECK_TITLE'] ='Проверка статуса оплаты';
$MESS['WINDOW_CONFIRM_TITLE'] ='Подтверждение оплаты';
$MESS['BUTTON_REFRESH'] ='Обновить страницу';

?>