<?
$MESS['TWOCAN_MODULE_NAME'] = "Payment system 2Can.ru";
$MESS['TWOCAN_MODULE_DESC'] = "Integration with payment system 2Can.ru";
$MESS['TWOCAN_PARTNER_NAME'] = '2Can';
$MESS["TWOCAN_PARTNER_URI"] = 'https://2Can.ru/';
$MESS['UV_INSTALL_TITLE'] = "Module installation";
$MESS['UV_UNINSTALL_TITLE'] = "Module deinstallation";
$MESS['TWOCAN_HOLD_STATUS']='2Can: Принят, ожидается подтверждение оплаты';
$MESS['TWOCAN_CONFIRMED_STATUS']='2Can: Принят, оплата подтверждена';
$MESS['TWOCAN_PAID_STATUS']='2Can: Принят, оплата получена';
$MESS['TWOCAN_REFUND_STATUS']='2Can: Произведен возврат';


?>
