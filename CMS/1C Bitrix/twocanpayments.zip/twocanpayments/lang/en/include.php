<?
$MESS['BUTTON_CONFIRM_PAYMENT'] ='Charge payment';
$MESS['BUTTON_CHECK_PAYMENT'] ='Check payment';
$MESS['BUTTON_PAYMENT_ACTIONS'] ='2Can.ru';
$MESS['BUTTON_PAYMENT_ACTIONS_TITLE'] ='Payment actions';

$MESS['WINDOW_CHECK_TITLE'] ='Payment status';
$MESS['WINDOW_CONFIRM_TITLE'] ='Payment confirmation';
$MESS['BUTTON_REFRESH'] ='Reload page';

?>