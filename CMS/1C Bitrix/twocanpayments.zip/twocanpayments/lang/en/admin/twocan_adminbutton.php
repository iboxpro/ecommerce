<?
$MESS['SUMMA_TXT1'] = 'Order sum: ';

$MESS['PAY_OK1'] ='Payment confirmed!';

?>