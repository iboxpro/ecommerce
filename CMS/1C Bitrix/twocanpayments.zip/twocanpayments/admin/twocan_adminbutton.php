<?

require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');

if (!CModule::IncludeModule("main")) return;
\Bitrix\Main\Loader::includeModule('sale');
 
 
$order=\Bitrix\Sale\Order::load($_REQUEST['id']);
$propertyCollection = $order->getPropertyCollection();
$paymentCollection = $order->getPaymentCollection();
$ps = false;
$PAY_VOUCHER_NUM = "";
$psBusValues = null;
$SALE_HPS_2CAN_AUTOCHARGE = false;
$mypayment = null;
foreach ($paymentCollection as $payment) {

  if($payment->getPaySystem()->getField("ACTION_FILE") == 'twocan'){
    $ps = $payment->getPaySystem();
    $PAY_VOUCHER_NUM = $payment->getField('PS_INVOICE_ID');
    $psBusValues = $ps->getParamsBusValue($payment);
    $SALE_HPS_2CAN_AUTOCHARGE = ($psBusValues['SALE_HPS_2CAN_AUTOCHARGE'] == "Y")?true:false;
    $mypayment = &$payment;

  }
}

if ($_GET['type'])
{
     switch($_GET['type'])
     {                        
             case 'pay_ok':
                    $initResult = $ps->confirm($mypayment);
                    $psData = $initResult->getPsData();
                    if ($psData)
                    {
                      $setResult = $mypayment->setFields($psData);
                      if ($setResult->isSuccess())
                      {
                        /** @var \Bitrix\Sale\PaymentCollection $paymentCollection */
                        $paymentCollection = $mypayment->getCollection();
                        if ($paymentCollection)
                        {
                          $order = $paymentCollection->getOrder();

                          if ($order)
                          {
                            $saveResult = $order->save();
                            if (!$saveResult->isSuccess())
                              $initResult->addErrors($saveResult->getErrors());
                          }
                        }
                      }
                      else
                      {
                        $initResult->addErrors($setResult->getErrors());
                      }
                    }

                    if (!$initResult->isSuccess())
                      \Bitrix\Sale\PaySystem\ErrorLog::add(array('ACTION' => 'confirm', 'MESSAGE' => $initResult->getErrorMessages()));

             break;
             case 'check':

                    $initResult = $ps->check($mypayment);
                    $psData = $initResult->getPsData();
                    if ($psData)
                    {
                      $setResult = $mypayment->setFields($psData);
                      if ($setResult->isSuccess())
                      {
                        /** @var \Bitrix\Sale\PaymentCollection $paymentCollection */
                        $paymentCollection = $mypayment->getCollection();
                        if ($paymentCollection)
                        {
                          $order = $paymentCollection->getOrder();

                          if ($order)
                          {
                            $saveResult = $order->save();
                            if (!$saveResult->isSuccess())
                              $initResult->addErrors($saveResult->getErrors());
                          }
                        }
                      }
                      else
                      {
                        $initResult->addErrors($setResult->getErrors());
                      }
                    }
                   

                    if (!$initResult->isSuccess()){
                      echo $initResult->getErrorMessages()[0];
                      \Bitrix\Sale\PaySystem\ErrorLog::add(array('ACTION' => 'check', 'MESSAGE' => $initResult->getErrorMessages()));
                    }

             break;
     }
}

?>
