<?php
$MESS["SALE_HPS_TWOCAN_REFUND_ERROR"] = "Во время выполнения возврата перевода возникла ошибка.";
$MESS["SALE_HPS_TWOCAN_REFUND_ERROR_INFO"] = "Тип ошибки: #FAILURETYPE#. Сообщение: #ERROR#";
$MESS["SALE_HPS_TWOCAN_REFUND_CONNECTION_ERROR"] = "Ошибка подключения. URL: #URL#. HTTP код: #CODE#. Ошибка: #ERROR#";

$MESS["SALE_HPS_TWOCAN_CONFIRM_ERROR"] = "Во время выполнения подтверждения оплаты возникла ошибка.";
$MESS["SALE_HPS_TWOCAN_CONFIRM_ERROR_INFO"] = "<strong>Тип ошибки:</strong> #FAILURETYPE# <br><strong>Сообщение:</strong> #ERROR#";

$MESS["SALE_HPS_TWOCAN_CONFIRMED"] = "Платеж подтвержден успешно.";
$MESS["SALE_HPS_TWOCAN_CONFIRMED_INFO"] = "#AMOUNT# успешно списаны.";

$MESS["SALE_HPS_TWOCAN_STATUS_AMOUNT"] = "Сумма платежа: #AMOUNT#<br>Из них списано: #CHARGED_AMOUNT#<br>Дата операции: #UPDATED#";




$MESS["SALE_HPS_TWOCAN_STATUS.charged"] = "Проведено успешное списание средств";
$MESS["SALE_HPS_TWOCAN_STATUS.prepared"] = "Ожидаются действия извне";
$MESS["SALE_HPS_TWOCAN_STATUS.processing"] = "Выполняется обработка заказа";
$MESS["SALE_HPS_TWOCAN_STATUS.new"] = "Заказ создан, но обработка еще не началась";

$MESS["SALE_HPS_TWOCAN_STATUS.authorized"] = "Проведена успешная авторизация.";
$MESS["SALE_HPS_TWOCAN_STATUS.reversed"] = "Проведено успешное аннулирование";
$MESS["SALE_HPS_TWOCAN_STATUS.refunded"] = "Проведен успешный возврат средств";
$MESS["SALE_HPS_TWOCAN_STATUS.rejected"] = "Заказ был отклонен системой";
$MESS["SALE_HPS_TWOCAN_STATUS.fraud"] = "Заказ был определен как фродный и отклонен системой";
$MESS["SALE_HPS_TWOCAN_STATUS.declined"] = "Заказ был отклонен банком-эквайером";
$MESS["SALE_HPS_TWOCAN_STATUS.chargedback"] = "Заказ был отмечен как чарджбек";
$MESS["SALE_HPS_TWOCAN_STATUS.error"] = "В процессе выполнения произошла ошибка, возможно,требуется вмешательство службы поддержки";

$MESS["SALE_HPS_TWOCAN_SUCCESS"] = "Платеж по заказу №#ORDER_ID#, на сумму #AMOUNT# <b>успешно принят</b>.";
$MESS["SALE_HPS_TWOCAN_RESPONSE"] = "Ответ платежной системы: #RESPONSE#";
$MESS["SALE_HPS_TWOCAN_FAIL"] = "Платеж по заказу №#ORDER_ID# <b>отклонен</b>.<br>Причина: #REASON#";
$MESS["SALE_HPS_TWOCAN_BACKURL"] = "<a href='#URL#'>Перейти на страницу заказа</a>";

$MESS["SALE_HPS_TWOCAN_ORDER_CANCELED"] = "Операция невозможно, так как заказ был отменен.";







