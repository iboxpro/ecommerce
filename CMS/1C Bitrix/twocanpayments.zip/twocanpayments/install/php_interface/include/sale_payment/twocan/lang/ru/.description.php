<?
$MESS["SALE_HPS_2CAN_DTITLE"] = "Сервис iBox";

$MESS["SALE_HPS_2CAN_RETURN"] = "";
$MESS["SALE_HPS_2CAN_RESTRICTION"] = "";
$MESS["SALE_HPS_2CAN_COMMISSION"] = "";
$MESS["SALE_HPS_2CAN_CHECKOUT_REFERRER"] = "<a href=\"https://www.2can.ru/\" target=\"_blank\">2can.ru</a>";

$MESS["SALE_HPS_2CAN_DDESCR"] = "<a href=\"https://www.2can.ru\" target=\"_blank\">https://www.2can.ru</a>";
$MESS["SALE_HPS_2CAN_TERMINAL_ID"] = "Идентификатор терминала";
$MESS["SALE_HPS_2CAN_TERMINAL_ID_DESCR"] = "Идентификатор терминала, который получен от 2CAN";
$MESS["SALE_HPS_2CAN_LOGIN"] = "Имя пользователя";
$MESS["SALE_HPS_2CAN_LOGIN_DESCR"] = "Имя пользователя, который получен от 2CAN";
$MESS["SALE_HPS_2CAN_PASSWORD"] = "Пароль";
$MESS["SALE_HPS_2CAN_PASSWORD_DESCR"] = "Пароль, который получен от 2CAN";
$MESS["PAYMENT_CURRENCY"] = "Валюта заказа";
$MESS["ORDER_ID"] = "Номер заказа";
$MESS["ORDER_ID_DESCR"] = "Номер заказа в интернет магазине";
$MESS["SALE_HPS_2CAN_SHOULD_PAY"] = "Сумма заказа";
$MESS["SALE_HPS_2CAN_SHOULD_PAY_DESCR"] = "Сумма к оплате";
$MESS["SALE_HPS_2CAN_IS_TEST"] = "Тестовый режим";

$MESS["BUYER_PERSON_CUSTPROP_DESCR"] = "Можно привзяать данный параметр к свойствам заказа по их Коду";

$MESS["BUYER_PERSON_ADDRESS"] = "Адрес покупателя";
$MESS["BUYER_PERSON_CITY"] = "Город покупателя";
$MESS["BUYER_PERSON_COUNTRY"] = "Страна покупателя";
$MESS["BUYER_PERSON_NAME"] = "Имя покупателя";
$MESS["BUYER_PERSON_INDEX"] = "Почтовый индекс покупателя";
$MESS["BUYER_PERSON_EMAIL"] = "E-Mail покупателя";
$MESS["BUYER_PERSON_PHONE"] = "Телефон покупателя";


$MESS["SALE_HPS_2CAN_FORCE3DS"] = "Принудительно направлять на 3D Secure";


$MESS["SALE_HPS_2CAN_AUTOCHARGE"] = "Двух стадийный платеж";


$MESS['CONNECT_SETTINGS_2CAN'] = 'Настройки подключения 2CAN.ru';

$MESS["STATUS_GROUP"]="Статусы";
$MESS["STATUS_PAY"]="Статус оплачен";
$MESS["STATUS_REFUNDED"]="Статус возврата платежа";
$MESS["STATUS_AUTHORIZE"]="Статус подтверждения авторизации платежа (двухстадийные платежи)";
$MESS["STATUS_CONFIRM"]="Статус авторизованного платежа (двухстадийные платежи)";

$MESS["STATUS_CANCELED"]="Статус отмена авторизованного платежа (двухстадийные платежи)";