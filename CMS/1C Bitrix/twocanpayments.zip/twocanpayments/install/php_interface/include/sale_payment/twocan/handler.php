<?php

namespace Sale\Handlers\PaySystem;

use Bitrix\Main\Error;
use Bitrix\Main\Request;
use Bitrix\Main\Type\DateTime;
use Bitrix\Main\Localization\Loc;
use Bitrix\Sale\PaySystem;
use Bitrix\Sale\Payment;
use Bitrix\Sale\PriceMaths;
use Bitrix\Sale\Order;
use Bitrix\Main\Web\HttpClient; 
use Bitrix\Main\ArgumentException;
use Bitrix\Main\Type\ParameterDictionary;
use Bitrix\Main\Application;


Loc::loadMessages(__FILE__);

class TwocanHandler extends PaySystem\ServiceHandler implements PaySystem\IRefund, PaySystem\ICheckable, PaySystem\IHold
{

	public $psStatus = "";
	/**
	 * @param Payment $payment
	 * @param Request|null $request
	 * @return PaySystem\ServiceResult
	 */
	public function initiatePay(Payment $payment, Request $request = null)
	{


		$amount = $this->getBusinessValue($payment,"PAYMENT_SHOULD_PAY");
		$amount = number_format($amount, 2, '.', '');
		$location ='/bitrix/tools/sale_ps_twocan_redirect.php?payment_id='.$payment->getId(). '&order_id='. $this->getBusinessValue($payment,"ORDER_ID");
		$params = array(

			'url' => $location,
			//'response' => $response,
			'amount' => $amount
			
		);

		$this->setExtraParams($params);

		return $this->showTemplate($payment, "template");
	}

	

	/**
	 * @return array
	 */
	public static function getIndicativeFields()
	{
		return array('HPS_HANDLER' => 'TWOCAN');
	}

	/**
	 * @param Request $request
	 * @param $paySystemId
	 * @return bool
	 */
	static protected function isMyResponseExtended(Request $request, $paySystemId)
	{

		return true;
	}

	/**
	 * @param Request $request
	 * @return mixed
	 */
	public function getPaymentIdFromRequest(Request $request)
	{
		return $request->get('paymentid');
	}

	/**
	 * @param Payment $payment
	 * @param Request $request
	 * @return PaySystem\ServiceResult
	 */
	public function processRequest(Payment $payment, Request $request)
	{	
		global $APPLICATION;
	  $result = new PaySystem\ServiceResult();
		$order = Order::load((int)$request->get("id"));
		$url =sprintf($this->getUrl($payment, 'status'), $payment->getField("PS_INVOICE_ID")); 

		$TerminlID = $this->getBusinessValue($payment, "PAYMENT_SHOULD_PAY");
		$TCANLogin = $this->getBusinessValue($payment, "SALE_HPS_2CAN_LOGIN");
		$TCANPass = $this->getBusinessValue($payment, "SALE_HPS_2CAN_PASSWORD");

		$TWOSTAGED = ($this->getBusinessValue($payment, "SALE_HPS_2CAN_AUTOCHARGE") == "Y")?0:1;

		$httpClient = new HttpClient(); 
		$httpClient->setAuthorization($TCANLogin, $TCANPass);
		$httpClient->disableSslVerification();
		$httpClient->setRedirect(false);
		$httpClient->setVersion("1.1");
		$httpClient->setHeader('Content-Type', 'application/json', true);
		$response = $httpClient->get($url);
		
		if($response === false)
		{
			
			$result->addErrors($request->getError());
			return $result;
		}

		$responseData = json_decode($response, true);

		if (isset($responseData['orders']))
		{	
			

			$psData = $this->parsePaymentAnswer($responseData);
			
			if($psData['PAID'] == "Y"){
				$result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);
			}else{
				$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);
			}
			$status_auth = $this->getBusinessValue($payment, $this->mapStatus($this->psStatus, $TWOSTAGED));
			if($status_auth){
				$order->setField("STATUS_ID", $status_auth);
				$order->save();
			}
	
		}
		else
		{
			
			$psData = array(
				"PS_STATUS" => 'N',
				"PS_STATUS_CODE" => $responseData['failure_type'],
				"PS_STATUS_MESSAGE" => $responseData['failure_message'],
				"PS_RESPONSE_DATE" => new DateTime()
			);
		}
		$result->setPsData($psData);
		return $result;
	}

	private function mapStatus($status, $twostage = true)
	{	
		switch ($status) {
			case 'authorized':
					return 'STATUS_AUTHORIZE';
				break;
			case 'charged':
					return $twostage?'STATUS_PAY':'STATUS_CONFIRM';
				break;
			case 'refunded':
					return 'STATUS_REFUNDED';
				break;
			case 'reversed':
			case 'canceled':
					return 'STATUS_CANCELED';
				break;
			default:
				# code...
				break;
		}
	}


	/**
	 * @param Payment $payment
	 * @return bool
	 */
	protected function isTestMode(Payment $payment = null)
	{
		return ($this->getBusinessValue($payment, 'SALE_HPS_2CAN_IS_TEST') == 'Y');
	}

	/**
	 * @return array
	 */
	public function getCurrencyList()
	{
		return array('RUB');
	}

	/**
	 * @param PaySystem\ServiceResult $result
	 * @param Request $request
	 * @return mixed
	 */
	public function sendResponse(PaySystem\ServiceResult $result, Request $request)
	{
		global $APPLICATION;
		$APPLICATION->RestartBuffer();

        define("STOP_STATISTICS", true);
		define('NO_AGENT_CHECK', true);
		define("DisableEventsCheck", true);

  
		$APPLICATION->SetTitle("Статус оплаты");
		$APPLICATION->AddChainItem("Персональный раздел", "/personal/");
		$APPLICATION->AddChainItem("Заказы");
		$psData = $result->getPsData();
		if ($result->isResultApplied())
		{
			
			
			if($psData['PS_STATUS'] == "Y"){
				echo '<p>'.Loc::getMessage('SALE_HPS_TWOCAN_SUCCESS', array('#ORDER_ID#' => $request->get('id'), '#AMOUNT#' => $psData['PS_SUM'])).'</p>';

				
			}else{
				echo '<p>'.Loc::getMessage('SALE_HPS_TWOCAN_FAIL', array('#ORDER_ID#' => $request->get('id'), '#REASON#' => $psData['PS_STATUS_MESSAGE'])).'</p>';
			}

			
		}else{

			echo '<p>'.Loc::getMessage('SALE_HPS_TWOCAN_FAIL', array('#ORDER_ID#' => $request->get('id'), '#REASON#' => $psData['PS_STATUS_MESSAGE'])).'</p>';
		}
		echo '<p>'.Loc::getMessage('SALE_HPS_TWOCAN_RESPONSE', array('#RESPONSE#' => $psData['PS_STATUS_DESCRIPTION'])).'</p>';
		echo '<p>'.Loc::getMessage('SALE_HPS_TWOCAN_BACKURL', array('#URL#' => "/personal/order/detail/".$request->get('id').'/')).'</p>';
		
	}


	/**
	 * @return mixed
	 */
	protected function getUrlList()
	{
		$hostTest = ".ecom-sandbox.2can.ru";
		$hostProd  = "api-ecom.2can.ru";
		return array(
			'pay' => array(
				self::TEST_URL => 'https://checkout' . $hostTest . '/pay/%d',
				self::ACTIVE_URL => 'https://checkout' . $hostProd . '/pay/%d'
			),
			'charge' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/charge',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/%d/charge'
			),
			'cancel' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/cancel',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/%d/cancel'
			),
			'reverse' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/reverse',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/%d/reverse'
			),
			'refund' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/refund',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/%d/refund',
			),
			'create' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/create',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/create',
			),
			'status' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d',
				self::TEST_URL => 'https://api' . $hostTest . '/orders/%d',
			),
		);
	}


	/**
	 * @param Payment $payment
	 * @param int $refundableSum
	 * @return PaySystem\ServiceResult
	 */
	public function refund(Payment $payment, $refundableSum)
	{
		$result = new PaySystem\ServiceResult();
		$error = '';
		$order = Order::load((int)$payment->getOrderId());
		$url = sprintf($this->getUrl($payment, 'refund'), $payment->getField("PS_INVOICE_ID"));

		$post = [
			'amount' => $refundableSum
		];

		$TCANLogin = $this->getBusinessValue($payment,"SALE_HPS_2CAN_LOGIN");
		$TCANPass = $this->getBusinessValue($payment,"SALE_HPS_2CAN_PASSWORD");
		$httpClient = new HttpClient(); 
		$httpClient->setAuthorization($TCANLogin, $TCANPass);
		$httpClient->disableSslVerification();
		$httpClient->setRedirect(false);
		$httpClient->setVersion("1.1");
		$httpClient->setHeader('Content-Type', 'application/json', true);
		$qstatus = $httpClient->query("PUT", $url, json_encode($post));

		$httpCode = $httpClient->getStatus();

		if($qstatus){	

			$responseData = json_decode($httpClient->getResult(), true);		
			
			if(in_array($httpCode, [200, 201])){
	
				$psData = $this->parsePaymentAnswer($responseData);

				if($psData['PAID'] == "Y"){
					$result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);
				}else{
					$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);
				}		
				
				
				$result->setPsData($psData);


				$chstatus = $this->getBusinessValue($payment, $this->mapStatus($this->psStatus));
				if($chstatus){
					$order->setField("STATUS_ID", $chstatus);
					$order->save();
				}

				
				
			}else{
				

				$error .= Loc::getMessage('SALE_HPS_TWOCAN_REFUND_ERROR').' '.Loc::getMessage('SALE_HPS_TWOCAN_REFUND_ERROR_INFO', array('#FAILURETYPE#' => $responseData['failure_type'], '#ERROR#' =>  $responseData['failure_message']));
			}
		}else{
			$error .= Loc::getMessage('SALE_HPS_TWOCAN_REFUND_CONNECTION_ERROR', array('#URL#' => $url, '#ERROR#' => $curlError, '#CODE#' => $httpCode));
		}

		if ($error !== '')
		{
			$result->addError(new Error($error));
			PaySystem\ErrorLog::add(array(
				'ACTION' => 'returnPaymentRequest',
				'MESSAGE' => join("\n", $result->getErrorMessages())
			));
		}

		return $result;
	}

	public function confirm(Payment $payment)
	{
		global $APPLICATION;
		$result = new PaySystem\ServiceResult();
		$error = "";
		$order = Order::load((int)$payment->getOrderId());
		if(!$order->isCanceled()){
			$url =sprintf($this->getUrl($payment, 'charge'), $payment->getField("PS_INVOICE_ID")); 
			if((float)$order->getField('SUM_PAID') < (float)$payment->getSum()){
				$toPay = $order->getField('SUM_PAID');
			}else{
				$toPay = $payment->getSum();
			}

			$post = [
				 'amount' => sprintf('%0.2f', $toPay)
			];

			$TCANLogin = $this->getBusinessValue($payment,"SALE_HPS_2CAN_LOGIN");
			$TCANPass = $this->getBusinessValue($payment,"SALE_HPS_2CAN_PASSWORD");
			$httpClient = new HttpClient(); 
			$httpClient->setAuthorization($TCANLogin, $TCANPass);
			$httpClient->disableSslVerification();
			$httpClient->setRedirect(false);
			$httpClient->setVersion("1.1");
			$httpClient->setHeader('Content-Type', 'application/json', true);
			$qstatus = $httpClient->query("PUT", $url, json_encode($post));
			$responseData = json_decode($httpClient->getResult(), true);

			if (isset($responseData['orders']))
			{	
				
				$psData = $this->parsePaymentAnswer($responseData);

				if($psData['PAID'] == "Y"){
					$result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);
				}else{
					$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);
				}
				$chstatus = $this->getBusinessValue($payment, $this->mapStatus($this->psStatus));
				if($this->psStatus == "charged" && $chstatus){
					$order->setField("STATUS_ID", $chstatus);
					$order->save();
				}
				$error .= Loc::getMessage('SALE_HPS_TWOCAN_CONFIRMED');
				$error .= '<br><br>'.Loc::getMessage('SALE_HPS_TWOCAN_STATUS_AMOUNT', ['#CHARGED_AMOUNT#' => $responseData['orders'][0]['amount_charged'],'#AMOUNT#' => $responseData['orders'][0]['amount'], '#UPDATED#' =>$responseData['orders'][0]['updated']]);
			}
			else
			{
				$error .= Loc::getMessage('SALE_HPS_TWOCAN_CONFIRM_ERROR').'<br><br>'.Loc::getMessage('SALE_HPS_TWOCAN_CONFIRM_ERROR_INFO', array('#FAILURETYPE#' => $responseData['failure_type'], '#ERROR#' =>  $responseData['failure_message']));
				$psData = array(
					"PS_STATUS" => 'N',
					"PS_STATUS_CODE" => $responseData['failure_type'],
					"PS_STATUS_DESCRIPTION" => "",
					"PS_STATUS_MESSAGE" => $responseData['failure_message'],
					"PS_SUM" => 0,
					"PS_CURRENCY" => $this->getBusinessValue($payment, "PAYMENT_CURRENCY"),
					"PS_RESPONSE_DATE" => new DateTime(),
				);

			}
			$result->setPsData($psData);
		}else{
			$error .= Loc::getMessage('SALE_PS_SERVICE_ORDER_CANCELED', array('#ORDER_ID#' => $order->getId()));
		}

		if ($error !== '')
		{
			echo $error;
			$result->addError(new Error($error));
			PaySystem\ErrorLog::add(array(
				'ACTION' => 'checkPayment',
				'MESSAGE' => join("\n", $result->getErrorMessages())
			));
		}

		return $result;
	}

	/**
	 * @param Payment $payment
	 * @return PaySystem\ServiceResult
	 */
	public function cancel(Payment $payment)
	{
		$result = new PaySystem\ServiceResult();
		$error = '';
		$order = Order::load((int)$payment->getOrderId());
		

		$post = [];
		$authStatus = $this->check($payment, true)->psStatus;

		$url = sprintf($this->getUrl($payment, ($authStatus == "authorized")?'reverse':'cancel'), $payment->getField("PS_INVOICE_ID"));

		$TCANLogin = $this->getBusinessValue($payment,"SALE_HPS_2CAN_LOGIN");
		$TCANPass = $this->getBusinessValue($payment,"SALE_HPS_2CAN_PASSWORD");
		$httpClient = new HttpClient(); 
		$httpClient->setAuthorization($TCANLogin, $TCANPass);
		$httpClient->disableSslVerification();
		$httpClient->setRedirect(false);
		$httpClient->setVersion("1.1");
		$httpClient->setHeader('Content-Type', 'application/json', true);
		$qstatus = $httpClient->query("PUT", $url, "");

		$httpCode = $httpClient->getStatus();

		if($qstatus){			

			if(in_array($httpCode, ["200", "201"])){

				$response = json_decode($httpClient->getResult(), true);

				$psData = $this->parsePaymentAnswer($response);
				
				if(in_array($this->psStatus, ['refunded', 'reversed'])){

					$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);

					$chstatus = $this->getBusinessValue($payment, $this->mapStatus($this->psStatus));
					if($chstatus){
						$order->setField("STATUS_ID", $chstatus);
						$order->save();
					}

				}

				$result->setPsData($psData);
			}else{

				$response = json_decode($httpClient->getResult());

				$error .= Loc::getMessage('SALE_HPS_TWOCAN_REFUND_ERROR').' '.Loc::getMessage('SALE_HPS_TWOCAN_REFUND_ERROR_INFO', array('#FAILURETYPE#' => $response->failure_type, '#ERROR#' =>  $response->failure_message));
			}
		}else{
			$error .= Loc::getMessage('SALE_HPS_TWOCAN_REFUND_CONNECTION_ERROR', array('#URL#' => $url, '#ERROR#' => $curlError, '#CODE#' => $httpCode));
		}

		if ($error !== '')
		{
			$result->addError(new Error($error));
			PaySystem\ErrorLog::add(array(
				'ACTION' => 'cancelPayment',
				'MESSAGE' => join("\n", $result->getErrorMessages())
			));
		}

		return $result;

	}

	
	public function check(Payment $payment, $silent = false)
	{
		 \Bitrix\Main\Config\Option::set("sale", "allow_pay_status", 'N');
		
		$result = new PaySystem\ServiceResult();
		$url =sprintf($this->getUrl($payment, 'status'), $payment->getField("PS_INVOICE_ID")); 
		$order = Order::load((int)$payment->getOrderId());

		if(!$order->isCanceled()){
			$TerminlID = $this->getBusinessValue($payment, "PAYMENT_SHOULD_PAY");
			$TCANLogin = $this->getBusinessValue($payment, "SALE_HPS_2CAN_LOGIN");
			$TCANPass = $this->getBusinessValue($payment, "SALE_HPS_2CAN_PASSWORD");

			$httpClient = new HttpClient(); 
			$httpClient->setAuthorization($TCANLogin, $TCANPass);
			$httpClient->disableSslVerification();
			$httpClient->setRedirect(false);
			$httpClient->setVersion("1.1");
			$httpClient->setHeader('Content-Type', 'application/json', true);
			$response = $httpClient->get($url);
			
			if($response === false)
			{
				$result->addErrors($request->getError());
				return $result;
			}

			$responseData = json_decode($response, true);

			if (isset($responseData['orders']))
			{	

				$psData = $this->parsePaymentAnswer($responseData);

				if($psData['PAID'] == "Y"){
					$result->setOperationType(PaySystem\ServiceResult::MONEY_COMING);
				}else{
					$result->setOperationType(PaySystem\ServiceResult::MONEY_LEAVING);
				}

				$chstatus = $this->getBusinessValue($payment, $this->mapStatus($this->psStatus));
				if($chstatus){
					$order->setField("STATUS_ID", $chstatus);
					$order->save();
				}

			}
			else
			{
				
				$psData = array(
					"PS_STATUS" => 'N',
					"PS_STATUS_CODE" => $responseData['failure_type'],
					"PS_STATUS_MESSAGE" => $responseData['failure_message'],
					"PS_RESPONSE_DATE" => new DateTime()
				);
			}
			$error .= Loc::getMessage('SALE_HPS_TWOCAN_STATUS.'.$responseData['orders'][0]['status']);
			if($responseData['orders'][0]['status'] == 'charged' && !$silent) echo '<br><br>'.Loc::getMessage('SALE_HPS_TWOCAN_STATUS_AMOUNT', ['#CHARGED_AMOUNT#' => $responseData['orders'][0]['amount_charged'],'#AMOUNT#' => $responseData['orders'][0]['amount'], '#UPDATED#' =>$responseData['orders'][0]['updated']]);

			
			$result->setPsData($psData);
		}else{
			$error .= Loc::getMessage('SALE_HPS_TWOCAN_ORDER_CANCELED');
		}

		if ($error !== '')
		{
			if(!$silent) echo $error;
			$result->addError(new Error($error));
			PaySystem\ErrorLog::add(array(
				'ACTION' => 'checkPayment',
				'MESSAGE' => join("\n", $result->getErrorMessages())
			));
		}

		return $result;

	}

	private function parsePaymentAnswer($responseData){
		$this->psStatus = $responseData['orders'][0]['status'];
		switch ($responseData['orders'][0]['status']) {
			case 'refunded':
					$amount = $responseData['orders'][0]['amount_refunded'];
				break;
			case 'charged':
					$amount = $responseData['orders'][0]['amount_charged'];
				break;			
			default:
					$amount = $responseData['orders'][0]['amount'];
				break;
		}
		$psData = array(
			"PS_STATUS" => (in_array($responseData['orders'][0]['status'], ['refunded', 'chargedback','reversed','authorized','charged','new','processing', 'prepared']))?'Y':'N',
			"PS_RESPONSE_DATE" => new DateTime(),
			"PS_SUM" => $amount,
			"PS_CURRENCY" => $responseData['orders'][0]['currency'],
			"PS_STATUS_MESSAGE" => (isset($responseData['orders'][0]['failure_message'])?$responseData['orders'][0]['failure_message']:''),
			"PS_STATUS_DESCRIPTION" => Loc::getMessage('SALE_HPS_TWOCAN_STATUS.'.$responseData['orders'][0]['status']),
			"PS_STATUS_CODE" => $responseData['orders'][0]['status']

			
		);

		

		if(in_array($responseData['orders'][0]['status'], ['charged', 'authorized'])) {
			
			$psData["PAID"] = "Y";	

		}elseif(in_array($responseData['orders'][0]['status'], ['refunded', 'chargedback','reversed'])){
			
			$psData["PAID"] = "N";	

		}

		return $psData;
	}
	
}