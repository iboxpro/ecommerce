<?
use Bitrix\Main\Localization\Loc;

Loc::loadMessages(__FILE__);

$description = array(
	'RETURN' => Loc::getMessage('SALE_HPS_2CAN_RETURN'),
	'RESTRICTION' => Loc::getMessage('SALE_HPS_2CAN_RESTRICTION'),
	'COMMISSION' => Loc::getMessage('SALE_HPS_2CAN_COMMISSION'),
	'MAIN' => Loc::getMessage('SALE_HPS_2CAN_DESCRIPTION')
);


$data = array(
	'NAME' => Loc::getMessage('SALE_HPS_2CAN_DTITLE'),
	'SORT' => 500,
	'CODES' => array(
		"BUYER_PERSON_ADDRESS" => array(
				"NAME" => GetMessage("BUYER_PERSON_ADDRESS"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'ADDRESS',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_CITY" => array(
				"NAME" => GetMessage("BUYER_PERSON_CITY"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'CITY',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_COUNTRY" => array(
				"NAME" => GetMessage("BUYER_PERSON_COUNTRY"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'COUNTRY',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_NAME" => array(
				"NAME" => GetMessage("BUYER_PERSON_NAME"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'FIO',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_INDEX" => array(
				"NAME" => GetMessage("BUYER_PERSON_INDEX"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'ZIP',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_EMAIL" => array(
				"NAME" => GetMessage("BUYER_PERSON_EMAIL"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'EMAIL',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"BUYER_PERSON_PHONE" => array(
				"NAME" => GetMessage("BUYER_PERSON_PHONE"),
				"DESCR" => GetMessage("BUYER_PERSON_CUSTPROP_DESCR"),
				'SORT' => 1100,
				'GROUP' => 'BUYER_PERSON',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'PHONE',
					'PROVIDER_KEY' => 'PROPERTY'
				)
			),
		"ORDER_ID" => array(
				"NAME" => GetMessage("ORDER_ID"),
				"DESCR" => GetMessage("ORDER_ID_DESCR"),
				'GROUP' => 'PAYMENT',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'ID',
					'PROVIDER_KEY' => 'ORDER'
				)
			),
		"PAYMENT_SHOULD_PAY" => array(
				"NAME" => GetMessage("SALE_HPS_2CAN_SHOULD_PAY"),
				"DESCR" => GetMessage("SALE_HPS_2CAN_SHOULD_PAY_DESCR"),
				'GROUP' => 'PAYMENT',
				'DEFAULT' => array(
					'PROVIDER_VALUE' => 'SUM',
					'PROVIDER_KEY' => 'PAYMENT'
				)
			),
		"SALE_HPS_2CAN_IS_TEST" => array(
				'SORT' => 400,
				'GROUP' => 'GENERAL_SETTINGS',
				"INPUT" => array(
					'TYPE' => 'Y/N'
				),
				"NAME" => GetMessage("SALE_HPS_2CAN_IS_TEST"),
			),
		"SALE_HPS_2CAN_FORCE3DS" => array(
				'SORT' => 600,
				"NAME" => GetMessage("SALE_HPS_2CAN_FORCE3DS"),
				'GROUP' => 'GENERAL_SETTINGS',
				"INPUT" => array(
					'TYPE' => 'Y/N'
				),
			),
		"PAYMENT_CURRENCY" => array(
            "NAME" => GetMessage("PAYMENT_CURRENCY"),
            "DESCR" => GetMessage("PAYMENT_CURRENCY_DESC"),
            'SORT' => 900,
			'GROUP' => 'PAYMENT',
			'DEFAULT' => array(
				'PROVIDER_VALUE' => 'CURRENCY',
				'PROVIDER_KEY' => 'PAYMENT'
			)
         ),	
        "SALE_HPS_2CAN_AUTOCHARGE" => array(
        		'SORT' => 500,
				"NAME" => GetMessage("SALE_HPS_2CAN_AUTOCHARGE"),
				'GROUP' => 'GENERAL_SETTINGS',
				"INPUT" => array(
					'TYPE' => 'Y/N'
				),
			),	
		"SALE_HPS_2CAN_PASSWORD" => array(
				'SORT' => 200,
				"NAME" => GetMessage("SALE_HPS_2CAN_PASSWORD"),
				"DESCR" => GetMessage("SALE_HPS_2CAN_PASSWORD_DESCR"),
				'GROUP' => 'GENERAL_SETTINGS',
			),
		"SALE_HPS_2CAN_LOGIN" => array(
				'SORT' => 100,
				"NAME" => GetMessage("SALE_HPS_2CAN_LOGIN"),
				"DESCR" => GetMessage("SALE_HPS_2CAN_LOGIN_DESCR"),
				'GROUP' => 'GENERAL_SETTINGS',
			),
		"SALE_HPS_2CAN_TERMINAL_ID" => array(
				'SORT' => 300,	
				"NAME" => GetMessage("SALE_HPS_2CAN_TERMINAL_ID"),
				"DESCR" => GetMessage("SALE_HPS_2CAN_TERMINAL_ID_DESCR"),
				'GROUP' => 'GENERAL_SETTINGS',
			),
	)
);

if (CModule::IncludeModule("sale") && CModule::IncludeModule("catalog"))
{
	$db_dtype=CSaleStatus::GetList(array());
	while ($ar_dtype = $db_dtype->Fetch())
	{
	     $STATUS_ALL[$ar_dtype['ID']]=$ar_dtype['NAME'];
	}	
	$customStatus = ['PAY','AUTHORIZE', 'REFUNDED', 'CONFIRM', 'CANCELED'];
	foreach ($customStatus as $statusID) {
		$data['CODES']["STATUS_". $statusID]=array(
            "NAME" => Loc::getMessage("STATUS_".$statusID),
            'SORT' => 300,
            'GROUP' => Loc::getMessage("STATUS_GROUP"),
            "TYPE" => "SELECT",
            "INPUT"=>array(
                'TYPE'=>'ENUM',
                'OPTIONS'=>$STATUS_ALL
            )
        );
	}
}