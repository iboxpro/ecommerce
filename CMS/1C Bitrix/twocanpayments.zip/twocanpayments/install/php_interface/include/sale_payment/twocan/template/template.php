<?
	use Bitrix\Main\Localization\Loc;
	Loc::loadMessages(__FILE__);

?>
		Вы хотите оплатить через систему <b>2CAN.ru</b><br /><br />
		Сумма к оплате по счету: <b><?=$params['amount']?> р.</b><br />
		<br />
		<a class="sale-order-list-about-link" href="<?=$params['url']?>">Оплатить</a>
