<?
global $MESS;
$strPath2Lang = str_replace("\\", "/", __FILE__);
$strPath2Lang = substr($strPath2Lang, 0, strlen($strPath2Lang)-strlen("/install/index.php"));
include(GetLangFileName($strPath2Lang."/lang/", "/install/install.php"));

if(class_exists("twocanpayments")) return;

class twocanpayments extends CModule
{
	var $MODULE_ID = "twocanpayments";
	var $MODULE_VERSION;
	var $MODULE_VERSION_DATE;
	var $MODULE_NAME;
	var $MODULE_DESCRIPTION;
	var $MODULE_GROUP_RIGHTS = "Y";
	
	function twocanpayments()
	{
		$arModuleVersion = array();
		include(dirname(__FILE__)."/version.php");
		$this->MODULE_VERSION = $arModuleVersion["VERSION"];
		$this->MODULE_VERSION_DATE = $arModuleVersion["VERSION_DATE"];
		$this->MODULE_NAME = GetMessage("TWOCAN_MODULE_NAME");
		$this->MODULE_DESCRIPTION = GetMessage("TWOCAN_MODULE_DESC");
		$this->PARTNER_NAME = GetMessage("TWOCAN_PARTNER_NAME");
		$this->PARTNER_URI = GetMessage("TWOCAN_PARTNER_URI");
	}
  
	function DoInstall()
	{	
        global $DOCUMENT_ROOT, $APPLICATION;
		$this->InstallFiles();
		RegisterModule($this->MODULE_ID);
        $this->InstallEvents();
        $this->InstallOrderStatus();
        $APPLICATION->IncludeAdminFile("Установка модуля ".GetMessage("TWOCAN_MODULE_NAME"), $DOCUMENT_ROOT."/bitrix/modules/".$this->MODULE_ID."/install/step.php");
        
		return true;
	}

	function InstallDB()
	{
	
		return true;
	}

	function InstallFiles($arParams = array())
	{

    	CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/php_interface",  $_SERVER["DOCUMENT_ROOT"]."/bitrix/php_interface",true,true);
		CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/admin",  $_SERVER["DOCUMENT_ROOT"]."/bitrix/admin",true,true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/tools",  $_SERVER["DOCUMENT_ROOT"]."/bitrix/tools",true,true);
        CopyDirFiles($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/".$this->MODULE_ID."/install/images/sale/sale_payments/",  $_SERVER["DOCUMENT_ROOT"]."/bitrix/images/sale/sale_payments/",true,true);
        
		return true;
	}

    function InstallOrderStatus()
    {
        if (!CModule::IncludeModule("sale")) return false;
        $lang[]=array("LID"=>'ru',"NAME"=> GetMessage("TWOCAN_HOLD_STATUS"));
        $lang[]=array("LID"=>'en',"NAME"=>"2Can: Accepted, waiting for payment confirmation");
        
        $new_status = array(
                'ID' => 'TA',
                'SORT' => 900,
                'LANG' =>$lang,    
        );
        CSaleStatus::Add($new_status);
        unset($new_status);
        unset($lang);
        
        $lang[]=array("LID"=>'ru',"NAME"=>GetMessage("TWOCAN_CONFIRMED_STATUS"));
        $lang[]=array("LID"=>'en',"NAME"=>"2Can: Payment confirmed");
        
        $new_status = array(
                'ID' => 'TC',
                'SORT' => 910,
                'LANG' =>$lang,    
        );
        CSaleStatus::Add($new_status);
        unset($new_status);
        unset($lang);

        $lang[]=array("LID"=>'ru',"NAME"=>GetMessage("TWOCAN_PAID_STATUS"));
        $lang[]=array("LID"=>'en',"NAME"=>"2Can: Paid");
        
        $new_status = array(
                'ID' => 'TP',
                'SORT' => 920,
                'LANG' =>$lang,    
        );
        CSaleStatus::Add($new_status);
        unset($new_status);
        unset($lang);

        $lang[]=array("LID"=>'ru',"NAME"=>GetMessage("TWOCAN_REFUND_STATUS"));
        $lang[]=array("LID"=>'en',"NAME"=>"2Can: Payment refunded");
        
        $new_status = array(
                'ID' => 'TR',
                'SORT' => 930,
                'LANG' =>$lang,    
        );
        CSaleStatus::Add($new_status);
        unset($new_status);
        unset($lang);

        $lang[]=array("LID"=>'ru',"NAME"=>GetMessage("TWOCAN_CANCELED_STATUS"));
        $lang[]=array("LID"=>'en',"NAME"=>"2Can: Canceled");
        
        $new_status = array(
                'ID' => 'CA',
                'SORT' => 940,
                'LANG' =>$lang,    
        );
        CSaleStatus::Add($new_status);
        unset($new_status);
        unset($lang);

        
    }

    function UnInstallOrderStatus()
    {
        if (!CModule::IncludeModule("sale")) return false;
        CSaleStatus::Delete("TA");
        CSaleStatus::Delete("TC");
        CSaleStatus::Delete("TP");
        CSaleStatus::Delete("TR");

    }
	function UnInstallFiles()
	{
		DeleteDirFilesEx('/bitrix/php_interface/include/sale_payment/twocan');
		unlink($_SERVER["DOCUMENT_ROOT"]."/bitrix/admin/twocan_adminbutton.php");
        unlink($_SERVER["DOCUMENT_ROOT"]."/bitrix/tools/sale_ps_twocan_redirect.php");
        unlink($_SERVER["DOCUMENT_ROOT"]."/bitrix/images/sale/sale_payments/twocan.png");
		
		return true;
	}



  function InstallEvents()
  {
    
    $eventManager = \Bitrix\Main\EventManager::getInstance();
    $eventManager->registerEventHandler("main", "OnAdminContextMenuShow", $this->MODULE_ID, "TwocanHandler2", "OnAdminContextMenuShowHandler_button",9999);
    $eventManager->registerEventHandler("sale", "OnBeforeOrderDelete", $this->MODULE_ID, "TwocanHandler2", "OnTwocanOrderDelete",9999);
    
    $eventManager->registerEventHandler("sale", "OnSaleBeforeCancelOrder", $this->MODULE_ID, "TwocanHandler2", "OnTwocanOnSaleBeforeCancelOrder",9999);  
    $eventManager->registerEventHandler("sale", "OnBeforePaymentEntityDelete", $this->MODULE_ID, "TwocanHandler2", "OnTwocanPaymentDelete",9999);
    $eventManager->registerEventHandler("sale", "OnSalePaymentEntitySaved", $this->MODULE_ID, "TwocanHandler2", "OnTwocanPaymentSave",9999);
    
    return true;
  }

  function UnInstallEvents()
  {
    $eventManager = \Bitrix\Main\EventManager::getInstance();
    $eventManager->unRegisterEventHandler("main", "OnAdminContextMenuShow", $this->MODULE_ID, "TwocanHandler2", "OnAdminContextMenuShowHandler_button");
    $eventManager->unRegisterEventHandler("sale", "OnBeforeOrderDelete", $this->MODULE_ID, "TwocanHandler2", "OnTwocanOrderDelete");
    $eventManager->unRegisterEventHandler("sale", "OnSaleStatusOrder", $this->MODULE_ID, "TwocanHandler2", "OnTwocanStatusUpdate");    //
    $eventManager->unRegisterEventHandler("sale", "OnSaleBeforeCancelOrder", $this->MODULE_ID, "TwocanHandler2", "OnTwocanOnSaleBeforeCancelOrder");    //
    $eventManager->unRegisterEventHandler("sale", "OnBeforePaymentEntityDelete", $this->MODULE_ID, "TwocanHandler2", "OnTwocanPaymentDelete");
    $eventManager->unRegisterEventHandler("sale", "OnSaleBeforePayOrder", $this->MODULE_ID, "TwocanHandler2", "OnTwocanPayOrder");

    return true;
  }



	function DoUninstall()
	{	
        global $DOCUMENT_ROOT, $APPLICATION;
        $this->UnInstallEvents();
		$this->UnInstallDB();
		$this->UnInstallFiles();
        $this->UnInstallOrderStatus();
		UnRegisterModule($this->MODULE_ID);
        $APPLICATION->IncludeAdminFile("Деинсталяция модуля ".GetMessage("TWOCAN_MODULE_NAME"), $DOCUMENT_ROOT."/bitrix/modules/".$this->MODULE_ID."/install/unstep.php");
    
		return true;
	}
	function UnInstallDB()
	{	
		return true;
	}
}?>