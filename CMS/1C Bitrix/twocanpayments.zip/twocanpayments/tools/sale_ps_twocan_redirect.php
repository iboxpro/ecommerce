<?
use \Bitrix\Main\Application;
use \Bitrix\Sale\PaySystem;
use \Bitrix\Main\Web\HttpClient; 

define("STOP_STATISTICS", true);
define('NO_AGENT_CHECK', true);
define('NOT_CHECK_PERMISSIONS', true);
define("DisableEventsCheck", true);
require($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/main/include/prolog_before.php");


global $APPLICATION;

if (CModule::IncludeModule("sale"))
{
	$context = Application::getInstance()->getContext();
	$request = $context->getRequest();

	$order=\Bitrix\Sale\Order::load((int)$request->get("order_id"));

	$paymentId = $request->get("payment_id");
	/** @var \Bitrix\Sale\PaymentCollection $collection */
	$collection = $order->getPaymentCollection();

	/** @var \Bitrix\Sale\Payment $payment */
	$payment = $collection->getItemById($paymentId);

	$ps = $payment->getPaySystem();

	$psBusValues = $ps->getParamsBusValue($payment);


	if ($ps)
	{		
		if ($ps instanceof PaySystem\Service)

			$paymentUrl = getPaymentUrl($payment, $psBusValues );

			header( 'Location: ' . $paymentUrl, true, 301 );
			
	}
}

function getPaymentUrl(\Bitrix\Sale\Payment $payment, $psBusValues)
	{
		global $USER;

		$url = ($psBusValues['SALE_HPS_2CAN_IS_TEST'] == 'Y')?'https://api.ecom-sandbox.2can.ru/orders/create':'https://api.ecom.2can.ru/orders/create';
		
		$TerminlID = $psBusValues["SALE_HPS_2CAN_TERMINAL_ID"];
		$TCANLogin = $psBusValues["SALE_HPS_2CAN_LOGIN"];
		$TCANPass = $psBusValues["SALE_HPS_2CAN_PASSWORD"];

		$email = $psBusValues["BUYER_PERSON_EMAIL"]?:"";
		$phone = $psBusValues["BUYER_PERSON_PHONE"]?:"";
		$name = $psBusValues["BUYER_PERSON_NAME"]?:"";
		$city = $psBusValues["BUYER_PERSON_CITY"?:""];
		$country = $psBusValues["BUYER_PERSON_COUNTRY"]?:"";
		$index = $psBusValues["BUYER_PERSON_INDEX"]?:"";

		$orderNumber = $psBusValues["ORDER_ID"];
		$amount = $psBusValues["PAYMENT_SHOULD_PAY"];
		$amount = number_format($amount, 2, '.', '');

		$context = Application::getInstance()->getContext();
		$server = $context->getServer();	
		$request = $context->getRequest();
		$langId = $context->getLanguage();



		$post = [
				"amount" => $amount,
				"merchant_order_id" => $orderNumber,
				"description" => "Заказ №" . $orderNumber,
				"client" => [
					"phone" => $phone,
					"email" => $email,
					"city" => $city,
					"name" => $name,
					//"country" => $country,
					"index" => $index,
				],
				"options" => [
					"terminal" => $TerminlID,
					"force3d" => ($psBusValues["SALE_HPS_2CAN_FORCE3DS"] == "Y")?1:0,
					"auto_charge" => ($psBusValues["SALE_HPS_2CAN_AUTOCHARGE"] == "Y")?0:1,
					"language" => $langId,
					"return_url" => (($request->isHttps()?"https://":"http://").$server->getServerName(). '/bitrix/tools/sale_ps_result.php?HPS_HANDLER=TWOCAN&paymentid='.$payment->getId(). "&id=".$orderNumber),
				],
				'extra_fields' => [
					'oneclick' => [
						'customer_id' => $USER->GetID(),
					]
				]
			];
		


		$httpClient = new HttpClient(); 
		$httpClient->setAuthorization($TCANLogin, $TCANPass);
		$httpClient->disableSslVerification();
		$httpClient->setRedirect(false);
		$httpClient->setVersion("1.1");
		$httpClient->setHeader('Content-Type', 'application/json', true);
		$response = json_decode($httpClient->post($url, json_encode($post)));

		if($httpClient->getStatus() === 201){
			$location = $httpClient->getHeaders()->get('Location');

			$paymentOrderId = $response->orders[0]->id;

			 if ($paymentOrderId) {
		 	
				$payment->setFields(Array('PS_INVOICE_ID' => $paymentOrderId));
		 		
			 	$payment->save();

			}
		  
		}else{
			$location = false;
			$paymentOrderId = false;
		}

		return $location;
	}
