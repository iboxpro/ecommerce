<?
use Bitrix\Sale\PaySystem;

class TwocanHandler2 {
  public static function OnAdminContextMenuShowHandler_button(&$items) {



    if ($GLOBALS['APPLICATION']->GetCurPage() == '/bitrix/admin/sale_order_view.php' || $GLOBALS['APPLICATION']->GetCurPage() == '/bitrix/admin/sale_order_edit.php' || $GLOBALS['APPLICATION']->GetCurPage() == '/bitrix/admin/sale_order_payment_edit.php') {
      if ((array_key_exists('ID', $_REQUEST) && $_REQUEST['ID'] > 0) || (array_key_exists('order_id', $_REQUEST) && $_REQUEST['order_id'] > 0) && \Bitrix\Main\Loader::includeModule('sale')) {
        
        if(array_key_exists('ID', $_REQUEST)) {
          $order_id = $_REQUEST['ID'];
        }else{
          $order_id = $_REQUEST['order_id'];
        }

        $order = \Bitrix\Sale\Order::load($order_id);
        $propertyCollection = $order->getPropertyCollection();

        $two_stage_payment = true; ///двухстадийная оплата
        
        $ps = false;
        $PAY_VOUCHER_NUM = "";
        $psBusValues = null;
        $SALE_HPS_2CAN_AUTOCHARGE = false;
        $TYPE = $order->isPaid() ? 'Y' : "N";

        $paymentCollection = $order->getPaymentCollection();

        foreach ($paymentCollection as $payment) {

          if($payment->getPaySystem()->getField("ACTION_FILE") == 'twocan'){
            $ps = $payment->getPaySystem();
            $PAY_VOUCHER_NUM = $payment->getField('PS_INVOICE_ID');
            $PS_STATUS_CODE = $payment->getField('PS_STATUS_CODE');
            $psBusValues = $ps->getParamsBusValue($payment);
            $SALE_HPS_2CAN_AUTOCHARGE = ($psBusValues['SALE_HPS_2CAN_AUTOCHARGE'] == "Y")?true:false;
          }
        }


        if ($ps && !$order->isCanceled()){
            // Подключаем библиотеку
            CUtil::InitJSCore(array('window')); 

            $buttons = [
              'TEXT' => GetMessage("BUTTON_PAYMENT_ACTIONS"),
              "TITLE" => GetMessage("BUTTON_PAYMENT_ACTIONS_TITLE"),
              'MENU' => []
            ];
            
            if ($PAY_VOUCHER_NUM && $SALE_HPS_2CAN_AUTOCHARGE  && $PS_STATUS_CODE == "authorized") {
              // Параметры кнопки
              $arDialogParams = array(
                 'title' => GetMessage("WINDOW_CONFIRM_TITLE"),
                 'content_url' => "/bitrix/admin/twocan_adminbutton.php?type=pay_ok&id=". $order_id,
                 'width' => 500,
                 'height' => 100,
                 'draggable'=> false,
                'resizable'=> false,
                'closeIcon'=> [],
                'buttons' => array(
                    array(
                          "title" => GetMessage("BUTTON_REFRESH"),
                          "name" => "refresh_page",
                          "id" => "",
                          "action" => "[code]function(){location.reload();}[code]", // Кастомная кнопка
                          'className' => 'adm-btn-save'
                       )
                 ),
              );

              // преобразование в объект и замена кавычек 
            $strParams = CUtil::PhpToJsObject($arDialogParams);
            $strParams = str_replace('\'[code]', '', $strParams);
            $strParams = str_replace('[code]\'', '', $strParams);

            // ссылка для открытия окна
            $url = '(new BX.CDialog('.$strParams.')).Show()';
            $buttons['MENU'][] = array(
                  'TEXT' => GetMessage("BUTTON_CONFIRM_PAYMENT") ,
                  'LINK' => 'javascript:' . $url ,
                  'WARNING' => 'Y',
                );
           
            }            
             
            // Параметры кнопки
            $arDialogParams = array(
               'title' => GetMessage("WINDOW_CHECK_TITLE"),
               'content_url' => "/bitrix/admin/twocan_adminbutton.php?type=check&id=". $order_id,
               'width' => 500,
               'height' => 100,
               'draggable'=> false,
              'resizable'=> false,
              'closeIcon'=> [],
              'buttons' => array(
                  array(
                        "title" => GetMessage("BUTTON_REFRESH"),
                        "name" => "refresh_page",
                        "id" => "",
                        "action" => "[code]function(){location.reload();}[code]", // Кастомная кнопка
                        'className' => 'adm-btn-save'
                     )
               ),
            );

            // преобразование в объект и замена кавычек 
            $strParams = CUtil::PhpToJsObject($arDialogParams);
            $strParams = str_replace('\'[code]', '', $strParams);
            $strParams = str_replace('[code]\'', '', $strParams);

            // ссылка для открытия окна
            $url = '(new BX.CDialog('.$strParams.')).Show()';

            $buttons['MENU'][] = array(
                  'TEXT' => GetMessage("BUTTON_CHECK_PAYMENT") ,
                  'LINK' => 'javascript:' . $url ,
                  'WARNING' => 'Y',
                );

            $FirstItem = array_shift($items);
              $items = array_merge(array(
                $FirstItem
              ) , array(
               $buttons 
              ) , $items);
 

        }

      } 
          

    }

  }

  function OnTwocanOnSaleBeforeCancelOrder($ORDER_ID, $CANCELED) {
    if (!empty($ORDER_ID && $CANCELED == "Y")) {
      CModule::IncludeModule("sale");
      $order = \Bitrix\Sale\Order::load($ORDER_ID);
      $paymentCollection = $order->getPaymentCollection();
      $refundableSum = $order->getField('SUM_PAID');//getPrice();
      $tmp_ps = $order->getPaymentSystemId();
      if ($tmp_ps[0]) $ps_id = $tmp_ps[0];
      if ($ps_id) {
        //возврат
        foreach ($paymentCollection as $payment) {
          $ps = $payment->getPaySystem();
          if ($ps->getField("ACTION_FILE") == 'twocan') {

              $payment->getPaySystem()->cancel($payment);
                     
          }
        }
      }
    }
  }

  function OnTwocanPaymentDelete(\Bitrix\Main\Event $event) {

    return true;
  }

  function OnTwocanOrderDelete($ORDER_ID) {
   if (!empty($ORDER_ID)) {
      CModule::IncludeModule("sale");
      $order = \Bitrix\Sale\Order::load($ORDER_ID);
      $paymentCollection = $order->getPaymentCollection();
      //$refundableSum = $order->getField('SUM_PAID');//getPrice();
      $tmp_ps = $order->getPaymentSystemId();
      if ($tmp_ps[0]) $ps_id = $tmp_ps[0];
      if ($ps_id) {
        //возврат
        foreach ($paymentCollection as $payment) {
          $ps = $payment->getPaySystem();
          if ($ps->getField("ACTION_FILE") == 'twocan' && $payment->isPaid()) {
              $payment->getPaySystem()->cancel($payment);                     
          }
        }
      }
    }
  }

  function OnTwocanPaymentSave(\Bitrix\Main\Event $event) {
     
     CModule::IncludeModule("sale");
     
    $payment = $event->getParameter("ENTITY");
    $oldValues = $event->getParameter("VALUES");
    $arPaymentVals = $payment->getFields()->getValues();

    if($arPaymentVals['IS_RETURN'] == 'N' && $arPaymentVals['PAID'] == 'N' && isset($oldValues['PAID']) && $oldValues['PAID'] == 'Y') // статус изменился
    {
         $ps = $payment->getPaySystem();
         if ($ps->getField("ACTION_FILE") == 'twocan') {
              $initResult = $ps->cancel($payment); 

              $psData = $initResult->getPsData();
              if ($psData)
              {
                $setResult = $payment->setFields($psData);
                if ($setResult->isSuccess())
                {
                  /** @var \Bitrix\Sale\PaymentCollection $paymentCollection */
                  $paymentCollection = $payment->getCollection();
                  if ($paymentCollection)
                  {
                    $order = $paymentCollection->getOrder();

                    if ($order)
                    {
                      $saveResult = $order->save();
                      if (!$saveResult->isSuccess())
                        $initResult->addErrors($saveResult->getErrors());
                    }
                  }
                }
                else
                {
                  $initResult->addErrors($setResult->getErrors());
                }
              }

              if (!$initResult->isSuccess())
                \Bitrix\Sale\PaySystem\ErrorLog::add(array('ACTION' => 'confirm', 'MESSAGE' => $initResult->getErrorMessages()));                    
          }

    }

  }
}


