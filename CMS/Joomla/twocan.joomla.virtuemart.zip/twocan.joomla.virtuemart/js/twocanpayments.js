jQuery(document).ready(function() {
    // jQuery("#get_refund").click(function(event) {
    // 	 event.preventDefault();
    //     jQuery("#refund_sum_cell").show();
    //     jQuery(this).hide();
    // });

    // jQuery("#cancel_refund").click(function(event) {
    // 	event.preventDefault();
    //     jQuery("#refund_sum_cell").hide();
    //     jQuery("#get_refund").show();
    // });

    //  jQuery("#do_refund").click(function(e) {
    //  	e.preventDefault();
    //    calcMAC();
    //    jQuery('#returnForm').submit();
    // });

      jQuery("#historyButton").click(function(e) {
     	e.preventDefault();
       jQuery('#twocanHistory').toggle();
    });
});


			