<?php
if (!defined('_VALID_MOS') && !defined('_JEXEC'))
	die('Direct Access to ' . basename(__FILE__) . ' is not allowed.');

if (!class_exists('vmPSPlugin'))
	require(JPATH_VM_PLUGINS . DS . 'vmpsplugin.php');

if (!class_exists('VmConfig'))
	require(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_virtuemart' . DS . 'helpers' . DS . 'config.php');

VmConfig::loadConfig();

if (!class_exists('VmModel'))
	require(JPATH_ADMINISTRATOR . DS . 'components' . DS . 'com_virtuemart' . DS . 'helpers' . DS . 'vmmodel.php');

if (!class_exists('VirtueMartModelOrders')) {
	require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');
}

class plgVmPaymentTwocanPayments extends vmPSPlugin
{
	
	public $methodId;

	const CURRENCY = 643;

	/**
	 * Тип операции
	 *
	 * 1	Покупка
	 * 24	Возврат
	 * 
	 */

	const TRTYPE_BUY = 1;
	const TRTYPE_RETURN = 24;

	/** 
	 * 0	Транзакция успешно завершена
	 * 1	Обнаружена повторная транзакция
	 * 2	Транзакция отклонена
	 * 3	Ошибка обработки транзакции
	 * 4	Информационное сообщение
	 */

	const STATUS_ACCEPTED  = 0;
	const STATUS_DOUBLED = 1;
	const STATUS_DECLINED  = 2;
	const STATUS_ERROR  = 3;
	const STATUS_INFO  = 4;

	const TEST_API = "api.ecom-sandbox.2can.ru";
	const PROD_API = "api-ecom.2can.ru";

	const TEST_URL = 'test';
	const ACTIVE_URL = 'prod';


	
	function __construct(&$subject, $config)
	{
		parent::__construct($subject, $config);
		$lang = JFactory::getLanguage();
		$this->_loggable = true;
		$this->tableFields = array_keys($this->getTableSQLFields());
		
		if (version_compare(JVM_VERSION, '3', 'ge')) {
			$varsToPush = $this->getVarsToPush();
		} else {
			$varsToPush = array(
				'public_id' => array('', 'string'),
				'payment_message' => array('', 'string'),
				'status_success' => array('', 'char'),
				'status_refund' => array('R', 'char'),
				'status_canceled' => array('X', 'char'),
				"status_pending" => array('P', 'char'),
			);
		}
		$this->setConfigParameterable($this->_configTableFieldName, $varsToPush);
	}
	/**
	 * Срабатывает по урлу ?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&twocanpayment
	 * @param $html
	 * @param $d
	 * @return mixed
	 */
	function plgVmOnPaymentResponseReceived(&$html, &$response)
	{
		if (isset($_GET['twocanpayment'])) {
			switch (JRequest::getVar('twocanaction')) {
				case 'create':
						$oOrderModel = VmModel::getModel('orders');
						$iOrderId = $oOrderModel->getOrderIdByOrderNumber(JRequest::getVar('order_number'));
						$oOrder = $oOrderModel->getOrder($iOrderId);

						if(!$payurl = $this->createOrder($oOrder)){
							vmError('<p>Ошибка создания заказа</p>');
						}else{
							echo '<p>Сейчас вы будете перенаправлены на страницу оплаты</p>';
							$app = JFactory::getApplication();
							$app->redirect($payurl);
							// $script = 'window.setTimeout(function(){ window.location.href = \'' . $payurl . '\';}, 3000);';
							// $document = JFactory::getDocument();
							// $document->addScriptDeclaration($script);
						}
						
						return true;
					break;	
				case 'statusupdate':
						$oOrderModel = VmModel::getModel('orders');
						$iOrderId = $oOrderModel->getOrderIdByOrderNumber(JRequest::getVar('order_number'));
						$oOrder = $oOrderModel->getOrder($iOrderId);

						if(!$psData = $this->checkOrder($oOrder)){
							vmError('<p>Ошибка проверки заказа</p>');
						}else{
							$psData = $this->parsePaymentAnswer($response['body']);
							echo '<p>Сейчас вы будете перенаправлены на страницу заказа</p>';
							$redirecturl = JUri::base().'index.php?option=com_virtuemart&view=orders&task=edit&layout=details&order_number='.$oOrder['details']['BT']->order_number.'&order_pass='.$oOrder['details']['BT']->order_pass;
							$app = JFactory::getApplication();
							$app->redirect($redirecturl);
						}
						
						return true;
					break;
				case 'statusupdateadmin':
						$oOrderModel = VmModel::getModel('orders');
						$iOrderId = $oOrderModel->getOrderIdByOrderNumber(JRequest::getVar('order_number'));
						$oOrder = $oOrderModel->getOrder($iOrderId);
						$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber (JRequest::getVar('order_number'));

						if(!$this->checkOrder($oOrder)){
							vmError('<p>Ошибка проверки заказа</p>');
						}else{
							echo '<p>Сейчас вы будете перенаправлены на страницу заказа</p>';
							$redirecturl = JUri::base().'administrator/index.php?option=com_virtuemart&view=orders&task=edit&virtuemart_order_id='.$virtuemart_order_id;
							$app = JFactory::getApplication();
							$app->redirect($redirecturl);
							
						}
						
						return true;
					break;			
				default:
					die('Something goes worng');
					break;
			}
		}
		
		vmDebug('plgVmOnPaymentResponseReceived');
		//return $this->plgVmOnPaymentResponseReceived($html);
	}

	private function createOrder($order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}

		$orderNumber = $order['details']['BT']->order_number;

		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($orderNumber);;

		$url = $this->getUrl('create', $method->scheme);
var_dump($url);
		$totalInPaymentCurrency =  number_format($order['details']['BT']->order_total, 2, '.', '');

		$sPhone = $order['details']['BT']->phone_1 ? $order['details']['BT']->phone_1 : ($order['details']['BT']->phone_2 ? $order['details']['BT']->phone_2 : '');
		$sAddress = $order['details']['BT']->address_1 ? $order['details']['BT']->address_1 : ($order['details']['BT']->address_2 ? $order['details']['BT']->address_2 : '');

		$lang = JFactory::getLanguage();
		$langId= $lang->getTag();

		$post = [
				"amount" => $totalInPaymentCurrency,
				"merchant_order_id" => $virtuemart_order_id,
				"description" => "Заказ №" . $orderNumber,
				"client" => [
					"phone" => $sPhone,
					"email" => $order['details']['BT']->email,
					"city" => $order['details']['BT']->city,
					"name" => ($order['details']['BT']->first_name?$order['details']['BT']->first_name. ' ':'') . ($order['details']['BT']->middle_name?$order['details']['BT']->middle_name. ' ':'') .$order['details']['BT']->last_name,
					"address" => $sAddress,
					"index" => $order['details']['BT']->zip,
				],
				"options" => [
					"terminal" => $method->terminalid,
					"force3d" => $method->force3d,
					"auto_charge" => $method->paymentscheme,
					"language" => 'ru',//$langId,
					"return_url" => JUri::base().'index.php?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&twocanpayment&twocanaction=statusupdate&order_number='.$order['details']['BT']->order_number,
				],
				'extra_fields' => [
					'oneclick' => [
						'customer_id' => $order['details']['BT']->virtuemart_user_id,
					]
				]
			];

		if(!$response = $this->makeRequest($method, $url, $virtuemart_order_id, "POST", $post)){
			return false;
		}
		// Prepare data that should be stored in the database
		$dbValues = ['twocan_order_id' => $response['body']['orders'][0]['id']];

		$this->setOrderValues($virtuemart_order_id, $dbValues);

		return $response['headers']['Location'];

	}

	private function confirmOrder($order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}

		$orderNumber = $order['details']['BT']->order_number;

		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($orderNumber);

		$customData = $this->getOrderCustomValues($virtuemart_order_id);

		$url = sprintf($this->getUrl('charge', $method->scheme),$customData['twocan_order_id'] );

		$totalInPaymentCurrency =  number_format($order['details']['BT']->order_total, 2, '.', '');


		$post = [
				"amount" => $totalInPaymentCurrency,
			];

		if(!$response = $this->makeRequest($method, $url, $virtuemart_order_id,"PUT", $post)){
			
			return false;
		}
		
		$psData = $this->parsePaymentAnswer($response['body']);

		$this->writeHistory($virtuemart_order_id, ($psData["PS_STATUS_MESSAGE"]?:$psData['PS_STATUS_DESCRIPTION']). " " . date('Y-m-d H:i:s'));

		return $psData;

	}

	private function refundOrder($order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}

		$orderNumber = $order['details']['BT']->order_number;


		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($orderNumber);;

		$customData = $this->getOrderCustomValues($virtuemart_order_id);



		$url = sprintf($this->getUrl('refund', $method->scheme),$customData['twocan_order_id'] );

		$totalInPaymentCurrency =  number_format($order['details']['BT']->order_total, 2, '.', '');


		$post = [
				"amount" => $totalInPaymentCurrency,
			];

		if(!$response = $this->makeRequest($method, $url, $virtuemart_order_id,"PUT", $post)){
			
			return false;
		}
		
		$psData = $this->parsePaymentAnswer($response['body']);



		$this->writeHistory($virtuemart_order_id, ($psData["PS_STATUS_MESSAGE"]?:$psData['PS_STATUS_DESCRIPTION']) . " " . date('Y-m-d H:i:s'));



		return $psData;

	}

	private function reverseOrder($order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}

		$orderNumber = $order['details']['BT']->order_number;

		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($orderNumber);;
		$customData = $this->getOrderCustomValues($virtuemart_order_id);

		$url = sprintf($this->getUrl('reverse', $method->scheme),$customData['twocan_order_id'] );

		$totalInPaymentCurrency =  number_format($order['details']['BT']->order_total, 2, '.', '');


		if(!$response = $this->makeRequest($method, $url, $virtuemart_order_id,"PUT")){
			
			return false;
		}
		
		$psData = $this->parsePaymentAnswer($response['body']);
		$this->writeHistory($virtuemart_order_id, ($psData["PS_STATUS_MESSAGE"]?:$psData['PS_STATUS_DESCRIPTION']) . " " . date('Y-m-d H:i:s'));

		return $psData;

	}

	public function checkOrder($order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}

		$orderNumber = $order['details']['BT']->order_number;

		$virtuemart_order_id = VirtueMartModelOrders::getOrderIdByOrderNumber ($orderNumber);;

		$url = $this->getUrl('create', $method->scheme);

		 $customData = $this->getOrderCustomValues($virtuemart_order_id);

		$url = sprintf($this->getUrl('status', $method->scheme),$customData['twocan_order_id'] );

		$response = $this->makeRequest($method, $url, $virtuemart_order_id,'GET');

		$psData = $this->parsePaymentAnswer($response['body']);
		$this->writeHistory($virtuemart_order_id, ($psData["PS_STATUS_MESSAGE"]?:$psData['PS_STATUS_DESCRIPTION']) . " " . date('Y-m-d H:i:s'));
		$oOrderModel = VmModel::getModel('orders');

		if(!$status = $this->mapStatus( $psData['PS_STATUS_CODE'],$method->paymentscheme)){
			vmError($psData["PS_STATUS_MESSAGE"]?:$psData['PS_STATUS_DESCRIPTION']);
			return $psData;
		};

		$aOrder['order_status'] = $method->$status; 
		
		$oOrderModel->updateStatusForOneOrder($order['details']['BT']->virtuemart_order_id, $aOrder, TRUE);

		$dbValues['paid'] = ($psData['PAID'] === "Y")?1:0;

		$dbValues['refunded'] = ($aOrder['order_status'] == $method->status_refund)?1:0;

		$this->setOrderValues($virtuemart_order_id, $dbValues);
		return $psData;

	}


	/**
	 * Метод для отправки запросов системе
	 * @param object $method
	 * @param string $url
	 * @param array  $request
	 * @return bool|array
	 */
	private function makeRequest($method, $url, $virtuemart_order_id, $type = 'POST', $request = array()) {


		if (!$this->curl) {
			$auth       = $method->login . ':' . $method->password;
			$this->curl = curl_init();
			$fp = fopen('/web/joomla.rbarsukov.com/logs/curlerrorlog.txt', 'w');
			curl_setopt($this->curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($this->curl, CURLOPT_HEADER, true);
			curl_setopt($this->curl, CURLOPT_CONNECTTIMEOUT, 30);
			curl_setopt($this->curl, CURLOPT_TIMEOUT, 30);
			curl_setopt($this->curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
			curl_setopt($this->curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
			curl_setopt($this->curl, CURLOPT_USERPWD, $auth);
			curl_setopt($this->curl, CURLOPT_SSL_VERIFYHOST, 0);
			curl_setopt($this->curl, CURLOPT_SSL_VERIFYPEER, 0);
			curl_setopt($this->curl, CURLOPT_VERBOSE, 1);
   			curl_setopt($this->curl, CURLOPT_STDERR, $fp);
		}
		
		curl_setopt($this->curl, CURLOPT_URL, $url);
		if($type === 'POST'){
			curl_setopt($this->curl, CURLOPT_HTTPHEADER, array(
				"content-type: application/json"
			));

			curl_setopt($this->curl, CURLOPT_POST, true);
			if(!empty($request))curl_setopt($this->curl, CURLOPT_POSTFIELDS, json_encode($request));
		}elseif( $type === "PUT"){
			curl_setopt($this->curl, CURLOPT_CUSTOMREQUEST, "PUT");
			if(!empty($request))curl_setopt($this->curl, CURLOPT_POSTFIELDS, json_encode($request));
		}

		$response = curl_exec($this->curl);

		if ($response === false){
			vmDebug('TwocanPayments Failed API request' .
				' Location: ' . $url .
				' Request: ' . print_r($request, true) .
				' HTTP Code: ' . curl_getinfo($this->curl, CURLINFO_HTTP_CODE) .
				' Error: ' . curl_error($this->curl)
			);
			
			return false;
		}
		$header_size = curl_getinfo($this->curl, CURLINFO_HEADER_SIZE);
		$headers = substr($response, 0, $header_size);		

		preg_match_all('/^([a-z\-]+)\:(.*)/im', $headers, $matches);
		
		$headers = [];
		foreach ($matches[1] as $key => $headername) {
			$headers[trim($headername)]= trim($matches[2][$key]);
		}

		$body = substr($response, $header_size);
		$body = json_decode($body, true);

		if(!in_array(curl_getinfo($this->curl, CURLINFO_HTTP_CODE), [200, 201])) {
			vmError('TwocanPayments error: '. $body['failure_message']);
			$this->writeHistory($virtuemart_order_id, $body['failure_message'] . ' ' . date('Y-m-d H:i:s'));
			return false;
		}
		
		if (!isset($body['orders']) || !$body['orders']) {
			vmError('TwocanPayments error: '.$body['failure_message']);
			vmDebug('TwocanPayments Failed API request' .
				' Location: ' . $url .
				' Request: ' . print_r($request, true) .
				' HTTP Code: ' . curl_getinfo($this->curl, CURLINFO_HTTP_CODE) .
				' Error: ' . curl_error($this->curl)
			);		
			
		}
		
		return ['body' => $body, 'headers' => $headers];
	}
	
		
	/**
	 * Срабатывает при сохранении в админке
	 * Create the table for this plugin if it does not yet exist.
	 * This functions checks if the called plugin is active one.
	 * When yes it is calling the standard method to create the tables
	 * @author Valérie Isaksen
	 *
	 */
	public function plgVmOnStoreInstallPaymentPluginTable($jplugin_id)
	{
		/**
		 * Проверим наличие статусов TwocanPayments
		 */
		return $this->onStoreInstallPluginTable($jplugin_id);
	}
	
	/**
	 * Срабатывает после того как пользователь нажал кнопку подтвердить в корзине
	 * @param $cart
	 * @param $order
	 * @return bool|null
	 */
	public function plgVmConfirmedOrder($cart, $order)
	{
		if (!($method = $this->getVmPluginMethod($order['details']['BT']->virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($method->payment_element)) {
			return false;
		}
		
		// Prepare data that should be stored in the database
		$dbValues['order_number'] = $order['details']['BT']->order_number;
		$dbValues['virtuemart_order_id'] = $values['virtuemart_order_id'] = VirtueMartModelOrders::getOrderIdByOrderNumber ($dbValues['order_number']);
		$dbValues['virtuemart_paymentmethod_id'] = $virtuemart_paymentmethod_id;
		$dbValues['payment_name'] = $method->payment_name;
		$dbValues['payment_currency'] = $method->payment_currency;

		$this->storePSPluginInternalData($dbValues);

		/**
		 * Если метод оплаты TwocanPayments, то редиректим на страницу заказа для оплаты
		 */
		if ($method->virtuemart_paymentmethod_id == $this->methods[0]->virtuemart_paymentmethod_id) {
			$script = "console.log('{$order['details']['BT']->order_number}')";
			$script = "window.setTimeout(function(){ window.location.href = '/index.php?option=com_virtuemart&view=orders&task=edit&layout=details&order_number={$order['details']['BT']->order_number}&order_pass={$order['details']['BT']->order_pass}';}, 3000);";
			$document = JFactory::getDocument();
			$document->addScriptDeclaration($script);
		}
		/**
		 * Чистим корзину
		 */
		$cart->emptyCart ();
		/**
		 * Сообщаем о перенаправлении.
		 */
		vmInfo('<p>Сейчас вы будете перенаправлены на страницу заказа для совершения оплаты</p>');
		return null;
	}
	
	/**
	 * Срабатывает когда показываем детали по конкретному заказу. Здесь будем оплачивать
	 * This method is fired when showing the order details in the frontend.
	 * It displays the method-specific data.
	 *
	 * @param integer $order_id The order ID
	 * @return mixed Null for methods that aren't active, text (HTML) otherwise
	 * @author Max Milbers
	 * @author Valerie Isaksen
	 */
	public function plgVmOnShowOrderFEPayment($virtuemart_order_id, $virtuemart_paymentmethod_id, &$payment_name)
	{
		vmDebug('plgVmOnShowOrderFEPayment');
		$this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);
		
		
		if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($method->payment_element)) {
			return false;
		}
		$result = $this->onShowOrderFE($virtuemart_order_id, $virtuemart_paymentmethod_id, $payment_name);

		$link = '/?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&twocanaction=create&twocanpayment';

		if (JRequest::getVar('option') == 'com_virtuemart' &&
			Jrequest::getVar('view') == 'orders' &&
			Jrequest::getVar('layout') == 'details') {
			if (!class_exists('CurrencyDisplay'))
				require(JPATH_VM_ADMINISTRATOR . DS . 'helpers' . DS . 'currencydisplay.php');
			if (!class_exists('VirtueMartModelOrders'))
				require(JPATH_VM_ADMINISTRATOR . DS . 'models' . DS . 'orders.php');

			$orderModel = VmModel::getModel('orders');
			$oOrder = $orderModel->getOrder($virtuemart_order_id);
			if ($method->status_pending == $oOrder['details']['BT']->order_status) {

				$html = '';

				$html .= '<form action="'. $link. '" method="post" >';
				$html .= '<input type="hidden" name="order_number" value="'.$oOrder['details']['BT']->order_number .'">';
				$html .= '<input type="submit" name="Submit" class="btn btn-success" value="Оплатить">';
				$html .= '</form>';
			} else {
				if (!class_exists('shopFunctionsF')) {
					require(JPATH_VM_SITE . DS . 'helpers' . DS . 'shopfunctionsf.php');
				}
				$html = '<div>('.shopFunctionsF::getOrderStatusName($oOrder['details']['BT']->order_status).')</div>';
			}
			
			$payment_name .= $html;
		}
		return $result;
		
	}

	private function getUrl($action, $type = self::TEST_URL)
	{
		$urls = $this->getUrlList();

		return $urls[$action][$type];
	}


	/**
	 * @return mixed
	 */
	protected function getUrlList()
	{
		$hostTest = self::TEST_API; 
		$hostProd  = self::PROD_API;
		return array(
			// 'pay' => array(
			// 	self::TEST_URL => 'https://checkout' . $hostTest . '/pay/%d',
			// 	self::ACTIVE_URL => 'https://checkout' . $hostProd . '/pay/%d'
			// ),
			'charge' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/charge',
				self::TEST_URL => 'https://' . $hostTest . '/orders/%d/charge'
			),
			'cancel' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/cancel',
				self::TEST_URL => 'https://' . $hostTest . '/orders/%d/cancel'
			),
			'reverse' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/reverse',
				self::TEST_URL => 'https://' . $hostTest . '/orders/%d/reverse'
			),
			'refund' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d/refund',
				self::TEST_URL => 'https://' . $hostTest . '/orders/%d/refund',
			),
			'create' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/create',
				self::TEST_URL => 'https://' . $hostTest . '/orders/create',
			),
			'status' => array(
				self::ACTIVE_URL => 'https://' . $hostProd . '/orders/%d',
				self::TEST_URL => 'https://' . $hostTest . '/orders/%d',
			),
		);
	}
	
	/**
	 * Срабатывает до показа корзины
	 * plgVmDisplayListFEPayment
	 * This event is fired to display the pluginmethods in the cart (edit shipment/payment) for exampel
	 *
	 * @param object $cart Cart object
	 * @param integer $selected ID of the method selected
	 * @return boolean True on succes, false on failures, null when this plugin was not selected.
	 * On errors, JError::raiseWarning (or JError::raiseError) must be used to set a message.
	 *
	 */
	public function plgVmDisplayListFEPayment(VirtueMartCart $cart, $selected = 0, &$htmlIn)
	{
		$method = $this->methods[0];
		$methodId = $method->virtuemart_paymentmethod_id;
		$name = $method->payment_name;
		
		if ($selected == $methodId) {
			$checked = 'checked="checked"';
		} else {
			$checked = '';
		}
		
		$html = '<input type="radio" name="' . $this->_idName . '" data-dynamic-update="1" id="' . $this->_psType . '_id_' . $methodId . '"   value="' . $methodId . '" ' . $checked . ">\n"
			. '<label for="' . $this->_psType . '_id_' . $methodId . '">' . '<span class="' . $this->_type . '">' . $name . "</span></label>\n";
		
		$htmlIn [] = [$html];
		
		return true;
	}

	/**
	 * @param $orderDetails
	 * @param $data
	 * @return null
	 */
	function plgVmOnUserInvoice ($orderDetails, &$data) {

		if (!($method = $this->getVmPluginMethod ($orderDetails['virtuemart_paymentmethod_id']))) {
			return NULL; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement ($method->payment_element)) {
			return NULL;
		}
		
		$virtuemart_order_id = $orderDetails['virtuemart_order_id'];
		
		$customVaules = $this->getOrderCustomValues($virtuemart_order_id); 
		
		$orderDetails['virtuemart_paymentmethod_id'];
		$data['invoice_number'] = $customVaules['twocan_order_id']; // Nerver send the invoice via email
	}
	
	/**
	 * Срабатывает после оформления заказа /  При обнослении статуса заказа в админке
	 * Срабатывает при сохранении статуса заказ в админке
	 * Save updated order data to the method specific table
	 *
	 * @param array $_formData Form data
	 * @return mixed, True on success, false on failures (the rest of the save-process will be
	 * skipped!), or null when this method is not actived.
	 * @author Oscar van Eijk
	 */
	public function plgVmOnUpdateOrderPayment(&$_formData)
	{
		if (isset($_GET['task']) && $_GET['task'] == 'pluginresponsereceived')  return true; // если вызывается вебхук, то ничего не делаем, иначе не изменится статус заказа
		/**
		 * Отправляем TwocanPayments сообщение:
		 *  - заказ подтвержден / отменен
		 * Дальше будет вызван вебхук confirm и изменится статус заказа на status_cp_confirmed
		 */
		$method = $this->getVmPluginMethod($_formData->virtuemart_paymentmethod_id);
		$oOrderModel = VmModel::getModel('orders');
		$iOrderId = $oOrderModel->getOrderIdByOrderNumber($_formData->order_number);
		$oOrder = $oOrderModel->getOrder($iOrderId);
		$customValues = $this->getOrderCustomValues($iOrderId);
		if  ($method->payment_element == 'twocanpayments') {
			if ($oOrder['details']['BT']->order_status == $method->status_auth && $_formData->order_status == $method->status_confirmed) {
				$psData = $this->confirmOrder($oOrder);
				if(!$status = $this->mapStatus( $psData['PS_STATUS_CODE'],$method->paymentscheme)){
					$_formData->order_status = $oOrder['details']['BT']->order_status;
					vmError(vmText::_('COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_CONFIRMED_FAILED'));	
				}else{
					$_formData->order_status = $method->$status;							
					vmInfo(vmText::_('COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_CONFIRMED'));	
				}				
			} elseif ($_formData->order_status == $method->status_refund) {
				// не даем возможности через админку поменять заказ на status_cp_refund (возврат)
				$psData = $this->refundOrder($oOrder);
				if(!$status = $this->mapStatus($psData['PS_STATUS_CODE'],$method->paymentscheme)){
					$_formData->order_status = $oOrder['details']['BT']->order_status;
					vmInfo(vmText::_('COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_REFUND_FAILED'));	
				}else{
					$_formData->order_status = $method->$status;							
					vmInfo(vmText::_('COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_REFUND'));						
				}	
				return true;	
			} elseif ($_formData->order_status == $method->status_canceled && !$customValues['refunded']) {		
				$psData = (!$method->paymentscheme && !$customValues['paid'])?$this->reverseOrder($oOrder):$this->refundOrder($oOrder);
				if(!$status = $this->mapStatus( $psData['PS_STATUS_CODE'],$method->paymentscheme)){
					$_formData->order_status = $oOrder['details']['BT']->order_status;
					vmError(vmText::_($method->paymentscheme?'COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_REFUND_FAILED':'COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_CANCELED_FAILED'));				
				}else{
					$_formData->order_status = $method->$status;							
					vmInfo(vmText::_($method->paymentscheme?'COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_REFUND':'COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_UPDATED_CANCELED'));	
		
				}	
				return true;	
			}
		}
		// 	return
	}
	
		
	/**
	 * Срабатывает при вызове в админке
	 * @param $data
	 * @return bool
	 */
	public function plgVmDeclarePluginParamsPaymentVM3(&$data)
	{
		return $this->declarePluginParams('payment', $data);
	}
	
	/**
	 * Fields to create the payment table
	 * @return string SQL Fileds
	 */
	function getTableSQLFields()
	{
		$SQLfields = array(
			'id' => 'int(11) unsigned NOT NULL AUTO_INCREMENT',
			'virtuemart_order_id' => 'int(11) UNSIGNED',
			'order_number' => 'char(32)',
			'twocan_order_id' => 'char(32)',
			'paid' => 'int(1) unsigned NULL DEFAULT 0',
			'refunded' => 'int(1) unsigned NULL DEFAULT 0',
			'history' => "TEXT NULL DEFAULT ''" 
		
		);
		
		return $SQLfields;
	}
	
	/**
	 * Срабатывает после оформления заказа
	 * Display stored payment data for an order
	 * @param $virtuemart_order_id
	 * @param $virtuemart_payment_id
	 * @return mixed
	 */
	function plgVmOnShowOrderBEPayment($virtuemart_order_id, $virtuemart_payment_id)
	{

		if (!$this->selectedThisByMethodId($virtuemart_payment_id)) {
			return NULL; // Another method was selected, do nothing
		}
		if (!($method = $this->getVmPluginMethod($virtuemart_payment_id))) {
			return NULL; // Another method was selected, do nothing
		}

		$document = JFactory::getDocument();
		$document->addScript('/plugins/vmpayment/twocanpayments/js/twocanpayments.js');

		$orderModel = VmModel::getModel('orders');
		$order = $orderModel->getOrder($virtuemart_order_id);
		
		$customVaules = $this->getOrderCustomValues($virtuemart_order_id); 

		$html = '<table class="adminlist table">' . "\n";
		$html .= '
			<thead>
				<tr>
					<th class="key" style="text-align: center;" >'.$method->payment_name.'</th>
				</tr>
			</thead>';
		$html .= '<tbody>
					<tr>							
						<th class="key" style="text-align: center;" ><a href="/?option=com_virtuemart&view=pluginresponse&task=pluginresponsereceived&twocanpayment&twocanaction=statusupdateadmin&order_number='.$order['details']['BT']->order_number.'">Проверить статус оплаты</a></th>							
					</tr>
					<tr>							
						<th class="key" style="text-align: center;" ><a href="#twocanHistory" id="historyButton"> Сообщения от банка</a></th>							
					</tr>
					<tr>						
						<td>
							<textarea style="width:100%; height: 200px; display:none;" id="twocanHistory">'.$customVaules['history'].'</textarea>
						</td>							
					</tr>
					</tbody>';
		$html .= "</table>" ;		
		return $html;
		if (!in_array($order['details']['BT']->order_status, [$method->status_pending, $method->status_refund])) {
		}
		return NULL;
		
	}

	
	/**
	 * Срабатывает до показа корзины
	 * @param VirtueMartCart $cart
	 * @param int $method
	 * @param array $cart_prices
	 *
	 * @return bool
	 *
	 * @since version
	 */
	protected function checkConditions($cart, $method, $cart_prices)
	{
		return true;
	}
	
	/**
	 * Срабатывает при клике по платежной системе в коризине
	 * This event is fired after the payment method has been selected. It can be used to store
	 * additional payment info in the cart.
	 *
	 * @author Max Milbers
	 * @author Valérie isaksen
	 *
	 * @param VirtueMartCart $cart : the actual cart
	 * @return null if the payment was not selected, true if the data is valid, error message if the data is not vlaid
	 *
	 */
	public function plgVmOnSelectCheckPayment(VirtueMartCart $cart)
	{
		return $this->OnSelectCheck($cart);
	}
	
	/**
	 * Срабатывает до показа корзины
	 * plgVmonSelectedCalculatePricePayment
	 * Calculate the price (value, tax_id) of the selected method
	 * It is called by the calculator
	 * This function does NOT to be reimplemented. If not reimplemented, then the default values from this function are taken.
	 * @author Valerie Isaksen
	 * @cart: VirtueMartCart the current cart
	 * @cart_prices: array the new cart prices
	 * @return null if the method was not selected, false if the shiiping rate is not valid any more, true otherwise
	 *
	 *
	 */
	public function plgVmonSelectedCalculatePricePayment(VirtueMartCart $cart, array &$cart_prices, &$cart_prices_name)
	{
		return $this->onSelectedCalculatePrice($cart, $cart_prices, $cart_prices_name);
	}
	
	/**
	 * Срабатывает когда заказ оформлен
	 * @param $virtuemart_paymentmethod_id
	 * @param $paymentCurrencyId
	 * @return bool|null
	 */
	function plgVmgetPaymentCurrency($virtuemart_paymentmethod_id, &$paymentCurrencyId)
	{
		if (!($method = $this->getVmPluginMethod($virtuemart_paymentmethod_id))) {
			return null; // Another method was selected, do nothing
		}
		if (!$this->selectedThisElement($method->payment_element)) {
			return false;
		}
		$this->getPaymentCurrency($method);
		
		$paymentCurrencyId = $method->payment_currency;
	}
	
	/**
	 * Срабатывает во время оформления заказа. Заказа в базе еще нет
	 * plgVmOnCheckAutomaticSelectedPayment
	 * Checks how many plugins are available. If only one, the user will not have the choice. Enter edit_xxx page
	 * The plugin must check first if it is the correct type
	 * @author Valerie Isaksen
	 * @param VirtueMartCart cart: the cart object
	 * @return null if no plugin was found, 0 if more then one plugin was found,  virtuemart_xxx_id if only one plugin is found
	 *
	 */
	function plgVmOnCheckAutomaticSelectedPayment(VirtueMartCart $cart, array $cart_prices = array())
	{
		return $this->onCheckAutomaticSelected($cart, $cart_prices);
	}
	
	/**
	 * Срабатывает до показа корзины
	 * Не подходит для проверки, т.к. пользователь должен быть авторизован
	 * This event is fired during the checkout process. It can be used to validate the
	 * method data as entered by the user.
	 *
	 * @return boolean True when the data was valid, false otherwise. If the plugin is not activated, it should return null.
	 * @author Max Milbers
	 */
	public function plgVmOnCheckoutCheckDataPayment(VirtueMartCart $cart)
	{
		return null;
	}
	
	
	/**
	 * This method is fired when showing when priting an Order
	 * It displays the the payment method-specific data.
	 *
	 * @param integer $_virtuemart_order_id The order ID
	 * @param integer $method_id method used for this order
	 * @return mixed Null when for payment methods that were not selected, text (HTML) otherwise
	 * @author Valerie Isaksen
	 */
	function plgVmonShowOrderPrintPayment($order_number, $method_id)
	{
		return $this->onShowOrderPrint($order_number, $method_id);
	}
	
	function plgVmDeclarePluginParamsPayment($name, $id, &$data)
	{
		return $this->declarePluginParams('payment', $name, $id, $data);
	}
	
	/**
	 * Срабатывает при сохранении настроек в админке
	 * @param $name
	 * @param $id
	 * @param $table
	 *
	 * @return bool
	 *
	 * @since version
	 */
	function plgVmSetOnTablePluginParamsPayment($name, $id, &$table)
	{
		return $this->setOnTablePluginParams($name, $id, $table);
	}
	
	//Notice: We only need to add the events, which should work for the specific plugin, when an event is doing nothing, it should not be added

	
	/**
	 * Save updated orderline data to the method specific table
	 *
	 * @param array $_formData Form data
	 * @return mixed, True on success, false on failures (the rest of the save-process will be
	 * skipped!), or null when this method is not actived.
	 * @author Oscar van Eijk
	 */
	public function plgVmOnUpdateOrderLine($_formData)
	{
		return null;
	}
	
	/**
	 * Данного метода нет PayPal
	 * plgVmOnEditOrderLineBE
	 * This method is fired when editing the order line details in the backend.
	 * It can be used to add line specific package codes
	 *
	 * @param integer $_orderId The order ID
	 * @param integer $_lineId
	 * @return mixed Null for method that aren't active, text (HTML) otherwise
	 * @author Oscar van Eijk
	 */
	public function plgVmOnEditOrderLineBEPayment($_orderId, $_lineId)
	{
		return null;
	}
	
	/**
	 * Данного метода нет PayPal
	 * This method is fired when showing the order details in the frontend, for every orderline.
	 * It can be used to display line specific package codes, e.g. with a link to external tracking and
	 * tracing systems
	 *
	 * @param integer $_orderId The order ID
	 * @param integer $_lineId
	 * @return mixed Null for method that aren't active, text (HTML) otherwise
	 * @author Oscar van Eijk
	 */
	public function plgVmOnShowOrderLineFE($_orderId, $_lineId)
	{
		return null;
	}
	
	/**
	 * This event is fired when the  method notifies you when an event occurs that affects the order.
	 * Typically,  the events  represents for payment authorizations, Fraud Management Filter actions and other actions,
	 * such as refunds, disputes, and chargebacks.
	 *
	 * NOTE for Plugin developers:
	 *  If the plugin is NOT actually executed (not the selected payment method), this method must return NULL
	 *
	 * @param $return_context : it was given and sent in the payment form. The notification should return it back.
	 * Used to know which cart should be emptied, in case it is still in the session.
	 * @param int $virtuemart_order_id : payment  order id
	 * @param char $new_status : new_status for this order id.
	 * @return mixed Null when this method was not selected, otherwise the true or false
	 *
	 * @author Valerie Isaksen
	 *
	 **/
	
	/**
	 * @return bool|null
	 */
	public function plgVmOnPaymentNotification()
	{
		return null;
	}
	
	function plgVmOnUserPaymentCancel()
	{
		return $this->plgVmOnUserPaymentCancel();

	}

	private function writeHistory($v_id,$text)
	{

	 	if(strlen($text)){ 
	 		$text .= "\n --- \n";
			$oDb = JFactory::getDBO();
			$sSql = 'UPDATE `#__virtuemart_payment_plg_twocanpayments` SET history = IFNULL (CONCAT( history , "'. $text.'" ), "'.$text.'") WHERE `virtuemart_order_id` = '.$v_id;
			$oDb->setQuery($sSql);
			$oDb->execute();
		}
	}

	private function getOrderByTwocanOrderId($TwocanOrderId)
	{

		$db = JFactory::getDbo();
		$query = $db->getQuery(true);
		$query->select('order_number');
		$query->from($db->quoteName('#__virtuemart_payment_plg_twocanpayments'));
		$query->where($db->quoteName('twocan_order_id')." = ".$db->quote($TwocanOrderId));

		$db->setQuery($query);
		$order_number =  $db->loadResult();
		if($order_number){
			$oOrderModel = VmModel::getModel('orders');
			$iOrderId = $oOrderModel->getOrderIdByOrderNumber($order_number);
			$oOrder = $oOrderModel->getOrder($iOrderId);
			return $oOrder;
		}else{
			return false;
		}
	}

	private function setOrderValues($v_order_id ,$values)
	{
		if(!empty($values)){
			$db = JFactory::getDbo();

			$query = $db->getQuery(true);

			// Fields to update.
			$fields = array();

			foreach ($values as $key => $value) {
				$fields[] = $db->quoteName($key) . ' = ' . $db->quote($value);
			}

			// Conditions for which records should be updated.
			$conditions = array(
			    $db->quoteName('virtuemart_order_id') . ' = ' . $v_order_id, 		    
			);

			$query->update($db->quoteName('#__virtuemart_payment_plg_twocanpayments'))->set($fields)->where($conditions);

			$db->setQuery($query);

			$result = $db->execute();
		}
	}

	private function getOrderCustomValues($v_order_id)
	{

			$db = JFactory::getDbo();

			$query = $db->getQuery(true);

			$query
			    ->select('*')
			    ->from($db->quoteName('#__virtuemart_payment_plg_twocanpayments'))
			    ->where($db->quoteName('virtuemart_order_id') . ' = ' . $v_order_id);



			$db->setQuery($query);
			return $db->loadAssoc();
			
	}



	private function parsePaymentAnswer($responseData){
		$this->psStatus = $responseData['orders'][0]['status'];
		switch ($responseData['orders'][0]['status']) {
			case 'refunded':
					$amount = $responseData['orders'][0]['amount_refunded'];
				break;
			case 'charged':
					$amount = $responseData['orders'][0]['amount_charged'];
				break;			
			default:
					$amount = $responseData['orders'][0]['amount'];
				break;
		}
		$psData = array(
			"PS_STATUS" => (in_array($responseData['orders'][0]['status'], ['refunded', 'chargedback','reversed','authorized','charged','new','processing', 'prepared']))?'Y':'N',
			"PS_RESPONSE_DATE" => new DateTime(),
			"PS_SUM" => $amount,
			"PS_CURRENCY" => $responseData['orders'][0]['currency'],
			"PS_STATUS_MESSAGE" => (isset($responseData['orders'][0]['failure_message'])?$responseData['orders'][0]['failure_message']:''),
			"PS_STATUS_DESCRIPTION" => JText::_('COM_VIRTUEMART_PLUGIN_TWOCANPAYMENTS_STATUS_'.strtoupper($responseData['orders'][0]['status'])),
			"PS_STATUS_CODE" => $responseData['orders'][0]['status']			
		);

		

		if(in_array($responseData['orders'][0]['status'], ['charged'])) {
			
			$psData["PAID"] = "Y";	

		}elseif(in_array($responseData['orders'][0]['status'], ['refunded', 'chargedback','reversed', 'authorized'])){
			
			$psData["PAID"] = "N";	

		}

		return $psData;
	}

	private function mapStatus($status, $onestage = true)
	{	
		switch ($status) {
			case 'authorized':
					return 'status_auth';
				break;
			case 'charged':
					return $onestage?'status_success':'status_confirmed';
				break;
			case 'refunded':
					return 'status_refund';
				break;
			case 'reversed':
			case 'canceled':
					return 'status_canceled';
				break;
			default:
				 return false;
				break;
		}
	}


}
