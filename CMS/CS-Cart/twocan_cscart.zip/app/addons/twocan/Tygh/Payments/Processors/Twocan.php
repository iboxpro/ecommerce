<?php
namespace Tygh\Payments\Processors;

use Tygh\Registry;
use Tygh\Http;
use Tygh\Enum\OrderDataTypes;
use Tygh\Enum\OrderStatuses;

class Twocan
{
    const CONNECTION_ERROR_TITLE = "Сетевая ошибка: ";
    protected $_url = '';
    protected $_currency;
    protected $_login;
    protected $_password;
    protected $_terminal;
    protected $_autocharge;
    protected $_processor_data;

    protected $_response;
    protected $_error_code = 0;
    protected $_error_text = '';

    public function __construct($processor_data)
    {
        $this->_processor_data = $processor_data;
        $this->_login = $processor_data['processor_params']['login'];
        $this->_password = $processor_data['processor_params']['password'];
        $this->_terminal = $processor_data['processor_params']['terminal'];
        $this->_autocharge = ($processor_data['processor_params']['autocharge']==1)?1:0;

        if ($processor_data['processor_params']['mode'] == 'test') {
            $this->_url = rtrim($processor_data['processor_params']['test_api_url'],"/");
        } else {
            $this->_url = rtrim($processor_data['processor_params']['api_url'],"/");
        }
        
    }

    public function getIsoMessage($operation, $response)
    {
        
        $result = false;
        if($this->ifset($response['orders'][0]["operations"])){
            foreach ($response['orders'][0]["operations"] as $operationData) {
                if($operationData['type'] == $operation && $this->ifset($operationData['iso_response_code'])){
                   $result = $this->ifset($this->codes[$operationData['iso_response_code']]);                
                }
            }
        }
        return $result;
    }

    public function getLastIsoMessage($response)
    {
       
        if($this->ifset($response['orders'][0]["operations"])){
            $operations = $response['orders'][0]["operations"];
            $lastoperation = $operations[count($operations)-1];
            
            return $this->ifset($this->codes[$lastoperation['iso_response_code']]);
        }
        return false;
    }

    private $curl_codes = [
        0=> [
            "tag" => "CURLE_OK",
            "description" => "Curl работает без ошибки",
            "short_description" => "ОК"
        ],
        1=> [
            "tag" => "CURLE_UNSUPPORTED_PROTOCOL",
            "description" => "Протокол, который вы передали в url не поддерживается, по каким-либо причинам (может быть не актуальная версия curl или не верно определён PATH)",
            "short_description" => "Протокол не поддерживается"
        ],
        2=> [
            "tag" => "CURLE_FAILED_INIT",
            "description" => "Проблема с инициализацией кода, которая может быть связанна с не установкой необходимых пакетов.",
            "short_description" => "Проблема с инициализацией"
        ],
        3=> [
            "tag" => "CURLE_URL_MALFORMAT",
            "description" => "Неверно передан URL. Необходимо проверить url, который вы передаёте libcurl",
            "short_description" => "Неверный URL"
        ],
        4=> [
            "tag" => "CURLE_NOT_BUILT_IN",
            "description" => "Функция, протокол или параметры, которые вы вызываете не включены в библиотеку CURL.",
            "short_description" => "Функция не поддерживается"
        ],
        5=> [
            "tag" => "CURLE_COULDNT_RESOLVE_PROXY",
            "description" => "Не возможна работа с Proxy. Быстрее всего он просто не правильно настроен. Вам необходимо обратиться к системному администратору.",
            "short_description" => "Не возможна работа с Proxy"
        ],
        6=> [
            "tag" => "CURLE_COULDNT_RESOLVE_HOST",
            "description" => "К удалённому хосту доступ не разрешен. Необходимо настроить этот доступ. Не забудьте добавить хост в DNS.",
            "short_description" => "Запрещен доступ к удаленному хосту"
        ],
        7=> [
            "tag" => "CURLE_COULDNT_CONNECT",
            "description" => "Не удалось подключиться к хосту или прокси серверу. Проверьте не блокирует ли брандмауэр.",
            "short_description" => "Не удалось подключиться к серверу"
        ],
        8=> [
            "tag" => "CURLE_FTP_WEIRD_SERVER_REPLY (CURLE_WEIRD_SERVER_REPLY)",
            "description" => "CURL не смог разобрать ваш отправленный URL",
            "short_description" => "Неверный формат URL"
        ],
        9=> [
            "tag" => "CURLE_REMOTE_ACCESS_DENIED",
            "description" => "Отказ в доступе к удалённому каталогу. Это может быть связанно с тем, что происходит проверка сертификата.",
            "short_description" => "Доступ запрещен"
        ],
        18 => [
            "tag" => "CURLE_PARTIAL_FILE",
            "description" => "Размер передаваемого файла и полученного не совпадают. Проверьте если существует стабильное соединение. Выполните telnet или ping и проанализируйте.",
            "short_description" => "Размер файла не совпадает"
        ],
        22 => [
            "tag" => "CURLE_HTTP_RETURNED_ERROR",
            "description" => "Эта ошибка появляется тогда, когда параметр CURLOPT_FAILONERROR установлен в значение TRUE, а HTTP-сервер возвращает код ошибки > = 400",
            "short_description" => "HTTP ERROR"
        ],
        23 => [
            "tag" => "CURLE_WRITE_ERROR",
            "description" => "Ошибка при записи полученных данных в файл.",
            "short_description" => "Ошибка записи"
        ],
        26 => [
            "tag" => "CURLE_READ_ERROR",
            "description" => "Ошибка при чтении файла или появляется при обратном вызове чтения. Это может быть связанно с ошибками в локальном диске, повреждении файла.",
            "short_description" => "Ошибка чтения"
        ],
        27 => [
            "tag" => "CURLE_OUT_OF_MEMORY",
            "description" => "Ошибка, которая появляется, когда требует для своей работы больше памяти",
            "short_description" => "Недостаточно памяти"
        ],
        28 => [
            "tag" => "CURLE_OPERATION_TIMEDOUT",
            "description" => "Time-out выполнения операции. При отправлении запроса CURL есть параметр CURLOPT_TIMEOUT",
            "short_description" => "Time-out выполнения операции"
        ],
        33 => [
            "tag" => "CURLE_RANGE_ERROR",
            "description" => "Сервер, на который вы отсылаете запрос не поддерживает такие запросы",
            "short_description" => "Сервер не поддерживает запрос"
        ],
        34 => [
            "tag" => "CURLE_HTTP_POST_ERROR",
            "description" => "Ошибка при отправке CURL методом post, если не правильно переданы параметры или запрос построен не верно.",
            "short_description" => "Неверный запрос"
        ],
        35 => [
            "tag" => "CURLE_SSL_CONNECT_ERROR",
            "description" => "Ошибка произошла на уровне SSL / TLS приветствия. Это может быть связано с авторизацией или другими видами проверки",
            "short_description" => "Ошибка SSL содединения"
        ],
        41 => [
            "tag" => "CURLE_FUNCTION_NOT_FOUND",
            "description" => "Функция CURL, которую вы пытаетесь вызвать, не найдена. Проверьте пакеты и зависимости, если они правильно установлены.",
            "short_description" => "Функция не найдена"
        ],
        42 => [
            "tag" => "CURLE_ABORTED_BY_CALLBACK",
            "description" => "Ошибка появляется когда обратный вызов вернул “abort”",
            "short_description" => "Операция прервана"
        ],
        43 => [
            "tag" => "CURLE_BAD_FUNCTION_ARGUMENT",
            "description" => "Ошибка появляется когда вызываемая функция имеет неверные аргументы",
            "short_description" => "Неверные параметры"
        ],
        45 => [
            "tag" => "CURLE_INTERFACE_FAILED",
            "description" => "Ошибка интерфейса. Необходимо указать, какой интерфейс использовать для исходного IP-адреса исходящих соединений с помощью CURLOPT_INTERFACE.",
            "short_description" => "Ошибка интерфейса"
        ],
        47 => [
            "tag" => "CURLE_TOO_MANY_REDIRECTS",
            "description" => "Эта ошибка возникает когда количество перенаправлений превышает установленный лимит в CURLOPT_MAXREDIRS",
            "short_description" => "Превышено количество перенапралений"
        ],
        48 => [
            "tag" => "CURLE_UNKNOWN_OPTION",
            "description" => "Опция, которую вы пытаетесь использовать неопределенна",
            "short_description" => "Опция не определена"
        ],
        52 => [
            "tag" => "CURLE_GOT_NOTHING",
            "description" => "С сервера ничего не вернулось, что является также ошибкой",
            "short_description" => "Данные не получены"
        ],
        53 => [
            "tag" => "CURLE_SSL_ENGINE_NOTFOUND",
            "description" => "Ошибка, в результате не нахождения SSL  кодировщика",
            "short_description" => "SSL шифратор не найден"
        ],
        54 => [
            "tag" => "CURLE_SSL_ENGINE_SETFAILED",
            "description" => "Не удалось установить SSL шифрование",
            "short_description" => "Не удалось установить SSL шифрование"
        ],
        55 => [
            "tag" => "CURLE_SEND_ERROR",
            "description" => "Ошибка при отправке CURL запроса",
            "short_description" => "Ошибка отправки запроса"
        ],
        56 => [
            "tag" => "CURLE_RECV_ERROR",
            "description" => "Ошибка, возникает при сбое получения данных по сети",
            "short_description" => "Сетевая ошибка"
        ],
        58 => [
            "tag" => "CURLE_SSL_CERTPROBLEM",
            "description" => "Проблема с локальным сертификатом",
            "short_description" => "Ошибка сертификата"
        ],
        59 => [
            "tag" => "CURLE_SSL_CIPHER",
            "description" => "Ошибка, при использовании указанного шифра",
            "short_description" => "Ошибка шифрования"
        ],
        60 => [
            "tag" => "CURLE_SSL_CACERT",
            "description" => "Одноранговый сертификат не может быть аутентифицирован с помощью известных сертификатов CA",
            "short_description" => "Ошибка проверки сертификата"
        ],
        61 => [
            "tag" => "CURLE_BAD_CONTENT_ENCODING",
            "description" => "При передаче данных кодировка не распознана.",
            "short_description" => "Ошибка кодировки"
        ],
        62 => [
            "tag" => "CURLE_LDAP_INVALID_URL",
            "description" => "Неверный URL LDAP",
            "short_description" => "Неверный URL LDAP"
        ],
        63 => [
            "tag" => "CURLE_FILESIZE_EXCEEDED",
            "description" => "Ошибка, возникающая при превышении максимального размера файла",
            "short_description" => "Превышен максимальный размер файла"
        ],
        64 => [
            "tag" => "CURLE_USE_SSL_FAILED",
            "description" => "Ошибка при использовании SSL сертификата",
            "short_description" => "Ошибка использования SSL сертификата"
        ],
        65 => [
            "tag" => "CURLE_SEND_FAIL_REWIND",
            "description" => "При отправке данных необходимо было выбрать данные для повторной передачи, но произошла ошибка",
            "short_description" => "Ошибка отправки повторных данных"
        ],
        66 => [
            "tag" => "CURLE_SSL_ENGINE_INITFAILED",
            "description" => "При инициализации SSL произошла ошибка",
            "short_description" => "Ошибк инициализации SSL"
        ],
        67 => [
            "tag" => "CURLE_LOGIN_DENIED",
            "description" => "Вход в систему на удалённый сервер",
            "short_description" => "Ошибка входа"
        ],
        68 => [
            "tag" => "CURLE_TFTP_NOTFOUND",
            "description" => "Не найден файл на TFTP сервере",
            "short_description" => "Не найден файл на TFTP"
        ],
        69 => [
            "tag" => "CURLE_TFTP_PERM",
            "description" => "Проблемы с правами на TFTP сервере",
            "short_description" => "Отсутствуют права доступа на TFTP"
        ],
        30 => [
            "tag" => "CURLE_REMOTE_DISK_FULL",
            "description" => "Ошибка, связанная с тем, что дисковое пространство закончилось",
            "short_description" => "Ошибка. Нехватка места на диске"
        ],
        71 => [
            "tag" => "CURLE_TFTP_ILLEGAL",
            "description" => "Недопустимая операция TFTP",
            "short_description" => "Недопустимая операция TFTP"
        ],
        72 => [
            "tag" => "CURLE_TFTP_UNKNOWNID",
            "description" => "Неизвестный идентификатор передачи TFTP",
            "short_description" => "Неизвестный идентификатор передачи TFTP"
        ],
        73 => [
            "tag" => "CURLE_REMOTE_FILE_EXISTS",
            "description" => "Файл не может быть перезаписан, так как уже перезаписан",
            "short_description" => "Файл не может быть перезаписан"
        ],
        74 => [
            "tag" => "CURLE_TFTP_NOSUCHUSER",
            "description" => "Эта ошибка никогда не должна возвращаться правильно работающим TFTP-сервером.",
            "short_description" => "Ошибка сервера TFTP"
        ],
        75 => [
            "tag" => "CURLE_CONV_FAILED",
            "description" => "В результате преобразования символом произошла ошибка",
            "short_description" => "Ошибка преобразования"
        ],
        76 => [
            "tag" => "CURLE_CONV_REQD",
            "description" => "При регистрации обратного вызова произошла ошибка",
            "short_description" => "Ошибк регистрации обратного вызова"
        ],
        77 => [
            "tag" => "CURLE_SSL_CACERT_BADFILE",
            "description" => "Проблема с чтением сертификата SSL CA",
            "short_description" => "Ошибка чтения сертификата SSL CA"
        ],
        78 => [
            "tag" => "CURLE_REMOTE_FILE_NOT_FOUND",
            "description" => "Запрашиваемый ресурс на удалённом сервере не найден",
            "short_description" => "Запрашиваемый ресурс не найден"
        ],
        79 => [
            "tag" => "CURLE_SSH",
            "description" => "Во время сеанса SSH произошла неопределенная ошибка.",
            "short_description" => "Ошибка SSH"
        ],
        80 => [
            "tag" => "CURLE_SSL_SHUTDOWN_FAILED",
            "description" => "Ошибка при неудачном завершении соединения SSL",
            "short_description" => "Ошибка SSL содединения"
        ],
        81 => [
            "tag" => "CURLE_AGAIN",
            "description" => "Этот код возврата появляется только из curl_easy_recv и curl_easy_send",
            "short_description" => "Сокет не готов, попробуйте еще раз"
        ],
        82 => [
            "tag" => "CURLE_SSL_CRL_BADFILE",
            "description" => "Не удалось загрузить файл CRL",
            "short_description" => "Не удалось загрузить файл CRL"
        ],
        83 => [
            "tag" => "CURLE_SSL_ISSUER_ERROR",
            "description" => "Определенный код ошибки (CURLE_SSL_ISSUER_ERROR) определяется с параметром, который возвращается, если настройка сеанса SSL / TLS",
            "short_description" => "Не удалось получить сертификат эмитента"
        ],
        84 => [
            "tag" => "CURLE_FTP_PRET_FAILED",
            "description" => "Сервер FTP не понимает команду PRET или не поддерживает данный аргумент",
            "short_description" => "Команда PRET не поддерживается"
        ],
        85 => [
            "tag" => "CURLE_RTSP_CSEQ_ERROR",
            "description" => "Несоответствие чисел RTSP CSeq",
            "short_description" => "Несоответствие чисел RTSP CSeq"
        ],
        86 => [
            "tag" => "CURLE_RTSP_SESSION_ERROR",
            "description" => "Несоответствие идентификаторов сеансов RTSP",
            "short_description" => "Несоответствие идентификаторов сеансов RTSP"
        ],
        87 => [
            "tag" => "CURLE_FTP_BAD_FILE_LIST",
            "description" => "Невозможно проанализировать список файлов FTP (во время загрузки по шаблону FTP).",
            "short_description" => "Ошибка списка файлов FTP"
        ],
        88 => [
            "tag" => "CURLE_CHUNK_FAILED",
            "description" => "Чанк обратного вызова сообщил об ошибке",
            "short_description" => "Ошибка при обратном вызове фрагмента"
        ],
        89 => [
            "tag" => "CURLE_NO_CONNECTION_AVAILABLE",
            "description" => "Нет доступного соединения, сеанс будет поставлен в очередь.",
            "short_description" => "Нет доступного соединения"
        ],
        90 => [
            "tag" => "CURLE_SSL_PINNEDPUBKEYNOTMATCH",
            "description" => "Не удалось сопоставить закрепленный ключ, указанный в CURLOPT_PINNEDPUBLICKEY",
            "short_description" => "Не удалось сопоставить закрепленный ключ"
        ],
        91 => [
            "tag" => "CURLE_SSL_INVALIDCERTSTATUS",
            "description" => "Статус вернул ошибку при запросе с CURLOPT_SSL_VERIFYSTATUS",
            "short_description" => "Статус возвращен с ошибкой"
        ],
        92 => [
            "tag" => "CURLE_HTTP2_STREAM",
            "description" => "Ошибка потока в слое кадрирования HTTP / 2",
            "short_description" => "Ошибка кадрирования HTTP"
        ],
        93 => [
            "tag" => "CURLE_RECURSIVE_API_CALL",
            "description" => "Функция API была вызвана из обратного вызова",
            "short_description" => "Ошибка вызова API"
        ],
        94 => [
            "tag" => "CURLE_AUTH_ERROR",
            "description" => "Функция аутентификации вернула ошибку.",
            "short_description" => "Ошибка аутентификации"
        ],
        95 => [
            "tag" => "CURLE_HTTP3",
            "description" => "На уровне HTTP / 3 была обнаружена проблема. Это несколько общее и может быть одной из нескольких проблем, подробности см. В Буфере ошибок.",
            "short_description" => "Ошибка HTTP"
        ],
        96 => [
            "tag" => "CURLE_QUIC_CONNECT_ERROR",
            "description" => "Ошибка подключения QUIC. Эта ошибка может быть вызвана ошибкой библиотеки SSL. QUIC - это протокол, используемый для передачи HTTP / 3.",
            "short_description" => "Ошибка подключения QUIC"
        ],
    ];

    private $codes = [
        "00" => "Одобрено и завершено",
        "01" => "Авторизация отклонена, обратиться в банк-эмитент",
        "02" => "Авторизация отклонена, обратиться в банк-эмитент (специальное условие)",
        "03" => "Незарегистрированная торговая точка или агрегатор платежей",
        "04" => "Авторизация отклонена, изъять карту по требованию банка-эмитента без указания причин",
        "05" => "Авторизация отклонена, оплату не проводить",
        "06" => "Общая ошибка, повторить операцию",
        "07" => "Изъять карту по требованию банка-эмитента (специальное условие)",
        "08" => "Обслуживать с идентификацией по документу и подписи либо отменить всю операцию",
        "09" => "Запрос обрабатывается",
        "10" => "Одобрено на неполную сумму",
        "11" => "Одобрено (VIP)",
        "12" => "Недействительная транзакция, ошибка в сети, повторить операцию",
        "13" => "Неправильно введена сумма",
        "14" => "Недействительный номер карты",
        "15" => "Узел банка-эмитента не найден в сети",
        "16" => "Одобрено",
        "17" => "Отмена заказа клиентом",
        "18" => "Оспариваемая транзакция",
        "19" => "Повторите операцию",
        "20" => "Неверный формат ответа",
        "21" => "Действия не совершены (не совпали данные)",
        "22" => "Подозрение на ошибку",
        "23" => "Неприемлимая комиссия за транзакцию",
        "24" => "Обновление файла не поддерживается получателем",
        "25" => "Запись отсутствует",
        "26" => "Обновление дубликата записи, замена старой записи",
        "27" => "Ошибка обновления редактирования поля",
        "28" => "Нет ответа, файл временно недоступен",
        "29" => "Ошибка обновления файла, свяжитесь с банком эквайером",
        "30" => "Неправильный формат, необходим повтор",
        "31" => "Эмитент не найден в платежной системе",
        "32" => "Частично завершено",
        "33" => "Истек срок действия карты, изъять карту по требованию банка-эмитента",
        "34" => "Подозрение на мошенничество",
        "35" => "Изъять Карту: свяжитесь с обслуживающим банком",
        "36" => "Изъять Карту: Карта имеет ограничения",
        "37" => "Изъять Карту: позвоните в службу безопасности банка",
        "38" => "Изъять Карту: превышено число попыток ввода PIN-код",
        "39" => "Нет кредитного счета клиента",
        "40" => "Запррашиваемая функция не поддерживается",
        "41" => "Карта утеряна, изъять",
        "42" => "Изъять карту, карта утеряна",
        "43" => "Карта украдена, изъять",
        "44" => "Инвестиционный счет отсутствует",
        "45" => "Зарезервировано",
        "46" => "Зарезервировано",
        "47" => "Зарезервировано",
        "48" => "Зарезервировано",
        "49" => "Зарезервировано",
        "50" => "Не возобнолять",
        "51" => "Недостаточно средств на счете",
        "52" => "Нет расчетного/указанного счета клиента",
        "53" => "Нет накопительного счета клиента",
        "54" => "Истек срок действия карты, изъятию не подлежит",
        "55" => "Неверный PIN",
        "56" => "Карта не найдена",
        "57" => "Данный тип транзакции не предусмотрен для предъявленной карты",
        "58" => "Данный тип транзакции не предусмотрен для терминала",
        "59" => "Подозрение на мошенничество",
        "60" => "Отказ: свяжитесь с  банком эквайером",
        "61" => "Сумма авторизации превысила расходный лимит по карте",
        "62" => "Неверный сервисный код, запрещенная карта, изъятию не подлежит",
        "63" => "Отказ: по соображениям безопасности",
        "64" => "Сумма отмены авторизации отлична от суммы оригинальной авторизации",
        "65" => "Превышен лимит расходных операций по счету",
        "66" => "Позвоните в службу безопасности банка",
        "67" => "Карта изъята в банкомате",
        "68" => "Слишком поздно получен ответ из сети, необходим повтор",
        "69" => "Зарезервировано",
        "70" => "Неверная транзакция, обратитесь к эмитенту",
        "71" => "Отказ, ПИН не изменен",
        "72" => "Зарезервировано",
        "73" => "Зарезервировано",
        "74" => "Зарезервировано",
        "75" => "Число неправильно введенных PIN-кодов превысило разрешенное количество",
        "76" => "Число неправильно введенных PIN-кодов достигло разрешенного количества",
        "77" => "Действия не совершены (неполные данные), необходим откат или повтор",
        "78" => "Нет счета",
        "79" => "Операция уже отменена",
        "80" => "Сетевая ошибка",
        "81" => "Ошибка удаленной сети (VISA)/ошибка в шифре PIN (MC)",
        "82" => "Тайм-аут при соединении с узлом эмитента (MC)/неправильный CVV (VISA)",
        "83" => "Транзакция не удалась",
        "84" => "Превышено время ожидания по преавторизации",
        "85" => "Нет основания для отказа",
        "86" => "Невозможно проверить PIN – ошибка сети",
        "87" => "Разрешено только утверждениие покупки",
        "88" => "Ошибка шифрования PIN – ошибка сети",
        "89" => "Ошибка идентификации – ошибка сети",
        "90" => "Cutoff is in progress",
        "91" => "Нет связи с банком эмитентом – ошибка сети",
        "92" => "Неудачный запрос, маршрутизация невозможна – ошибка сети",
        "93" => "Транзакция не может быть завершена – эмитент отклонил авторизацию из-за нарушения правил",
        "94" => "Дублирование транзакции",
        "95" => "Ошибка сверки/авторизация не найдена",
        "96" => "Общая неисправность системы",
        "97" => "Зарезервировано",
        "98" => "Зарезервировано",
        "99" => "Зарезервировано",
        "101" => "Цепь не найдена",
        "102" => "Неверная цепь",
        "103" => "Многократная корректировка",
        "111" => "Отсутствует BIN карты",
        "112" => "Данный тип карты не обслуживается на устройстве",
        "113" => "Недопустимая операция для карты",
        "115" => "Запрошенная функция не поддерживается",
        "117" => "Подозрительная операция",
        "119" => "Данный БИН карты не обслуживается на устройстве",
        "120" => "Карта не обслуживается на устройстве",
        "121" => "Повторный запрос",
        "122" => "Предыдущий документ не найден",
        "123" => "Неверная сумма отмены",
        "124" => "Истек срок захвата",
        "125" => "Недопустимая сумма захвата",
        "126" => "Неверный формат ПИН блока",
        "128" => "Нет доступных для использования коммуникационных ключей",
        "129" => "Ошибка буфера ключа операции",
        "130" => "Недопустимый ID терминала",
        "131" => "Неверные атрибуты транзакции",
        "132" => "Транзакция не сверена",
        "133" => "Транзакция уже отменена",
        "140" => "В ответе отсутствует поле 39",
        "141" => "Получено неожидаемое поле 39",
        "142" => "Канал назначения не работает",
        "143" => "Запрос на проверку отклонено биллинговым каналом",
        "144" => "Запрос на платеж отклонен биллинговым каналом",
        "145" => "Авторизации по кредитной операции отклонена",
        "146" => "Использование карты для международных переводов запрещено",
        "147" => "Транзакция отклонена на терминале",
        "148" => "Токенизация недоступна для карты",
        "149" => "Invalid Resolution Method ID",
        "160" => "Аппаратная/Программная ошибка устройства",
        "161" => "Неверный статус у устройства",
        "162" => "Неизвестное сообщение о состоянии",
        "163" => "Ошибка ответа HSM",
        "164" => "Команда отклонена устройством",
        "165" => "Ошибка системы авторизации",
        "166" => "Команда прервана",
        "167" => "Ошибка записи ISO лога",
        "168" => "Field Mapper internal Error",
        "169" => "Не настроен лимит",
        "170" => "Ключ аутентификации сообщения не определен",
        "171" => "Отсутствует поле аутентификации сообщения",
        "172" => "Ошибка проверки MAC",
        "173" => "Ошибка формирования MAC",
        "174" => "Аппаратная/программная ошибка безопасности",
        "175" => "Таймаут канала модуля безопасности",
        "176" => "Неактивный линк. Устройство не на связи",
        "177" => "Устройство не совершает транзакцию",
        "178" => "Устройство уже совершает транзакцию",
        "179" => "Превышено время ожидания ответа от устройства",
        "180" => "Сумма слишком маленькая. Выдача невозможна",
        "181" => "Сумма слишком большая.  Выдача невозможна",
        "182" => "Сумма содержит копейки",
        "183" => "Выдача невозможна",
        "185" => "Недопустимая сумма",
        "188" => "Клиент не забрал деньги",
        "189" => "Для устройства не установлено рабочее время",
        "190" => "Устройство не настроено или недопустимо",
        "191" => "Недопустимый контракт устройства",
        "192" => "Устройство не в файле",
        "193" => "Запрошенная операция отсутствует в файле для этого устройства",
        "194" => "Операция запрещена для устройства",
        "195" => "Недопустимая валюта для устройства",
        "196" => "Неисправность внутренней системы",
        "198" => "Ошибка формата трека 2",
        "199" => "Ошибка преобразование PIN блока",
        "200" => "Держатель карты не забрал карту",
        "201" => "Устройство подключено к другому контроллеру",
        "203" => "Истек срок действия исходного контракта",
        "214" => "Карта продавца отсутствует в файле",
        "254" => "Закончился срок действия карты продавца",
        "257" => "Контракт карты продавца не одобрен",
        "258" => "Отсутствует контракт устройства",
        "261" => "Превышен лимит суммы на устройстве",
        "262" => "Отклонены некоторые документы в этом Batch- файле. ",
        "263" => "Wrong Invoice Party",
        "265" => "Превышен лимит частоты операций на устройстве",
        "270" => "САТ операция не совместима с МСС 6011",
        "271" => "Атрибуты транзакции для чиповой карты присутствуют, но Сервисный код не принадлежит интегральной схеме",
        "272" => "Атрибуты транзакции для чиповой карты присутствуют, но Сервисный код не принадлежит интегральной схеме (Предупреждение)",
        "361" => "Превышен лимит на сумму",
        "365" => "Привышен лимит повторений",
        "405" => "Требуется Строгая Аутентификация Клиента",
        "457" => "Кэшбэк отключен",
        "461" => "Превышен Лимит суммы кэшбека",
    ];

    private $statuses = [
        'rejected' => 'Отклонен',
        'declined' => 'Отклонен',
        'fraud' => 'Фрод',
        'error' => 'Ошибка',
        'refunded' => 'Произведен возврат',
        'charged' => 'Оплачен',
        'authorized' => 'Средства захолдированы',
        'reversed' => 'Отменен',
        'new' => 'Новый'

    ];

    public function create($order_info, $protocol = 'current')
    {
        
        $data = [
            /* Обязательные параметры */
            "amount" => $this->convertSum($order_info['total']), // Сумма заказа
        
            /* Необязательные параметры */
            "currency" => "RUB", // Валюта заказа
            "merchant_order_id" => $order_info['order_id'], // Идентификатор заказа в системе мерчанта
            "description" => 'Заказ № '.$order_info['order_id'], // Описание заказа - выводится в заголовке формы оплаты
        
            "client" => [ // Данные о клиенте
                "address" => $order_info['b_address'],
                "city" => $order_info['b_city'],
                "country" =>$order_info['b_country'],
                "email"  => $order_info['email'],
                "name" => $order_info['b_lastname']. ' '. $order_info['b_firstname'],
                "phone" => $order_info['b_phone '],
                "state" => $order_info['b_state'],
                "zip" => $order_info['order_id']
            ],
        
            "location" => [ // Местоположение клиента
                "ip" => $order_info['ip_address'], // IP-адрес
            ],    
            "options" => [
                "expiration_timeout" => $this->_processor_data['processor_params']['sessiontimeout'], // Время сессии
                "force3d" => '1', // Принудительное направление в 3-D Secure
                "auto_charge" =>  $this->_autocharge, //Провести операцию Charge (используется (для одностадийных платежей)
                "language" =>  $order_info['lang_code'], // Язык платежной формы
                "return_url" => fn_url("payment_notification.result?payment=twocan&ordernumber=".$order_info['order_id'], AREA, $protocol), // URL для перенаправления клиента после оплаты
                // "template" => $this->_processor_data['processor_params']['template'], // Шаблон платежной формы
                //"mobile" => '1', // Мобильный шаблон
                "terminal" => $this->_terminal// Терминал
            ]            
        ];  

        if($this->_processor_data['processor_params']['template'])  $data["options"]["template"] = $this->_processor_data['processor_params']['template'];
        if($this->_processor_data['processor_params']['expiration_timeout'])  $data["options"]["expiration_timeout"] =$this->_processor_data['processor_params']['sessiontimeout'];
       
        $extra = array(
            'basic_auth'=> [ $this->_login, $this->_password],          
            'headers' => [
                'Content-Type:application/json',
            ],
        );

        $http = new Http();
        $this->_response = $http::post($this->_url . '/orders/create', json_encode($data), $extra);
        
        if(!$this->_response){
            $this->_error_code = "Connection error";
            $this->_error_text = $this->getCurlErrorText($http->getErrorFields());
        }else{
            $this->_response = json_decode($this->_response, true);
       
            $this->checkErrors($http->getStatus());
            
            preg_match("/\sLocation:\s([^\s]*)/", $http->getHeaders(), $matches);
            if($matches){
                $this->_response['redirect_url'] = $this->ifset($matches[1]);
            }    
        }            

        return $this->_response;
    }

    private function getCurlErrorText($curl_error_fields)
    {
        $curl_error_code = $curl_error_fields['error_number'];

        if(array_key_exists($curl_error_code, $this->curl_codes)){
            $curl_error_text = $this->curl_codes[$curl_error_code]["short_description"];
        }else{
            $curl_error_text = "Неизвестная ошибка";
        }
        return self::CONNECTION_ERROR_TITLE.$curl_error_text;
    }

    public function charge($order_id, $amount, $protocol = 'current')
    {

        
        $data = [
            /* Обязательные параметры */
            "amount" => $this->convertSum($amount), // Сумма заказа        
        ];  
       
        $extra = array(
            'basic_auth'=> [ $this->_login, $this->_password],          
            'headers' => [
                'Content-Type:application/json',
            ],
        );

        $http = new Http();
        $this->_response = $http::put($this->_url . '/orders/'. $order_id .'/charge', json_encode($data), $extra);
        if(!$this->_response){
            $this->_error_code = "Connection error";
            $this->_error_text = $this->_error_text = $this->getCurlErrorText($http->getErrorFields());
        }else{
            $this->_response = json_decode($this->_response, true);
            $this->checkErrors($http->getStatus());
        }
        
        return $this->processResponse();
    }

    public function refund($order_id, $amount, $protocol = 'current')
    {

        $data = [
            /* Обязательные параметры */
            "amount" => $this->convertSum($amount), // Сумма заказа
        
        ];  
       
        $extra = array(
            'basic_auth'=> [ $this->_login, $this->_password],          
            'headers' => [
                'Content-Type:application/json',
            ],
        );

        $http = new Http();
        $this->_response = $http::put($this->_url . '/orders/'. $order_id .'/refund', json_encode($data), $extra);
        if(!$this->_response){
            $this->_error_code = "Connection error";
            $this->_error_text = $this->_error_text = $this->getCurlErrorText($http->getErrorFields());
        }else{
            $this->_response = json_decode($this->_response, true);
            $this->checkErrors($http->getStatus());
        }
        
        return $this->processResponse();
    }

    public function cancel($order_id, $amount, $protocol = 'current')
    {
        $data = [
            /* Обязательные параметры */
            "amount" => $this->convertSum($amount), // Сумма заказа
        
        ];  
        $extra = array(
            'basic_auth'=> [ $this->_login, $this->_password],          
            'headers' => [
                'Content-Type:application/json',
            ],
        );

        $http = new Http();
        $this->_response = $http::put($this->_url . '/orders/'. $order_id .'/cancel', json_encode($data), $extra);

        if(!$this->_response){
            $this->_error_code = "Connection error";
            $this->_error_text = $this->_error_text = $this->getCurlErrorText($http->getErrorFields());
        }else{
            $this->_response = json_decode($this->_response, true);
            $this->checkErrors($http->getStatus());
        }
        
        return $this->processResponse();
    }
    
    
    protected function parseErrors($response)
    {
        $message = sprintf('%s', $this->ifset($response, 'failure_message', 'Error'));
        $errors = $this->ifset($response['errors'],array());
        foreach($errors as $num => $error){
            $message .= sprintf(
                ' - %s: %s', 
                $num,
                $this->ifset($error['message'])
            );
        }
        return $message;
    }

    public function &ifset(&$var, $def=null)
    {
        if (func_num_args() > 2) {
            $keys = func_get_args();
            $def = array_pop($keys);
            $arr = array_shift($keys);
        } else {
            $keys = array();
            $arr = $var;
        }

        while($keys) {
            $key = array_shift($keys);
            if (is_object($arr) && !$arr instanceof ArrayAccess) {
                return $def;
            } else if (!isset($arr[$key])) {
                return $def;
            } else {
                $arr = $arr[$key];
            }
        }

        if (isset($arr)) {
            return $arr;
        }
        return $def;
    }

    public function getOrder($transaction_id)
    {

        $extra = array(
            'basic_auth'=> [ $this->_login, $this->_password],          
            'headers' => [
                'Content-Type:application/json',
            ],
        );

        $apiurl = sprintf($this->_url . '/orders/%s?expand=card,client,location,custom_fields,issuer,secure3d,operations.cashflow', $transaction_id);
        $http = new Http();
        $this->_response = $http::get( $apiurl, array(), $extra);
       
        if(!$this->_response){
            $this->_error_code = "Connection error";
            $this->_error_text = $this->_error_text = $this->getCurlErrorText($http->getErrorFields());
        }else{
            $this->_response = json_decode($this->_response, true);
            $this->checkErrors($http->getStatus());
        }
        
        return $this->processResponse();
    }

    private function checkErrors($httpStatus)
    {
        if ((!empty($this->_response['errors']) || !empty($this->_response['failure_message']) ) && !in_array($httpStatus, ['200', '201'])) {
            $this->_error_code = $this->_response['failure_type'];
            $this->_error_text = $this->parseErrors($this->ifset($this->_response));
        }else{
            $this->_error_code = "";
            $this->_error_text = "";
        }
    }

    public function processResponse()
    {
        
        if ($this->isError()) {
            $pp_response = array(
                'order_status' => OrderStatuses::FAILED,
                'reason_text' => $this->getErrorText()
            );
           
        } else {
            switch ($this->_response['orders'][0]['status']) {
                case 'rejected':
                case 'declined':
                case 'fraud':
                case 'error':
                    $pp_response = array(
                        'order_status' => OrderStatuses::FAILED,
                        'twocan_status' => $this->_response['orders'][0]['status'],
                        'twocan_charged' => $this->_response['orders'][0]['amount_charged'],
                        'twocan_refunded' => $this->_response['orders'][0]['amount_refunded'],
                        'twocan_status' => $this->_response['orders'][0]['status'],
                        'reason_text' => $this->_response['orders'][0]['failure_message']
                    );
                    
                    $lastOperationIsoMessage = $this->getLastIsoMessage($this->_response);
                    if($lastOperationIsoMessage){
                        $pp_response['reason_text'] .= ($pp_response['reason_text']?' - ':'').$lastOperationIsoMessage;
                    }
                    break;
                case 'refunded':
                case 'charged':
                case 'authorized':
                case 'reversed':
                    
                    $pp_response = [
                        'order_status' => $this->_processor_data['processor_params']['statuses'][$this->_response['orders'][0]['status']],
                        'amount' => $this->_response['orders'][0]['amount'],
                        'twocan_charged' => $this->_response['orders'][0]['amount_charged'],
                        'twocan_refunded' => $this->_response['orders'][0]['amount_refunded'],
                        'twocan_status' => $this->_response['orders'][0]['status'],
                        'reason_text' => $this->ifset($this->statuses[$this->_response['orders'][0]['status']], 'Неизвестно')
                    ];
                    if($this->_response['orders'][0]['status'] == "refunded" && ((float)$this->_response['orders'][0]['amount_charged'] > (float)$this->_response['orders'][0]['amount_refunded'])){
                        $pp_response['reason_text'] = "Произведен частичный возврат";
                        unset($pp_response['order_status']);
                    }
                    break;
                case 'new':
                    $pp_response = array(    
                        'twocan_charged' => $this->_response['orders'][0]['amount_charged'],
                        'twocan_refunded' => $this->_response['orders'][0]['amount_refunded'],
                        'twocan_status' => $this->_response['orders'][0]['status'],        
                        'amount' => $this->_response['orders'][0]['amount'],            
                        'reason_text' => $this->ifset($this->statuses[$this->_response['orders'][0]['status']], 'Неизвестно')
                    );
                    break;
                default:
                    $pp_response = array(
                        //'order_status' => OrderStatuses::FAILED,
                        
                        'reason_text' => 'Неизвестный статус заказа'
                    );
                    break;
            }
        }
        return $pp_response;
    }

    public function getErrorCode()
    {
        return $this->_error_code;
    }

    public function getErrorText()
    {
        
        return $this->_error_text;
    }

    public function getResponse()
    {
        return $this->_response;
    }

    public function isError()
    {
        return !empty($this->_error_code);
    }

    public static function writeLog($data, $file = 'sberbank.log')
    {
        $path = fn_get_files_dir_path();
        fn_mkdir($path);
        $file = fopen($path . $file, 'a');

        if (!empty($file)) {
            fputs($file, 'TIME: ' . date('Y-m-d H:i:s', TIME) . "\n");
            fputs($file, fn_array2code_string($data) . "\n\n");
            fclose($file);
        }
    }

    public static function convertSum($price)
    {
        if (CART_PRIMARY_CURRENCY != 'RUB') {
            $price = fn_format_price_by_currency($price, CART_PRIMARY_CURRENCY, 'RUB');
        }

        $price = str_replace(',','.',$price);
        
        $price = floatval(preg_replace('/[^0-9.]/', '', $price));       
        
        $price = fn_format_rate_value($price, 'F', 2, '.', '', '');

        return $price;
    }
}
