<?php
use Tygh\Payments\Processors\Twocan;
use Tygh\Enum\OrderDataTypes;
use Tygh\Enum\OrderStatuses;

if (defined('PAYMENT_NOTIFICATION')) {
    
    $order_id = 0;
    if (!empty($_REQUEST['ordernumber'])) {
        $order_id = $_REQUEST['ordernumber'];
    }

    $order_info = fn_get_order_info($order_id);
   
    
    if (empty($processor_data) && !empty($order_info)) {
        $processor_data = fn_get_processor_data($order_info['payment_id']);
    }



    // if (!empty($processor_data['processor_params']['logging']) && $processor_data['processor_params']['logging'] == 'Y') {
    //     Twocan::writeLog($_REQUEST, 'twocan_request.log');
    // }
    
    if (!empty($order_info) && ($mode == 'result')) {
        
        $pp_response = array(
            'order_status' => OrderStatuses::FAILED
        );
        

        if ($order_info['payment_info']['transaction_id'] != $_REQUEST['order_id']) {
            $pp_response['reason_text'] = __("addons.twocan.wrong_transaction_id");

        } else {
            $twocan = new Twocan($processor_data);
            $pp_response = $twocan->getOrder($order_info['payment_info']['transaction_id']);
        }
        
        fn_finish_payment($order_id, $pp_response);
        fn_order_placement_routines('route', $order_id, false);
    }

    exit;

} else {
    
    $twocan = new Twocan($processor_data);

    $response = $twocan->create($order_info);
    

    // if (!empty($processor_data['processor_params']['logging']) && $processor_data['processor_params']['logging'] == 'Y') {
    //     Twocan::writeLog($response, 'twocan.log');
    // }

    if (!$twocan->isError()) {

        $pp_response = array(
            'transaction_id' => $response['orders'][0]['id']
        );

        fn_update_order_payment_info($order_id, $pp_response);
        fn_create_payment_form($response['redirect_url'], array(), '2can&ibox', true, 'GET');

    } else {
        $pp_response['order_status'] = 'F';
        $pp_response['reason_text'] = $twocan->getErrorText();

        

        fn_finish_payment($order_id, $pp_response);
        fn_order_placement_routines('route', $order_id, false);
    }

}

