<?php
/***************************************************************************
*                                                                          *
*   (c) 2004 Vladimir V. Kalynyak, Alexey V. Vinokurov, Ilya M. Shalnev    *
*                                                                          *
* This  is  commercial  software,  only  users  who have purchased a valid *
* license  and  accept  to the terms of the  License Agreement can install *
* and use this program.                                                    *
*                                                                          *
****************************************************************************
* PLEASE READ THE FULL TEXT  OF THE SOFTWARE  LICENSE   AGREEMENT  IN  THE *
* "copyright.txt" FILE PROVIDED WITH THIS DISTRIBUTION PACKAGE.            *
****************************************************************************/

use Tygh\Registry;
use Tygh\Http;
use Tygh\Payments\Processors\Twocan;

if (!defined('BOOTSTRAP')) { die('Access denied'); }



if ($_SERVER['REQUEST_METHOD'] == 'POST') {

     switch ($mode) {
        case 'twocan_capture':
            if (!empty($_REQUEST['capture_data'])) {
                $capture_data = $_REQUEST['capture_data'];
                $order_id = $capture_data['order_id'];
        
                $order_info = fn_get_order_info($order_id);
                if (empty($processor_data) && !empty($order_info)) {
                    $processor_data = fn_get_processor_data($order_info['payment_id']);
                }
                $payment_info = $order_info['payment_info'];
                $pdata = $order_info['payment_method'];
                if (fn_check_payment_script('twocan.php', $order_id)) {
                    $twocan = new Twocan($processor_data);
                    $pp_response = $twocan->charge($payment_info['transaction_id'], $capture_data['amount']); 
                    if($pp_response['order_status'] == "F"){
                        fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                    }else{   
                    
                        if($pp_response['reason_text'] == "Order already charged"){
                            $pp_response = $twocan->getOrder($payment_info['transaction_id']);
                        }
            
                        if($pp_response['twocan_status'] == 'charged'){
                            fn_change_order_status($order_info['order_id'], $pdata['processor_params']['statuses']['charged']);
                            fn_set_notification('N', fn_get_lang_var('Notification'), $pp_response['reason_text'], "K");
                        }else{
                            fn_set_notification('W', fn_get_lang_var('warning'), $pp_response['reason_text'], "K");
                        }
            
                        fn_update_order_payment_info($order_info['order_id'], $pp_response);
                    }
        
                }
                return array(CONTROLLER_STATUS_OK, 'orders.details?order_id=' . $order_id);
            }
            break;
        case 'twocan_cancel':
            if (!empty($_REQUEST['cancel_data'])) {
                $cancel_data = $_REQUEST['cancel_data'];
                $order_id = $cancel_data['order_id'];
        
                $order_info = fn_get_order_info($order_id);
                if (empty($processor_data) && !empty($order_info)) {
                    $processor_data = fn_get_processor_data($order_info['payment_id']);
                }
                $payment_info = $order_info['payment_info'];
                $pdata = $order_info['payment_method'];
                if (fn_check_payment_script('twocan.php', $order_id)) {
                    $twocan = new Twocan($processor_data);
                    $pp_response = $twocan->cancel($payment_info['transaction_id'], $cancel_data['amount']); 
                    
                    if($pp_response['order_status'] == "F"){
                        fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                    }else{    
                        if($pp_response['twocan_status'] == 'reversed'){
                            fn_change_order_status($order_info['order_id'], $pdata['processor_params']['statuses']['reversed']);
                            fn_set_notification('N', fn_get_lang_var('Notification'), $pp_response['reason_text'], "K");
                        }else{
                            fn_set_notification('W', fn_get_lang_var('warning'), $pp_response['reason_text'], "K");
                        }
                        fn_update_order_payment_info($order_info['order_id'], $pp_response);
                    }              

                }
            
                return array(CONTROLLER_STATUS_OK, 'orders.details?order_id=' . $order_id);
            }
            break;
        case 'twocan_refund':
            if (!empty($_REQUEST['refund_data'])) {
                
                $refund_data = $_REQUEST['refund_data'];
                $order_id = $refund_data['order_id'];
        
                $order_info = fn_get_order_info($order_id);
                if (empty($processor_data) && !empty($order_info)) {
                    $processor_data = fn_get_processor_data($order_info['payment_id']);
                }
                $payment_info = $order_info['payment_info'];
                $pdata = $order_info['payment_method'];
                if (fn_check_payment_script('twocan.php', $order_id)) {
                    $twocan = new Twocan($processor_data);
                    $pp_response = $twocan->refund($payment_info['transaction_id'], $refund_data['amount']);  
                    if($pp_response['order_status'] == "F"){
                        fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                    }else{  
                        if($pp_response['reason_text'] == "Nothing to refund"){
                            $pp_response = $twocan->getOrder($payment_info['transaction_id']);
                        }
                        
                        if($pp_response['twocan_status'] == 'refunded'){
                            if((float)$pp_response['twocan_charged'] == (float)$pp_response['twocan_refunded']) {
                                fn_change_order_status($order_info['order_id'], $pdata['processor_params']['statuses']['refunded']);
                            }
                            fn_set_notification('N', fn_get_lang_var('Notification'), $pp_response['reason_text'], "K");
                        }else{
                            fn_set_notification('E', fn_get_lang_var('error'), $pp_response['reason_text'], "K");
                        }

                        if($pp_response['order_status'] == "F"){
                            fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                        }
            
                        fn_update_order_payment_info($order_info['order_id'], $pp_response);
                    }
        
                }
                return array(CONTROLLER_STATUS_OK, 'orders.details?order_id=' . $order_id);
            }
            break;
            case 'twocan_check':
                $order_id = $_REQUEST['order_id'];
        
                $order_info = fn_get_order_info($order_id);
                if (empty($processor_data) && !empty($order_info)) {
                    $processor_data = fn_get_processor_data($order_info['payment_id']);
                }
                $payment_info = $order_info['payment_info'];
                $pdata = $order_info['payment_method'];
                if (fn_check_payment_script('twocan.php', $order_id)) {
                    $twocan = new Twocan($processor_data);
                    $pp_response = $twocan->getOrder($payment_info['transaction_id']);
                    if($pp_response['order_status'] == "F"){
                        fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                    }else{  

                        if(in_array($pp_response['twocan_status'], ['refunded','charged','authorized', 'reversed'])){
                            fn_change_order_status($order_info['order_id'], $pdata['processor_params']['statuses'][$pp_response['twocan_status']]);
                            fn_set_notification('N', fn_get_lang_var('Notification'), $pp_response['reason_text'], "K");
                        }  
                        if($pp_response['order_status'] == "F"){
                            fn_set_notification('E', fn_get_lang_var('Error'), $pp_response['reason_text'], "K");
                        }     
                        fn_update_order_payment_info($order_info['order_id'], $pp_response);        
                    }
                }
                return array(CONTROLLER_STATUS_OK, 'orders.details?order_id=' . $order_id);
                
                break;
        default:
            # code...
            break;
     }
    

}

if ($mode == 'details') {
    
    $order_info = Tygh::$app['view']->getTemplateVars('order_info');



    if ($order_info && !empty($order_info['payment_method']['processor_id'])) {
        $processor_id = $order_info['payment_method']['processor_id'];
        $processor_script = db_get_field("SELECT processor_script FROM ?:payment_processors WHERE processor_id = ?i", $processor_id);

        Tygh::$app['view']->assign('processor_script', $processor_script);

        $pdata = $order_info['payment_method'];

        $pinfo = $order_info['payment_info'];
      

        $payment_info_required_fields = array(
            'twocan_refunded',
            'twocan_charged',
            'twocan_status'
        );
        foreach ($payment_info_required_fields as $field_name) {
            if (!isset($pinfo[$field_name])) {
                $pinfo[$field_name] = null;
            }
        }

        $twocan_show_refund = $twocan_show_capture = false;

        $refund_available = (float)$pinfo['twocan_charged'] - (float)$pinfo['twocan_refunded'];

        if (fn_check_payment_script('twocan.php', $order_info['order_id'])) {

            $twocan_show_refund = $twocan_show_refund || (in_array($pinfo['twocan_status'], ['charged', 'refunded']) && $refund_available > 0);
            $twocan_show_capture = ($pinfo['twocan_status'] == 'authorized');
           // $show_detailed_refund = fn_is_yandex_checkpoint_receipt_required($pdata);

           
        }
        
        Tygh::$app['view']->assign('twocan_show_capture', $twocan_show_capture);
        Tygh::$app['view']->assign('twocan_show_refund', $twocan_show_refund);
        Tygh::$app['view']->assign('twocan_refund_available', $refund_available);
       
        
        
    }
}
