<?php

if (!defined('BOOTSTRAP')) { die('Access denied'); }

function fn_twocan_install()
{
    fn_twocan_uninstall();

    $_data = array(
        'processor' => '2can&ibox',
        'processor_script' => 'twocan.php',
        'processor_template' => 'views/orders/components/payments/cc_outside.tpl',
        'admin_template' => 'twocan.tpl',
        'callback' => 'Y',
        'type' => 'P',
        'addon' => 'twocan'
    );

    db_query("INSERT INTO ?:payment_processors ?e", $_data);
}

function fn_twocan_uninstall()
{
    db_query("DELETE FROM ?:payment_processors WHERE processor_script = ?s", "twocan.php");
}

