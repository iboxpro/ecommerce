
var CGatewayApp = CGatewayApp || {};

jQuery.noConflict();
(function($){

    // --- Show/hide fields on model select.
    CGatewayApp.actionsOnModelSelect = CGatewayApp.actionsOnModelSelect || (function(){
        'use strict';

        var workModelValue = 0,
            useCertValue = 0;

        function init() {
            if ( !$('#woocommerce_cgateway_work_model').length ) {
                return;
            }

            if ( !$('#woocommerce_cgateway_use_cert').length ) {
                return;
            }

            useCertValue = getUseCertValue();
            setCertFields(useCertValue);

            $('#woocommerce_cgateway_use_cert').change(function(){
                useCertValue = getUseCertValue();
                setCertFields(useCertValue);
            });

            workModelValue = getWorkModelValue();
            setFieldsAccordingToModel(workModelValue);

            $('#woocommerce_cgateway_work_model').change(function(){
                workModelValue = getWorkModelValue();
                setFieldsAccordingToModel(workModelValue);
            });
        }
        
        function getWorkModelValue() {
            return $('#woocommerce_cgateway_work_model').val();
        }

        function setFieldsAccordingToModel(model) {
            var formTypeRowElem = $('label[for="woocommerce_cgateway_form_type"]').parent('th').parent('tr'), 
                customFormIdRowElem = $('label[for="woocommerce_cgateway_custom_form_id"]').parent('th').parent('tr'), 
                requireCardHolderRowElem = $('label[for="woocommerce_cgateway_require_card_holder"]').parent('th').parent('tr');
            
            if (model == 0 || model == 1) {
                formTypeRowElem.hide();
                customFormIdRowElem.hide();
                requireCardHolderRowElem.show();
            }
            else {
                formTypeRowElem.show();
                customFormIdRowElem.show();
                requireCardHolderRowElem.hide();
            }
        }

        function getUseCertValue() {
            if ( $('#woocommerce_cgateway_use_cert').is(":checked") ) {
                return 1;
            }
            else {
                return 0;
            }
        }

        function setCertFields(useCert) {
            var certFileElem = $('label[for="woocommerce_cgateway_cert_file"]').parent('th').parent('tr'), 
                filePathElem = $('label[for="woocommerce_cgateway_cert_file_path"]').parent('th').parent('tr'), 
                certPassElem = $('label[for="woocommerce_cgateway_cert_pass"]').parent('th').parent('tr');

            if (useCert == 1) {
                certFileElem.show();
                filePathElem.show();
                certPassElem.show();
            }
            else {
                certFileElem.hide();
                filePathElem.hide();
                certPassElem.hide();
            }
        }

        return {
            init: init
        };
    }());
    // --- on model select - END

    $(document).ready(function(){
        'use strict';
        
        CGatewayApp.actionsOnModelSelect.init();
    });

})(jQuery);
