<?php

return '
<script>
jQuery.noConflict();
(function($){
    $(document).ready(function(){
        "use strict";
        if ($(".wc-credit-card-form-card-number").length) {
            setTimeout(function(){
                $(".wc-credit-card-form-card-number").off();
                $(".wc-credit-card-form-card-number").on("keyup paste", function(e) {
                    var inputCardVal = $(this).val();
                    var newCardVal = inputCardVal.replace(/[^0-9 ]/g, "");
                    newCardVal = newCardVal.replace(/\s\s+/g, " ");
                    $(this).val(newCardVal);
                });
            }, 1000);
        }
    });
})(jQuery);
</script>
';
