<?php
/*
 * Plugin Name: Payment Gateway
 * Plugin URI:
 * Description: Payment gateway integration for WooCommerce.
 * Version: 0.0.8
 * Author: author
 * License: MIT
 * WC requires at least: 3.2.0
 * WC tested up to: 3.4.0
 */


if (!defined('ABSPATH')) exit; // exit if accessed directly

add_action('plugins_loaded', 'cgateway_payment_gateway_init');


function cgateway_payment_gateway_init()
{
    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    if (class_exists('WC_CGateway_Gateway')) {
        return;
    }

    if (!class_exists('CGateway\Order')) {
        require_once(plugin_dir_path(__FILE__) . "vendor/CGateway/Order.php");
    }
    if (!class_exists('CGateway\Client')) {
        require_once(plugin_dir_path(__FILE__) . "vendor/CGateway/Client.php");
    }

    /**
     * Add the gateway to WooCommerce
     */
    add_filter('woocommerce_payment_gateways', function($methods) {
        $methods[] = 'WC_CGateway_Gateway';
        return $methods;
    });

    /**
     * Gateway class.
     */
    class WC_CGateway_Gateway extends WC_Payment_Gateway 
    {
        /** @var boolean Whether or not logging is enabled */
        public static $log_enabled = false;

        /** @var WC_Logger Logger instance */
        public static $log = false;

        private $gatewayClient;

        const FORM_TYPE_IFRAME = 8;

        /**
        * Throw error on object clone
        *
        * @access public
        * @return void
        */
        public function __clone() {
            trigger_error('Cloning instances of the class is forbidden.');
        }

        /**
        * Disable unserializing of the class
        *
        * @access public
        * @return void
        */
        public function __wakeup() {
            trigger_error('Unserializing instances of the class is forbidden.');
        }

        public function __construct() {
            $this->id = 'cgateway';
            $this->method_title = 'CGateway';
            $this->method_description = $this->method_title . ' Payment Gateway';

            // Load the settings
            $this->init_form_fields();
            $this->init_settings();

            $this->icon = apply_filters( 'woocommerce_'. $this->id .'_gateway_icon', plugins_url('assets/images/logo.png', __FILE__) );
            $this->supports = array(
                'products', 
                'refunds'
            );

            foreach ( $this->settings as $setting_key => $value ) {
                $this->$setting_key = $value;
            }

            if ( isset($this->work_model) && $this->work_model == 1 ) {
                $this->has_fields = true; // set to true if we want payment fields to show on the checkout if doing a direct integration
                $this->supports[] = 'default_credit_card_form';
            }

            if (isset($this->sandbox) && $this->sandbox == 'yes') {
                $this->apiurl = $this->api_url_sandbox;
            }
            else {
                $this->apiurl = $this->api_url_live;
            }
            
            $this->gatewayClient = new CGateway\Client($this->apiurl);
            $this->gatewayClient->setCertParams(
                isset($this->cert_file_path) ? $this->cert_file_path : "", 
                isset($this->cert_pass) ? $this->cert_pass : "", 
                (!isset($this->use_cert) || $this->use_cert == 'yes') ? true : false 
            );
            $this->gatewayClient->setApiParams(
                $this->api_username, 
                $this->api_pass, 
                (!isset($this->verify_ssl) || $this->verify_ssl == 'no') ? false : true
            );

            if (!$this->is_valid_for_use()) {
                $this->enabled = 'no';
            }

            self::$log_enabled = $this->debug === 'yes';

            // Save settings
            if ( is_admin() ) {
                // Save administration options.
                add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
            }
            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ) );
            add_action('woocommerce_api_' . strtolower(get_class($this)), array( $this, 'check_response' ) ); // Payment listener/API hook
            add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'cgateway_order_id_display_admin_order_meta' ), 10, 1 );
            add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'cgateway_order_status_display_admin_order_meta' ), 10, 1 );
            add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'cgateway_order_updated_display_admin_order_meta' ), 10, 1 );
            
            if($this->electronic_receipt) {
                add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'cgateway_order_receipt_display_admin_order_meta' ), 10, 1 );
                add_action('woocommerce_admin_order_data_after_billing_address', array( $this, 'cgateway_order_reciept_update_admin_order_meta' ), 10, 1);             
            }


            if ( is_admin() ) {
                // add_action('save_post', array( $this, 'cgateway_charge_on_save_order' ) );
     
                add_action('woocommerce_order_status_on-hold_to_processing', array( $this, 'cgateway_change_from_onhold_to_processing' ), 10, 2 );
                add_action('woocommerce_order_status_on-hold_to_completed', array( $this, 'cgateway_change_from_onhold_to_completed' ), 10, 2 );
                add_action('woocommerce_order_status_processing_to_completed', array( $this, 'cgateway_change_from_processing_to_completed' ), 10, 2 );
            }

            add_filter('woocommerce_thankyou_order_received_text', array( $this, 'change_order_received_text' ), 10 );
            if ($this->has_fields) {
                add_filter('woocommerce_credit_card_form_fields', array( $this, 'woocommerce_credit_card_form_fields_cgateway' ), 10, 2 ); 
            }

            // Check for SSL
            if ($this->gatewayClient->getUserIp() != '127.0.0.1') {
                add_action( 'admin_notices', array( $this, 'do_ssl_check' ) );
            }

            add_action('wp_enqueue_scripts', array($this, 'current_gateway_checkout_scripts'));
            add_action('admin_footer', array($this, 'current_gateway_load_admin_js'));

            if ( isset($_GET) && !empty($_GET) ) { 
                // wc_clear_notices();
                $this->orderReceivedPageCalledByGateway($_GET);
            }
        }

        /**
         * Logging method
         * @param  string $message
         */
        public static function log($message) {
            if (self::$log_enabled) {
                $logger = wc_get_logger();
                $logger->info( $message, array( 'source' => 'cgateway' ) );
            }
        }

        
        

        /**
         * Enqueue checkout page styles, scripts.
         */
        public function current_gateway_checkout_scripts() {
            if (is_checkout()) {
                wp_enqueue_style($this->id . '-checkout', plugin_dir_url(__FILE__) . 'assets/css/styles.css', array(), '1.0.0');
            }
        }

        /**
         * Load JS for Gateway woo admin area.
        */
        public function current_gateway_load_admin_js() {
            if ( !isset($_GET['tab']) || $_GET['tab'] != 'checkout' || !isset($_GET['section']) || $_GET['section'] != $this->id ) {
                return;
            }

            wp_register_script($this->id . '-scripts', plugin_dir_url(__FILE__) . 'assets/js/scripts.js', array(), '1.0.0', true);
            wp_enqueue_script($this->id . '-scripts');
        }

        /**
         * Check if store currency is supported
         * @return bool true if currency is in supported currencies list
         */
        public function is_valid_for_use() {
            return true; // Allways true. Gateway decides on further stages.
        }

        /**
         * Admin Panel Options
         */
        public function admin_options() {
            if ($this->is_valid_for_use()) {
                parent::admin_options();
            }
            else {
                ?>
                <div class="inline error">
                    <p><strong><?php _e('Gateway Disabled', 'woocommerce'); ?></strong>: 
                    <?php // _e('CGateway does not support your store currency.', 'woocommerce'); ?>
                    </p>
                </div>
                <?php
            }
        }

        /**
         * Initialise Gateway Settings Form Fields
         *
         * @access public
         * @return void
         */
        public function init_form_fields() {
            $this->form_fields = include('form-fields.php');
			$taxes_fields = [];
            $stdRates = WC_Tax::get_rates();

            $cgateway_taxes = [
                'none' => 'None', 
                'vat' => 'VAT 0%',
				'vat20' => 'VAT 20%',
                'vat18' => 'VAT 18%',
                'vat10' => 'VAT 10%',
				'vat120' => 'VAT 20/120',
                'vat118' => 'VAT 18/118',
                'vat110' => 'VAT 10/110',
            ];
			
            foreach ($stdRates as $key => $rate) {
				$name = str_replace(' ', '_', WC_Tax::get_rate_code($key));
                $taxes_fields[$name] = [
                    'title'       => __( 'Tax mapping - ' . $rate['label'], 'woocommerce-cgateway' ),
                    'type'        => 'select',
                    'class'       => 'wc-enhanced-select',
                    'description' => __( 'Map Store Tax '. $rate['label'], 'woocommerce-cgateway' ),                    
                    'desc_tip'    => true,
                    'options'     =>  $cgateway_taxes
                ];
                
            }

            $tax_classes = WC_Tax::get_tax_classes();
          	
          	
            
            foreach ($tax_classes as $value) {
                $rates = WC_Tax::get_rates($value);
                foreach ($rates as $key => $rate) {
					$name = str_replace(' ', '_', WC_Tax::get_rate_code($key));
              
                    $taxes_fields[$name] = [
                        'title'       => __( 'Tax mapping - ' . $rate['label'], 'woocommerce-cgateway' ),
                        'type'        => 'select',
                        'class'       => 'wc-enhanced-select',
                        'description' => __( 'Map Store Tax '. $rate['label'], 'woocommerce-cgateway' ),                    
                        'desc_tip'    => true,
                        'options'     =>  $cgateway_taxes
                    ];
                    
                }
            }

             
          
           $this->form_fields = array_merge( $this->form_fields, $taxes_fields);
          
			
        }

        /**
         * Validate credit card data
         *
         * @return void
         */
        public function validate_fields() {
            if ($this->has_fields) {

            }
        }

        /**
         * Add notice in admin section if gateway is used without SSL certificate
         */
        public function do_ssl_check() {
            if ( $this->enabled == "yes" && get_option( 'woocommerce_force_ssl_checkout' ) == "no" ) {
                echo "<div class=\"error\"><p>". sprintf( __( "<strong>%s</strong> is enabled and WooCommerce is not forcing the SSL certificate on your checkout page. Please ensure that you have a valid SSL certificate and that you are <a href=\"%s\">forcing the checkout pages to be secured.</a>" ), $this->method_title, admin_url( 'admin.php?page=wc-settings&tab=checkout' ) ) ."</p></div>";
            }
        }

        

        /**
         * Show Receipt data on Order Edit page
         *
         */
        public function cgateway_order_receipt_display_admin_order_meta($order) {
           
            $receiptDataJSON = get_post_meta( $order->get_order_number(), 'cgateway_receipt_attributes',true);
            $receiptStatus = get_post_meta( $order->get_order_number(), 'cgateway_receipt_status',true);
            $receiptCreated = get_post_meta( $order->get_order_number(), 'cgateway_receipt_created',true);
            $receiptOperation = get_post_meta( $order->get_order_number(), 'cgateway_receipt_operation',true);

            echo '<p><strong>' . $this->method_title . ' ' . __('Electronic Reciept Status') . ':</strong> ' . $receiptStatus . '</p>';
            echo '<p><strong>' . $this->method_title . ' ' . __('Electronic Reciept Operation') . ':</strong> ' . $receiptOperation . '</p>';
            echo '<p><strong>' . $this->method_title . ' ' . __('Electronic Reciept Created at') . ':</strong> ' . $receiptCreated . '</p>';
            if($receiptDataJSON){
                $receiptData = json_decode($receiptDataJSON, true);
                if($receiptData){
                    echo '<p><strong>' . $this->method_title . ' ' . __('Electronic Reciept Data') . ':</strong> ' . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Receipt Number') . ':</strong> ' . $receiptData['receipt_number'] . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Shift Number') . ':</strong> ' . $receiptData['shift_number'] . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Shift Receipt Number') . ':</strong> ' . $receiptData['shift_receipt_number'] . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Registered') . ':</strong> ' . $receiptData['registered'] . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Receipt Attribute') . ':</strong> ' . $receiptData['receipt_attribute'] . '</p>';                
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Fiscal Storage Number') . ':</strong> ' . $receiptData['fiscal_storage_number'] . '</p>';
                    echo '<p>&nbsp;&nbsp;&nbsp;' . __('Device Registration Number') . ':</strong> ' . $receiptData['device_registration_number'] . '</p>';
                }
            }
        }
        

        /**
         * Show Order ID on Order Edit page
         *
         */
        public function cgateway_order_reciept_update_admin_order_meta($order) {
           $post_id = isset($_GET['post']) ? $_GET['post'] : false;
            if(! $post_id ) return; // Exit
            $gatewayOrderStatus = get_post_meta( $post_id, 'cgateway_order_status', false );
            $gatewayOrderStatus = end( $gatewayOrderStatus );

            if(in_array($gatewayOrderStatus, ["charged", "refunded"])) echo '<a href="?post='.$post_id.'&action=edit&cgateway_action=update_receipt">'.__('Update receipt').'</a>';

            if ( isset( $_GET['cgateway_action'] ) &&  $_GET['cgateway_action']=='update_receipt' ) {
                $gatewayOrderId = get_post_meta( $post_id, 'cgateway_order_id', false );
                $gatewayOrderId = end( $gatewayOrderId );

                self::log($post_id . ': Update receipt, GW: ' . $gatewayOrderId);

                if (!$gatewayOrderId) {
                    return new WP_Error( 'cgateway_status_error', __('No Gateway order ID.', 'woocommerce-cgateway') ); // return false;
                }
                
                $orderData = $this->requestGatewayOrderData($gatewayOrderId);

                $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                update_post_meta($post_id, 'cgateway_receipt_status',  $gatewayReciept['status']);
                update_post_meta($post_id, 'cgateway_receipt_created',  $gatewayReciept['created']);
                update_post_meta($post_id, 'cgateway_receipt_operation',  $gatewayReciept['operation']);

                $attributes = isset($gatewayReciept['attributes'])?json_encode($gatewayReciept['attributes']):"";          
                update_post_meta($post_id, 'cgateway_receipt_attributes', $attributes  );

                wp_redirect(admin_url('/post.php?post='.$post_id.'&action=edit', 'http'), 307);

            }
        }

        

        /**
         * Show Order ID on Order Edit page
         *
         */
        public function cgateway_order_id_display_admin_order_meta($order) {
            $value = implode(', ', get_post_meta( $order->get_order_number(), 'cgateway_order_id', false ));
            // $value = get_post_meta( $order->get_order_number(), 'cgateway_order_id', false );
            // $value = end( $value );
            echo '<p><strong>' . $this->method_title . ' ' . __('Order ID') . ':</strong> ' . $value . '</p>';
        }

        /**
         * Show Order Status on Order Edit page
         *
         */
        public function cgateway_order_status_display_admin_order_meta($order) {
            $value = implode(', ', get_post_meta( $order->get_order_number(), 'cgateway_order_status', false ));
            // $value = get_post_meta( $order->get_order_number(), 'cgateway_order_status', false );
            // $value = end( $value );
            echo '<p><strong>' . $this->method_title . ' ' . __('Order Status') . ':</strong> ' . $value . '</p>';
        }

       /**
         * Show Order when updated on Order Edit page
         *
         */
        public function cgateway_order_updated_display_admin_order_meta($order) {
            $value = implode(', ', get_post_meta( $order->get_order_number(), 'cgateway_order_updated', false ));
            // $value = get_post_meta( $order->get_order_number(), 'cgateway_order_updated', false );
            // $value = end( $value );
            echo '<p><strong>' . $this->method_title . ' ' . __('Order Updated at') . ':</strong> ' . $value . '</p>';
        }

        /**
         * Process fields values of this plugin admin settings.
         *
         */
        public function process_admin_options() {
            parent::process_admin_options();
            // processing file upload
            $maxCertFileSize = intval(0.5 * 1024 * 1024); // 0.5MB (524288 bytes)
            if ( isset($_FILES) && isset($_FILES['woocommerce_'. $this->id .'_cert_file']) && $_FILES['woocommerce_'. $this->id .'_cert_file']['size'] > 0 && $_FILES['woocommerce_'. $this->id .'_cert_file']['size'] <= $maxCertFileSize ) {
                $this->init_settings();
                $wp_upload_dir = wp_upload_dir();
                $cert_upload_dir = $wp_upload_dir['basedir'] . '/'. $this->id .'/certs';
                $upload_overrides = array( 'test_form' => false );
                if ( wp_mkdir_p($cert_upload_dir) ) { // wp_is_writable($cert_upload_dir)
                    $new_cert_file_name = 'cert_' . md5(time());
                    $tmp_cert_file_path = $_FILES['woocommerce_'. $this->id .'_cert_file']['tmp_name'];
                    $new_cert_file_full_path = $cert_upload_dir . '/' . $new_cert_file_name;
                    if ( $move_uploaded_file_res = move_uploaded_file( $tmp_cert_file_path, $new_cert_file_full_path ) ) {
                        // uploaded and moved
                        $this->settings['cert_file_path'] = $new_cert_file_full_path;
                        return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
                    }
                    else {
                        self::log("ERR: cert move fail");
                        $this->add_error("Can't move certificate file.");
                    }
                }
                else {
                    self::log("ERR: cert dir fail");
                    $this->add_error("Can't create certificate directory.");
                }
                $this->display_errors();
            }
        }

        /**
         * Customize Thank you text.
         *
         */
        public function change_order_received_text($text) {
           $newText = '<p>' . sprintf(__('Ваш заказ был получен. <br />Способ оплаты: %s Payment Gateway.', 'woocommerce-cgateway'), $this->method_title) . '</p>';
           return $newText;
        }

        /**
         * Modify credit card form.
         *
         */
        public function woocommerce_credit_card_form_fields_cgateway($form_fields, $this_payment_id) {
            if ( isset($this->require_card_holder) && $this->require_card_holder == 'yes' ) {
                $form_fields['card_holder'] = '<p class="form-row form-row-wide">
                    <label for="'. esc_attr($this_payment_id) .'-card-holder">Card holder <span class="required">*</span></label>
                    <input id="'. esc_attr($this_payment_id) .'-card-holder" class="input-text wc-credit-card-form-card-holder" autocomplete="cc-holder" autocorrect="no" autocapitalize="yes" spellcheck="no" type="text" name="'. esc_attr($this_payment_id) .'-card-holder" />
                </p>';
            }

            $form_fields['card-number-field'] .= include(plugin_dir_path(__FILE__) . 'include/card-number-js.php');

            return $form_fields;
        }


        /**
         * Refund processing.
         * https://github.com/mikejolley/woocommerce-simplify-payment-gateway-plugin/blob/master/includes/class-payment-gateway.php
         * 
         * @param  int $order_id
         * @param  float $amount
         * @param  string $reason
         * @return bool|WP_Error
         */
        public function process_refund( $order_id, $amount = null, $reason = '' ) {
            self::log('--- Refund, Order: ' . $order_id);

            if ( !is_numeric($order_id) ) {
                return new WP_Error( 'cgateway_refund_error', __('Invalid Order ID.', 'woocommerce-cgateway') ); // return false;
            }

           

            $gatewayOrderId = get_post_meta( $order_id, 'cgateway_order_id', false );
            $gatewayOrderId = end( $gatewayOrderId );

            self::log($order_id . ': Refund, GW: ' . $gatewayOrderId);

            if (!$gatewayOrderId) {
                return new WP_Error( 'cgateway_refund_error', __('No Gateway order ID.', 'woocommerce-cgateway') ); // return false;
            }
            
            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/' . $gatewayOrderId, // get order info
                    'type' => 'GET',
                    'get_headers' => true
                ]
            );

            // self::log( print_r($output, true) );

            $outputCode = (int)$output['code'];

            if ($outputCode != 200) {
                self::log($order_id . ': Refund, ERR, Code: ' . $outputCode);
                return new WP_Error( 'cgateway_refund_error', __('Cannot retrieve this order Gateway data.', 'woocommerce-cgateway') ); // return false;
            }

            $orderData = json_decode($output['body'], true);

            // self::log( print_r($orderData, true) );

            // - find out current status

            if ( !isset($orderData['orders'][0]['status']) ) {
                return new WP_Error( 'cgateway_refund_error', __('Gateway order status undefined.', 'woocommerce-cgateway') ); // return false;
            }

            $currentGatewayOrderStatus = $orderData['orders'][0]['status'];

            self::log($order_id . ': Refund, Current status: ' . $currentGatewayOrderStatus);

            $amount_charged = isset($orderData['orders'][0]['amount_charged']) ? $orderData['orders'][0]['amount_charged'] : 0;

            if ( ! (int)($amount_charged * 100) ) {
                $amount_charged = isset($orderData['orders'][0]['amount']) ? $orderData['orders'][0]['amount'] : 0;
            }

            self::log($order_id . ': Refund, GW Amount Charged: ' . $amount_charged);

            if ( $currentGatewayOrderStatus != 'charged' && $currentGatewayOrderStatus != 'authorized' ) {
                // - find charged or authorized within operations
                if ( !isset($orderData['orders'][0]['operations']) || empty($orderData['orders'][0]['operations']) ) {
                    return new WP_Error( 'cgateway_refund_error', __('Gateway order operations are undefined.', 'woocommerce-cgateway') ); // return false;
                }

                foreach ($orderData['orders'][0]['operations'] as $op) {
                    if ( !isset($op['type']) ) {
                        continue;
                    }

                    if ( $op['type'] == 'charge' ) {
                        $currentGatewayOrderStatus = 'charged';
                        break;
                    }
                    elseif ( $op['type'] == 'authorize' ) {
                        $currentGatewayOrderStatus = 'authorized';
                    }
                }

                self::log($order_id . ': Refund, Operation type: ' . $currentGatewayOrderStatus);
            }

            if ( $currentGatewayOrderStatus != 'charged' && $currentGatewayOrderStatus != 'authorized' ) {
                return new WP_Error( 'cgateway_refund_error', __('Refund and reverse operations are not available.', 'woocommerce-cgateway') ); // return false;
            }

            if ( $currentGatewayOrderStatus == 'charged' ) {
                // - do Refund
                
                if ( (int)($amount * 100) <= 0 ) {
                    return new WP_Error( 'cgateway_refund_error', __('Invalid amount value.', 'woocommerce-cgateway') ); // return false;
                }

                $orderArray['amount'] = $amount;

                if($this->electronic_receipt == 'yes'){
                    $order = new WC_Order($order_id);
                    $refunds = $order->get_refunds();
                    $refunds = $refunds[0];
                    $orderArray['extra_fields'] = $this->fillRefundRecieptData($refunds);
                }

                $output = $this->gatewayClient->request(
                    [
                        'url' => $this->apiurl . '/orders/' . $gatewayOrderId . '/refund',
                        'type' => 'PUT',
                        'get_headers' => false
                    ],
                    json_encode( $orderArray )
                );
                
                // self::log( print_r($output, true) );

                $outputCode = (int)$output['code'];

                self::log($order_id . ': Refund att., Amount: ' . $amount . '; Code: ' . $outputCode);

                if ( $outputCode != 200 ) {
                    return new WP_Error( 'cgateway_refund_error', __('Refund operation failed.', 'woocommerce-cgateway') ); // return false;
                }

                $orderData = json_decode($output['body'], true);
                $this->changeShopOrder($orderData, $gatewayOrderId, $order_id); // update shop order meta info

                if ( $amount_charged == $amount ) {
                    self::log($order_id . ': Refunded completely');
                    $order = new WC_Order($order_id);
                    $order->update_status( 'refunded' );
                }

                return true;
            }
            elseif ( $currentGatewayOrderStatus == 'authorized' ) {
                // - do Reverse
                
                if ( (int)($amount * 100) != (int)($amount_charged * 100) ) {
                    return new WP_Error( 'cgateway_refund_error', __('Reverse cannot be performed.', 'woocommerce-cgateway') ); // return false;
                }
                
                $output = $this->gatewayClient->request(
                    [
                        'url' => $this->apiurl . '/orders/' . $gatewayOrderId . '/reverse',
                        'type' => 'PUT',
                        'get_headers' => false
                    ]
                );

                $outputCode = (int)$output['code'];

                self::log($order_id . ': Reverse att., Code: ' . $outputCode);

                if ( $outputCode != 200 ) {
                    return new WP_Error( 'cgateway_refund_error', __('Reverse operation failed.', 'woocommerce-cgateway') ); // return false;
                }

                $orderData = json_decode($output['body'], true);
                $this->changeShopOrder($orderData, $gatewayOrderId, $order_id); // update shop order meta info

                $order = new WC_Order($order_id);
                $order->update_status( 'cancelled', 'Order reversed.' );

                return true;
            }

            return false;
        }


        /**
         * Handling payment and processing the order.
         *
         * @param int $order_id Id of the order
         * @return array
         */
        public function process_payment($order_id) {
            self::log("--- Shop order " . $order_id);
            
            $order = new WC_Order($order_id);
            
            $returnArray = [
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            ];

            $creditCardArray = isset($_POST) ? $this->createCreditCardArray($_POST) : false;

            if ( !$this->has_fields || !isset($_POST) || !$creditCardArray ) {
                return $returnArray; // Payment page is used. Early exit.
            }

            self::log($order_id . ': Selfhosted, POST, authorize');

            $order_data = $order->get_data();
            $customerArray = $this->createCustomerArray($order_data);

            $jsonData = $this->createJsonAsArrayForGateway($order, $customerArray, $creditCardArray);

            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/authorize', // Authorization of payment
                    'type' => 'POST',
                    'get_headers' => false
                ],
                $jsonData
            );
            $outputCode = (int)$output['code'];


            // self::log( print_r($output, true) );
            self::log($order_id . ': Output code: ' . $outputCode);

            if ( isset($output['body']) ) {
                $gatewayOutputBody = json_decode($output['body'], true);
            }
            else {
                self::log("ERR: no output body");
                return $returnArray;
            }

            $gatewayOrderStatus = $this->gatewayClient->getGatewayOrderStatus($gatewayOutputBody);

            if ( $outputCode == 200 ) {
                // 200, authorization is complete, 3-D Secure was not requested
                self::log($order_id . ": Selfhosted, POST, 200");

                // wc_add_notice( __('Authorization has been completed. ', 'woocommerce-cgateway') . __('Order ID: ', 'woocommerce-cgateway') . $order_id, 'success' );

                $this->changeShopOrder($gatewayOutputBody, false, $order_id);
                $wooOrderStatus = $this->convertGatewayToWooStatus($gatewayOrderStatus);
                $messageEntity = $this->setWooNotice($wooOrderStatus, $gatewayOrderStatus);
                wc_add_notice($messageEntity['string'], $messageEntity['type']);
                $order->update_status( $wooOrderStatus, $messageEntity['string'] );

                $returnArray = [
                    'result' => 'success',
                    'redirect' => $this->get_return_url($order)
                ];
            }
            elseif ( $outputCode == 201 ) {
                // 201, order is prepared for the 3-D Secure authentication
                self::log($order_id . ": Selfhosted, POST, 201");

                wc_add_notice( __('Order is prepared for the 3-D Secure authentication. ', 'woocommerce-cgateway') . __('Order ID: ', 'woocommerce-cgateway') . $order_id, 'success' );

                if ( $this->gatewayClient->isGatewayOutputBody3dOk($gatewayOutputBody) ) {
                    WC()->session->set( $this->id . '-termurl', $gatewayOutputBody['orders'][0]['form3d']['TermUrl'] );
                    WC()->session->set( $this->id . '-pareq', $gatewayOutputBody['orders'][0]['form3d']['PaReq'] );
                    WC()->session->set( $this->id . '-MD', $gatewayOutputBody['orders'][0]['form3d']['MD'] );
                    WC()->session->set( $this->id . '-action', $gatewayOutputBody['orders'][0]['form3d']['action'] );
                }
                else {
                    self::log('ERR: vars for 3D are not set');
                    wc_add_notice( __('Incorrect parameters.', 'woocommerce-cgateway'), 'error' );
                    $returnArray = [
                        'result' => 'failed',
                        'redirect' => $this->get_return_url($order)
                    ];
                    return $returnArray;
                }
            }
            else {
                // xxx, failed
                self::log($order_id . ": Selfhosted, POST, fail, code: " . $outputCode);

                $gatewayOrderId = isset($gatewayOutputBody['order_id']) ? $gatewayOutputBody['order_id'] : 0;
                $gatewayFailureMessage = isset($gatewayOutputBody['failure_message']) ? $gatewayOutputBody['failure_message'] : "";
                
                $gatewayFailureMessageInner = "";
                if (!$gatewayFailureMessage) {
                    // in case we are not getting JSON, but HTML
                    $gatewayFailureMessageInner = isset($output['body']) ? strip_tags( $output['body'] ) : "";
                }

                $order->update_status( $this->convertGatewayToWooStatus($gatewayOrderStatus) );
                add_post_meta($order_id, 'cgateway_order_id', $gatewayOrderId );
                add_post_meta($order_id, 'cgateway_order_status', $gatewayOrderStatus );
                add_post_meta($order_id, 'cgateway_order_updated', '-' );
                echo "<pre style='background:rgba(216, 51, 51, 0.44)'>";
                echo  __('Payment failure. ', 'woocommerce-cgateway') . $gatewayFailureMessage;
                echo "</pre>";
                // if($this->electronic_receipt){                    
                //     $gatewayReciept = $this->gatewayClient->getGatewayReceipt($gatewayOutputBody);
                //     if(!$gatewayReciept){
                //         $orderData = $this->requestGatewayOrderData($gatewayOrderId);
                //         $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                //     }
                //     update_post_meta($order_id, 'cgateway_receipt_status',  $gatewayReciept['status']);
                //     update_post_meta($order_id, 'cgateway_receipt_created',  $gatewayReciept['created']);
                //     update_post_meta($order_id, 'cgateway_receipt_operation',  $gatewayReciept['operation']);

                //     $attributes = isset($gatewayReciept['attributes'])?json_encode($gatewayReciept['attributes']):"";          
                //     update_post_meta($order_id, 'cgateway_receipt_attributes', $attributes  );

                // }

                self::log("Failure msg: " . $gatewayFailureMessage . ' ' . $gatewayFailureMessageInner);

                $order->add_order_note( 'Failure. ' . $gatewayFailureMessage . ' ' . $gatewayFailureMessageInner );

                wc_add_notice( __('Order ID: ', 'woocommerce-cgateway') . $order_id, 'error' );
                wc_add_notice( __('Payment failure. ', 'woocommerce-cgateway') . $gatewayFailureMessage, 'error' );

                $returnArray = [
                    'result' => 'failed',
                    'redirect' => $this->get_return_url($order)
                ];
            }

            return $returnArray;
        }

        /**
         * Creates order on Gateway. Sets Shop's order status. Shows additional HTML or redirects to Gateway.
         * /checkout/order-pay/SSS/?key=wc_order_ZZZ
         * 
         * @param $order_id
         */
        function receipt_page( $order_id ) {
            self::log("receipt_page : " . $order_id);

            echo '<p>'. __('Thank you for your order.', 'woocommerce-cgateway') .'</p>';
            
            if ( $this->has_fields && WC()->session->get($this->id . '-MD') ) {
                // Server to server is used.

                self::log($order_id . ": 3D");

                $threeDFormHtml = $this->gatewayClient->generateThreeDForm( 
                    WC()->session->get($this->id . '-pareq'), 
                    WC()->session->get($this->id . '-MD'), 
                    WC()->session->get($this->id . '-termurl'), 
                    WC()->session->get($this->id . '-action') 
                );
                WC()->session->set($this->id . '-MD', "");
                if (!$threeDFormHtml) {
                    echo '<p>' . __('Error: Proper 3D form cannot be generated.', 'woocommerce-cgateway') . '</p>';
                }
                else {
                    echo '<p>'. __('Payment form will appear now.', 'woocommerce-cgateway') .'</p>';
                    echo $threeDFormHtml;
                }
                return;
            }

            // Payment page is used.

            $order = new WC_Order($order_id);
            
            $order_data = $order->get_data();
            $customerArray = $this->createCustomerArray($order_data);

            $jsonData = $this->createJsonAsArrayForGateway($order, $customerArray);

            self::log($order_id . ": POST, create");

            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/create', // create order within Gateway
                    'type' => 'POST',
                    'get_headers' => true
                ],
                $jsonData
            );
			
            //self::log( print_r($output, true) );
            preg_match('/{.*}/', $output['body'], $output_withoutHeader);
			$output_withoutHeader = $output_withoutHeader[0];

            $outputCode = (int)$output['code'];
            if ($outputCode != 201 && $outputCode != 200) {
                self::log($order_id . ": POST, create, code: " . $outputCode);
                
                if ( isset($output['body']) ) {
                    $gatewayOutputBody = json_decode($output_withoutHeader, true);
                }

                $gatewayOrderId = isset($gatewayOutputBody['order_id']) ? $gatewayOutputBody['order_id'] : 0;
                $gatewayFailureMessage = isset($gatewayOutputBody['failure_message']) ? $gatewayOutputBody['failure_message'] : "";
                $gatewayOrderStatus = $this->gatewayClient->getGatewayOrderStatus($gatewayOutputBody);
                
                
                $gatewayFailureMessageInner = "";
                if (!$gatewayFailureMessage) {
                    // in case we are not getting JSON, but HTML
                    $gatewayFailureMessageInner = isset($output['body']) ? strip_tags( $output['body'] ) : "";
                }

                $order->update_status( $this->convertGatewayToWooStatus($gatewayOrderStatus) );
                add_post_meta($order_id, 'cgateway_order_id', $gatewayOrderId );
                add_post_meta($order_id, 'cgateway_order_status', $gatewayOrderStatus );
                add_post_meta($order_id, 'cgateway_order_updated', '-' );
                // if($this->electronic_receipt){                    
                //     $gatewayReciept = $this->gatewayClient->getGatewayReceipt($gatewayOutputBody);
                //     if(!$gatewayReciept){
                //         $orderData = $this->requestGatewayOrderData($gatewayOrderId);
                //         $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                //     }
                //     update_post_meta($order_id, 'cgateway_receipt_status',  $gatewayReciept['status']);
                //     update_post_meta($order_id, 'cgateway_receipt_created',  $gatewayReciept['created']);
                //     update_post_meta($order_id, 'cgateway_receipt_operation',  $gatewayReciept['operation']);

                //     $attributes = isset($gatewayReciept['attributes'])?json_encode($gatewayReciept['attributes']):"";          
                //     update_post_meta($order_id, 'cgateway_receipt_attributes', $attributes  );
                // }
                echo "<pre style='background:rgba(216, 51, 51, 0.44)'>";
                echo  __('Payment failure. ', 'woocommerce-cgateway') . $gatewayFailureMessage;
                echo "</pre>";
                self::log("Failure msg: " . $gatewayFailureMessage . ' ' . $gatewayFailureMessageInner);
                
                $order->add_order_note( 'Failure. ' . $gatewayFailureMessage . ' ' . $gatewayFailureMessageInner );
                
                wc_add_notice( __('Order ID: ', 'woocommerce-cgateway') . $order_id, 'error' );
                wc_add_notice( __('Payment failure. ', 'woocommerce-cgateway') . $gatewayFailureMessage, 'error' );

                return false;
            }

            // get Location (URI) where Gateway payment form is
            $gatewayProcessPageUrl = $this->gatewayClient->getLocationHeader($output['body']);
			
            if (!$gatewayProcessPageUrl) {
                self::log("receipt_page, BAD Location : " . $order_id);
                wc_add_notice( __('Location value not defined. ', 'woocommerce-cgateway') . __('Order ID: ', 'woocommerce-cgateway') . $order_id, 'error' );
                $gatewayProcessPageUrl = $this->get_return_url($order);
            }
            $gatewayProcessPageUrl = esc_url( $gatewayProcessPageUrl );

            //if (function_exists('wc_reduce_stock_levels')) {
            //    wc_reduce_stock_levels($order_id);
            //}

            $order->update_status('pending');
            $order->add_order_note( __('Gateway processing started. Pending payment.', 'woocommerce-cgateway') );
            
            if ($this->form_type == self::FORM_TYPE_IFRAME) {
                echo '<iframe id="iframe-payment-gateway-form-'. $order_id .'" class="iframe-payment-gateway-form" src="'. $gatewayProcessPageUrl .'"></iframe>';
            }
            else {
                wp_redirect( $gatewayProcessPageUrl );
                exit;
            }
        }
        
        /**
         * Process 3D Secure callback. Payment Gateway callback from ACS received.
         *
         */
        public function check_response() {
            self::log("check_response");
        }

        /**
         * "Order received" page called from Gateway. Change status of Shop's order. Prepare notice.
         *
         */
        private function orderReceivedPageCalledByGateway($data) {
            // - parse url varibles, get order_id (gateway order id)
            if ( !isset($data['shop_order_id']) && !isset($data['order_id']) ) {
                return false;
            }

            if ( !isset($data['key']) ) {
                return false;
            }

            // self::log( print_r($data, true) );

            $gatewayOrderId = $this->gatewayClient->getGatewayOrderIdFromUriParameters(
                isset($data['order_id']) ? $data['order_id'] : 0, 
                isset($data['shop_order_id']) ? $data['shop_order_id'] : 0
            );

            if ($gatewayOrderId == 0) {
                return false;
            }

            $gatewayOrderId = sanitize_text_field( $gatewayOrderId );

            // - make request to Gateway
            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/' . $gatewayOrderId . '?expand=custom_fields', // get order info
                    'type' => 'GET',
                    'get_headers' => true
                ]
            );

            $outputCode = (int)$output['code'];

            if ($outputCode != 200 && $outputCode != 201) {
                self::log("ON GET: " . $outputCode . "; Gateway Order ID: " . $gatewayOrderId);
                // wc_add_notice( __('Sorry, no proper response from server. ', 'woocommerce-cgateway') . __('Gateway Order ID: ', 'woocommerce-cgateway') . $gatewayOrderId, 'error' );
                return false;
            }

            $orderData = json_decode($output['body'], true);

            if ( isset($orderData['orders'][0]['status']) && ( $orderData['orders'][0]['status'] == 'refunded' || $orderData['orders'][0]['status'] == 'reversed' ) ) {
                self::log("ON GET: Refunded or Reversed");
                return false;
            }

            // - change Shop's order
            $shop_order_id = $this->getShopOrderIdFromGateway($orderData);
            if (!$shop_order_id) {
                return false;
            }

            $this->changeShopOrder($orderData, $gatewayOrderId, $shop_order_id);

            $order = new WC_Order($shop_order_id);
            $gatewayOrderStatus = $this->gatewayClient->getGatewayOrderStatus($orderData);
            $wooOrderStatus = $this->convertGatewayToWooStatus($gatewayOrderStatus);
            // self::log($shop_order_id . ': @1 ' . $wooOrderStatus);
            $wooOrderStatus = $this->changeWooStatusIfDigital($order, $wooOrderStatus);
            // self::log($shop_order_id . ': @2 ' . $wooOrderStatus);
            $messageEntity = $this->setWooNotice($wooOrderStatus, $gatewayOrderStatus);
            wc_add_notice($messageEntity['string'], $messageEntity['type']);
            
            $order->update_status( $wooOrderStatus, $messageEntity['string'] );

            // iframe was used
            if ( $this->form_type == self::FORM_TYPE_IFRAME || (isset($data['is_iframe']) && $data['is_iframe'] == '1') ) {
                self::log('iframe, shop: ' . $shop_order_id);
                $this->showIframeHtmlAnswer($shop_order_id);
                exit;
            }
        }

        /**
         * Get Shop Order ID from data stored within Gateway.
         *
         */
        private function getShopOrderIdFromGateway($orderData) {
            $shop_order_id = 0;

            if ( isset($orderData['orders'][0]['custom_fields']['shop_order_id']) ) {
                $shop_order_id = (int)$orderData['orders'][0]['custom_fields']['shop_order_id'];
            }
            elseif ( isset($orderData['orders'][0]['merchant_order_id']) ) {
                $shop_order_id = (int)$orderData['orders'][0]['merchant_order_id'];
            }

            return $shop_order_id;
        }

        /**
         * Change metadata/data of Shop's Order.
         *
         */
        private function changeShopOrder($orderData, $gatewayOrderId = "", $shop_order_id = 0) {
            if ( !isset($orderData['orders'][0]['status']) ) {
                return 0;
            }
            
            if (!$shop_order_id) {
                return 0;
            }

            if (!$gatewayOrderId) {
                $gatewayOrderId = $orderData['orders'][0]['id'];
            }
            $gatewayOrderUpdated = "";
            if ( isset($orderData['orders'][0]['updated']) ) {
                $gatewayOrderUpdated = sanitize_text_field( $orderData['orders'][0]['updated'] );
            }
            $gatewayOrderStatus = sanitize_text_field( $orderData['orders'][0]['status'] );
            //$gatewayReciept = sanitize_text_field( $orderData['orders'][0]['status'] );
            //
           
            $order = new WC_Order($shop_order_id);

            if ( !$order ) {
                self::log("ERR, No order by ID: " . $shop_order_id);
                return 0;
            }

            self::log("upd Shop: " . $shop_order_id . " | Gw: " . $gatewayOrderId);

            $cgateway_order_status = get_post_meta( $shop_order_id, 'cgateway_order_status', false );
            $cgateway_order_status = end( $cgateway_order_status );
            
            if ( 
                $cgateway_order_status != $gatewayOrderStatus && 
                ($cgateway_order_status == 'authorized' || $cgateway_order_status == 'charged') && 
                function_exists('wc_reduce_stock_levels')
            ) {
                wc_reduce_stock_levels($shop_order_id);
            }

            if ( $cgateway_order_status == $gatewayOrderStatus && $cgateway_order_status != 'refunded' ) {
                // nothing
            }
            else {
                add_post_meta($shop_order_id, 'cgateway_order_id', $gatewayOrderId );
                add_post_meta($shop_order_id, 'cgateway_order_status', $gatewayOrderStatus );
                add_post_meta($shop_order_id, 'cgateway_order_updated', $gatewayOrderUpdated );
                if($this->electronic_receipt){
                    $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                    if(!$gatewayReciept){
                        $orderData = $this->requestGatewayOrderData($gatewayOrderId);
                        $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                    }
                    update_post_meta($shop_order_id, 'cgateway_receipt_status',  $gatewayReciept['status']);
                    update_post_meta($shop_order_id, 'cgateway_receipt_created',  $gatewayReciept['created']);
                    update_post_meta($shop_order_id, 'cgateway_receipt_operation',  $gatewayReciept['operation']);

                    $attributes = isset($gatewayReciept['attributes'])?json_encode($gatewayReciept['attributes']):"";          
                    update_post_meta($shop_order_id, 'cgateway_receipt_attributes', $attributes  );
                }
               // add_post_meta($shop_order_id, 'cgateway_order_updated', $gatewayOrderUpdated );
            }

            return $shop_order_id;
        }

        private function requestGatewayOrderData($gatewayOrderId)
        {
           // self::log($post_id . ': Update receipt, GW: ' . $gatewayOrderId);

            if (!$gatewayOrderId) {
                return new WP_Error( 'cgateway_status_error', __('No Gateway order ID.', 'woocommerce-cgateway') ); // return false;
            }
            
            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/' . $gatewayOrderId, // get order info
                    'type' => 'GET',
                    'get_headers' => true
                ]
            );

            // self::log( print_r($output, true) );

            $outputCode = (int)$output['code'];

            if ($outputCode != 200) {
                self::log($post_id . ': Status, ERR, Code: ' . $outputCode);
                return new WP_Error( 'cgateway_status_error', __('Cannot retrieve this order Gateway data.', 'woocommerce-cgateway') ); // return false;
            }

            return json_decode($output['body'], true);            
        }

        /**
         * Create customer data array for request to Gateway.
         * 
         */
        private function createCustomerArray($order_data) {
            if (!$order_data) {
                return array();
            }
            return array(
                'address'   => trim( $order_data['billing']['address_1'] . ' ' . $order_data['billing']['address_2'] ),
                'city'      => $order_data['billing']['city'],
                'country'   => $order_data['billing']['country'],
                'name'      => $order_data['billing']['first_name'] . ' ' . $order_data['billing']['last_name'],
                'phone'     => $order_data['billing']['phone'],
                'state'     => $order_data['billing']['state'], 
                'zip'       => $order_data['billing']['postcode'],
                'email'     => $order_data['billing']['email']
            );
        }


        /**
         * Create electronic reciept data array for request to Gateway.
         * 
         */
        private function fillRecieptData($order)
        {
            $orderItems = $order->get_items();
            $order_data = $order->get_data();
            $customerArray = $this->createCustomerArray($order_data);
            $shipment_cost = $order->get_total_shipping();
           
            $receiptData = [
                'electronic_receipt' => [
                   'phone' => $customerArray['phone'],
                   'email' => $customerArray['email'],
                   'inn' =>  $this->inn,
                   'taxation_type' => $this->taxation_type,
                ]
            ];

            foreach ($orderItems as $item_id => $order_item) {
				
				$amount = $order_item->get_total() + $order_item->get_total_tax();

       
                $item_payment_object_meta = get_post_meta( $order_item['product_id'], 'cgateway_payment_object_meta', true );
          
                $payment_object  = !in_array($item_payment_object_meta, ['std', ''])? $item_payment_object_meta: $this->payment_object;
                
				
                $tmp = [
                    'name' => $order_item->get_name(),
                    'price' => number_format( $amount / $order_item->get_quantity(), 2, ".", "" ),
                    'quantity' => $order_item->get_quantity(),
                    'amount' => number_format( $amount, 2, ".", "" ),
                    'tax_type' => $this->tax_type,
                    'payment_method' => $this->payment_method,
                    'payment_object' => $payment_object,

                 ];

                 if(wc_tax_enabled()){
                    $taxes = $order_item->get_taxes(); 
					$taxes_last_item = end($taxes);

                    $taxes_rate_code = str_replace(' ', '_', WC_Tax::get_rate_code(key($taxes_last_item)));
					if(property_exists($this, $taxes_rate_code)){
                       $tmp['tax_type'] = $this->$taxes_rate_code;
                    }else{
                        return new WP_Error( 'cgateway_payment_error', __('Tax code not set', 'woocommerce-cgateway') ); // return false;
                    }
					 
                 }
                 $receiptData['electronic_receipt']['items'][] =  $tmp;
            }
            
            if(doubleval($shipment_cost) != 0){
				$taxamount = 0;				                   
	
                if(wc_tax_enabled()){   
					$shipmenttax = WC_Admin_Settings::get_option('woocommerce_shipping_tax_class'); 
                    $shipment_taxes= $order->get_items( 'tax' );
					
					foreach($shipment_taxes as $shipment_tax_item){
						$taxamount += $shipment_tax_item->get_shipping_tax_total();
					}  
                 }else{
					$shipmenttax = $this->tax_type;
				}

                $receiptData['electronic_receipt']['items'][] =[
                    'name' => __('Доставка'),
                    'price' => number_format( $shipment_cost+$taxamount, 2 , ".", ""),
                    'quantity' => 1,
                    'amount' => number_format( $shipment_cost+$taxamount, 2 , ".", ""),
                    'tax_type' => $shipmenttax,
                    'payment_method' => $this->payment_method,
                    'payment_object' => 'service',
                ];
            }
            // echo "<pre>";
            // var_dump($receiptData);
            // echo "</pre>";
            // die();

			
            return $receiptData;
        }


        /**
         * Create electronic reciept data array for refund request to Gateway.
         * 
         */
        private function fillRefundRecieptData($refundorder)
        {
            $orderItems = $refundorder->get_items();
            $parentOrder = new WC_Order($refundorder->get_parent_id());
            $order_data = $parentOrder->get_data();
            $customerArray = $this->createCustomerArray($order_data);

            $shipment_cost = abs($refundorder->get_total_shipping());
           
            $receiptData = [
                'electronic_receipt' => [
                   'phone' => $customerArray['phone'],
                   'email' => $customerArray['email'],
                   'inn' =>  $this->inn,
                   'taxation_type' => $this->taxation_type,
                ]
            ];

            foreach ($orderItems as $item_id => $order_item) {
                $item_payment_object_meta = get_post_meta( $order_item['product_id'], 'cgateway_payment_object_meta', true );
          
                $payment_object  = !in_array($item_payment_object_meta, ['std', ''])? $item_payment_object_meta: $this->payment_object;
                 $tmp = [
                    'name' => $order_item->get_name(),
                    'price' => number_format( abs($order_item->get_total()) / abs($order_item->get_quantity()), 2 , ".", ""),
                    'quantity' => abs($order_item->get_quantity()),
                    'amount' => number_format( abs($order_item->get_total()), 2 , ".", ""),
                    'tax_type' => $this->tax_type,
                    'payment_method' => $this->payment_method,
                    'payment_object' => $payment_object,
                 ];  

                 if(wc_tax_enabled()){
                    $taxes = $order_item->get_taxes();  
                    $itemtaxesamount = 0;                  
                    foreach( $taxes['subtotal'] as $rate_id => $tax ){
                        $rate_code = WC_Tax::get_rate_code($rate_id);
                        $tmp['tax_type'] = $this->$rate_code; 
                        $itemtaxesamount += abs($tax);
                    }
                    
                    $amount = abs($order_item->get_total())+abs($itemtaxesamount);
                    $tmp['price'] = number_format( $amount  / abs($order_item->get_quantity()), 2 , ".", "");
                    $tmp['amount'] = number_format( $amount, 2 , ".", "");
                 }
                 $receiptData['electronic_receipt']['items'][] =  $tmp;
            }
            
            if(doubleval($shipment_cost)!=0){
                $taxamount = 0;
                if(!wc_tax_enabled()){
                    $shipmenttax= $this->tax_type;                    
                }else{
					$shipmenttax = WC_Admin_Settings::get_option('woocommerce_shipping_tax_class');
                   	$shipment_taxes = $refundorder->get_items( 'tax' );
					foreach($shipment_taxes as $shipment_tax_item){
						$taxamount += abs($shipment_tax_item->get_shipping_tax_total());
					}
                }
                 
                $receiptData['electronic_receipt']['items'][] =[
                    'name' => __('Доставка'),
                    'price' => number_format(abs( $shipment_cost)+abs($taxamount), 2 , ".", ""),
                    'quantity' => 1,
                    'amount' => number_format(abs( $shipment_cost)+abs($taxamount), 2 , ".", ""),
                    'tax_type' => $shipmenttax,
                    'payment_method' => $this->payment_method,
                    'payment_object' => 'service',

                ];
            }
            
            
            return $receiptData;
        }

        /**
         * Create credit card data array for request to Gateway.
         * 
         */
        private function createCreditCardArray($data) {
            if (!$data) {
                return array();
            }

            if ( !isset($data[$this->id.'-card-number']) || !isset($data[$this->id.'-card-expiry']) || !isset($data[$this->id.'-card-cvc']) ) {
                return array();
            }

            // if ( isset($this->require_card_holder) && $this->require_card_holder == 'yes' && !isset($data[$this->id.'-card-holder']) ) {
            //     return array();
            // }

            $card_expire_array = explode("/", sanitize_text_field( $data[$this->id.'-card-expiry'] ) );
            $exp_month = (int)$card_expire_array[0];
            $exp_year = (int)$card_expire_array[1];
            if ($exp_year < 100) {
                $exp_year += 2000;
            }
            $card_cvc_cvv = sanitize_text_field( $data[$this->id.'-card-cvc'] );
            $card_holder = isset($data[$this->id.'-card-holder']) ? sanitize_text_field( $data[$this->id.'-card-holder'] ) : "";

            return array(
                'pan' => preg_replace('/[^0-9]/', '', sanitize_text_field( $data[$this->id.'-card-number'] ) ), // MUST be unset before sending to Gateway
                'holder' => $card_holder,
                'cvv' => $card_cvc_cvv,
                'expiration_month' => $exp_month,
                'expiration_year' => $exp_year
            );
        }

        /**
         * Prepare gateway order object for request to Gateway.
         * 
         */
        private function createJsonAsArrayForGateway($order, $customerArray, $creditCardArray = array()) {
            $orderId = $order->get_order_number();
            
            $gatewayOrder = new CGateway\Order();
            $gatewayOrder->orderId = $orderId;
            $gatewayOrder->amount = $order->get_total();
            $gatewayOrder->currency = get_woocommerce_currency();
            $gatewayOrder->customerArray = $customerArray;
            $gatewayOrder->shopUri = home_url('/');
            $gatewayOrder->shopCMS = 'woo';
            $gatewayOrder->language = isset($this->gateway_lang) ? $this->gateway_lang : '';

            $clientIp = $this->gatewayClient->getUserIp();
            if ($clientIp == '127.0.0.1') {
                $clientIp = '6.6.6.6';
            }
            $gatewayOrder->clientIp = $clientIp;

            $gatewayOrder->autoCharge = $this->auto_charge == 'yes' ? 1 : 0;
            $gatewayOrder->force3d = $this->force3d == 'yes' ? 1 : 0;
            $gatewayOrder->terminal = $this->terminal ? $this->terminal : "";

            $gatewayOrder->electronic_receipt = $this->electronic_receipt == 'yes' ? 1 : 0;

            if($gatewayOrder->electronic_receipt){
                $gatewayOrder->electronic_receipt = $this->fillRecieptData($order);
            }

            $returnFromGatewayPageUrl = $this->get_return_url($order); // Go here from Gateway after payment. Originally "Thank you. Your order has been received." page
            if ($this->form_type == self::FORM_TYPE_IFRAME) {
                $returnFromGatewayPageUrl = add_query_arg('is_iframe', 1, $returnFromGatewayPageUrl);
            }
            $returnFromGatewayPageUrl = add_query_arg('shop_order_id', $orderId, $returnFromGatewayPageUrl);
            $gatewayOrder->returnUrl = esc_url( $returnFromGatewayPageUrl );
            
            if ( $this->work_model == 2 ) {
                if ( $this->form_type && $this->form_type == 'Custom' && $this->custom_form_id ) {
                    // Use Custom Form ID. Must be created within Gateway.
                    $gatewayOrder->template = $this->custom_form_id;
                }
                elseif ( $this->form_type && $this->form_type != 'Custom' ) {
                    // Use in Settings defined Form ID.
                    $gatewayOrder->template = $this->form_type;
                }
            }

            if ($creditCardArray && isset($creditCardArray['pan'])) {
                $card_number_pan = $creditCardArray['pan'];
                unset($creditCardArray['pan']);
                $gatewayOrder->pan = $card_number_pan;
                $gatewayOrder->card = $creditCardArray;
            }

            return $this->gatewayClient->createOrderJson($gatewayOrder);
        }

        /** 
         * Set Woo notice according to Woo Order status. Visual representation, sets color of message.
         *
         * @access private
         * @return array
         */
        private function setWooNotice($wooOrderStatus = 'failed', $gatewayOrderStatus = "") {
            $messageEntities = [
                'completed' => [
                    'type' => 'success',
                    'string' => sprintf(__('Способ оплаты: %s.', 'woocommerce-cgateway'), $this->method_title)
                ],
                'processing' => [
                    'type' => 'success',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ],
                'cancelled' => [
                    'type' => 'error',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ],
                'refunded' => [
                    'type' => 'notice',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ],
                'error' => [
                    'type' => 'error',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ],
                'failed' => [
                    'type' => 'error',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ]
            ];

            if ( !isset($messageEntities[$wooOrderStatus]) ) {
                return [
                    'type' => 'notice',
                    'string' => ucfirst($gatewayOrderStatus) . '.' 
                ];
            }
            else {
                return $messageEntities[$wooOrderStatus];
            }
        }

        /**
         * Get Woo order status acording to gateway status.
         *
         */
        private function convertGatewayToWooStatus($gatewayOrderStatus) {
            if ( $gatewayOrderStatus == 'charged' || $gatewayOrderStatus == 'success' ) {
                return 'processing';
            }
            elseif ( $gatewayOrderStatus == 'new' || $gatewayOrderStatus == 'processing' || $gatewayOrderStatus == 'prepared' || $gatewayOrderStatus == 'authorized' ) {
                return 'on-hold';
            }
            elseif ( $gatewayOrderStatus == 'reversed' ) {
                return 'cancelled';
            }
            elseif ( $gatewayOrderStatus == 'refunded' || $gatewayOrderStatus == 'chargedback' ) {
                return 'refunded';
            }
            elseif ( $gatewayOrderStatus == 'error' || $gatewayOrderStatus == 'fraud' || $gatewayOrderStatus == 'rejected' || $gatewayOrderStatus == 'declined' || $gatewayOrderStatus == 'failure' ) {
                return 'failed';
            }
            else {
                return 'pending';
            }
        }

        /**
         * If Order has only virtual or/and downloadable products, then change Woo Status.
         * 
         */
        private function changeWooStatusIfDigital($order, $previouslyDefinedOrderStatus) {
            $items = $order->get_items();
            
            foreach ($items as $item) {
                if ( '0' != $item['variation_id'] ) {
                    $product = new WC_Product( $item['variation_id'] );
                }
                else {
                    $product = new WC_Product( $item['product_id'] );
                }

                if ( !$product->is_virtual() && !$product->is_downloadable() ) {
                    return $previouslyDefinedOrderStatus;
                }
            }

            if ($previouslyDefinedOrderStatus == 'processing') {
                return 'completed';
            }

            return $previouslyDefinedOrderStatus;
        }

        /**
         * When 2 stages: authorize-charge.
         * Charge on update when from On Hold to Processing.
         *
         */
        /*
        public function cgateway_charge_on_save_order($post_id) {
            if ( 'shop_order' != get_post_type($post_id) ) {
                return;
            }

            // unhook this function so it doesn't loop infinitely
            remove_action( 'save_post', array($this, 'cgateway_charge_on_save_order') );

            $order = new WC_Order($post_id);

            $cgateway_order_status = get_post_meta( $post_id, 'cgateway_order_status', false );
            $cgateway_order_status = end( $cgateway_order_status );

            $cgateway_order_id = get_post_meta( $post_id, 'cgateway_order_id', false );
            $cgateway_order_id = end( $cgateway_order_id );

            // - if changed to Processing or Completed
            if ( 
                $cgateway_order_id && 
                $cgateway_order_status == 'authorized' && 
                isset($order->status) && 
                ($order->status == 'processing' || $order->status == 'completed') 
            ) {
                // - try to Charge
                $amount = number_format( $order->get_total(), 2 , ".", "");

                self::log($post_id . ': admin, Upd from On Hold, Amount: ' . $amount);

                $output = $this->gatewayClient->request(
                    [
                        'url' => $this->apiurl . '/orders/' . $cgateway_order_id . '/charge',
                        'type' => 'PUT',
                        'get_headers' => false
                    ],
                    json_encode( [ 'amount' => $amount ] )
                );

                // self::log( print_r($output, true) );

                $outputCode = (int)$output['code'];

                self::log($post_id . ': admin, Code: ' . $outputCode);

                if ( $outputCode == 200 ) {
                    $orderData = json_decode($output['body'], true);

                    $gatewayOrderStatus = isset($orderData['orders'][0]['status']) ? $orderData['orders'][0]['status'] : "";
                    $gatewayOrderUpdated = isset($orderData['orders'][0]['updated']) ? $orderData['orders'][0]['updated'] : "";

                    if ( $gatewayOrderStatus == 'charged' ) {
                        // - update Shop Order data
                        add_post_meta($post_id, 'cgateway_order_id', $cgateway_order_id );
                        add_post_meta($post_id, 'cgateway_order_status', $gatewayOrderStatus );
                        add_post_meta($post_id, 'cgateway_order_updated', $gatewayOrderUpdated );
                    }
                }
            }

            // re-hook this function
            add_action( 'save_post', array($this, 'cgateway_charge_on_save_order') );
        }
        */

        public function cgateway_change_from_onhold_to_processing($post_id, $order) {
            $this->cgateway_change_to_processing_or_completed($post_id, $order, 'on-hold');
        }

        public function cgateway_change_from_onhold_to_completed($post_id, $order) {
            $this->cgateway_change_to_processing_or_completed($post_id, $order, 'on-hold');
        }

        public function cgateway_change_from_processing_to_completed($post_id, $order) {
            $this->cgateway_change_to_processing_or_completed($post_id, $order, 'processing');
        }

        /**
         * When 2 stages: authorize-charge.
         * On status change to Processing or Completed do Charge.
         *
        */
        private function cgateway_change_to_processing_or_completed($post_id, $order, $previousStatus) {
            if ( 'shop_order' != get_post_type($post_id) ) {
                return;
            }

            if ( ! $order instanceof WC_Order ) {
                return;
            }
            
            $cgateway_order_id = get_post_meta( $post_id, 'cgateway_order_id', false );
            $cgateway_order_id = end( $cgateway_order_id );
            
            if ( !$cgateway_order_id ) {
                return;
            }

            $cgateway_order_status = get_post_meta( $post_id, 'cgateway_order_status', false );
            $cgateway_order_status = end( $cgateway_order_status );

            if ( $cgateway_order_status == 'charged' ) {
                return;
            }

            // - try to Charge
            $amount = number_format( $order->get_total(), 2 , ".", "");

            self::log($post_id . ': admin, Upd, Amount: ' . $amount);

            $orderArray['amount'] = $amount;

            if($this->electronic_receipt == 'yes'){
                $orderArray['extra_fields'] = $this->fillRecieptData($order);

            }
            $output = $this->gatewayClient->request(
                [
                    'url' => $this->apiurl . '/orders/' . $cgateway_order_id . '/charge',
                    'type' => 'PUT',
                    'get_headers' => false
                ],
                json_encode($orderArray )
            );

            // self::log( print_r($output, true) );

            $outputCode = (int)$output['code'];

            self::log($post_id . ': admin, Code: ' . $outputCode);

            $orderData = json_decode($output['body'], true);

            // If 200 then OK, else - change status back.
            if ( $outputCode == 200 ) {
                $gatewayOrderStatus = isset($orderData['orders'][0]['status']) ? $orderData['orders'][0]['status'] : "";
                $gatewayOrderUpdated = isset($orderData['orders'][0]['updated']) ? $orderData['orders'][0]['updated'] : "";

                if ( $gatewayOrderStatus == 'charged' ) {
                    // - update Shop Order data
                    add_post_meta($post_id, 'cgateway_order_id', $cgateway_order_id );
                    add_post_meta($post_id, 'cgateway_order_status', $gatewayOrderStatus );
                    add_post_meta($post_id, 'cgateway_order_updated', $gatewayOrderUpdated );
                    if($this->electronic_receipt){                    
                        $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);

                        if(!$gatewayReciept){
                            $orderData = $this->requestGatewayOrderData($cgateway_order_id);
                            $gatewayReciept = $this->gatewayClient->getGatewayReceipt($orderData);
                        }
                        update_post_meta($post_id, 'cgateway_receipt_status',  $gatewayReciept['status']);
                        update_post_meta($post_id, 'cgateway_receipt_created',  $gatewayReciept['created']);
                        update_post_meta($post_id, 'cgateway_receipt_operation',  $gatewayReciept['operation']);
                        $attributes = isset($gatewayReciept['attributes'])?json_encode($gatewayReciept['attributes']):"";          
                        update_post_meta($post_id, 'cgateway_receipt_attributes', $attributes  );
                    }
                }
            }
            else {
                $gatewayFailureMessage = isset($orderData['failure_message']) ? strip_tags($orderData['failure_message']) : "";
                $order->update_status( $previousStatus, "*****\r\nFailure. \r\n" . $gatewayFailureMessage . "\r\nOn action attempt: " );
            }
        }

        /**
         * Get Woo order status acording to gateway output code.
         *
         */
        /*
        private function convertGatewayCodeToWooStatus($gatewayOrderCode) {
            if ($gatewayOrderCode == 200 || $gatewayOrderCode == 201) {
                return 'processing';
            }
            elseif ($gatewayOrderCode == 402 || $gatewayOrderCode == 422) {
                return 'cancelled';
            }
            else {
                return 'failed';
            }
        }
        */

    
        /**
         * Show HTML answer after payment done within IFRAME
         * 
         */
        private function showIframeHtmlAnswer($shop_order_id) {
            if (!$shop_order_id) {
                return false;
            }

            echo '<html><head>
            <meta charset="UTF-8" />
            <title>Checkout : Iframe</title>
            <meta name="robots" content="noindex,nofollow" />
            <link rel="stylesheet" href="'. plugins_url() .'/woocommerce/assets/css/woocommerce-layout.css" type="text/css" media="all" />
            <link rel="stylesheet" href="'. plugins_url() .'/woocommerce/assets/css/woocommerce-smallscreen.css" type="text/css" media="all" />
            <link rel="stylesheet" href="'. plugins_url() .'/woocommerce/assets/css/woocommerce.css" type="text/css" media="all" />
            <style>body { font-family: Arial, "Helvetica Neue", Helvetica, sans-serif; }</style>
            </head><body class="page-template-default page woocommerce-checkout woocommerce-page woocommerce-order-pay checkout"><div class="woocommerce">';
            
            wc_get_template( 'order/order-details.php', array( 'order_id' => $shop_order_id ));
            
            echo '</div></body></html>';
        }


    }
}


add_action( 'woocommerce_product_options_general_product_data', 'cgateway_create_payment_object_field' );
add_action( 'woocommerce_process_product_meta', 'cgateway_save_payment_object_field');

/**
 * Display the payment object field in product properties
 * @since 1.0.0
 */
 function cgateway_create_payment_object_field() {
    $args = array(
        'id' => 'cgateway_payment_object_meta',
        'name' => 'cgateway_payment_object_meta',
        'label' => __( 'Payment object', 'woocommerce-cgateway' ),
        'class' => 'cgateway_payment_object_meta',
        'desc_tip' => true,
        'description' => __( 'Select proper payment object for product', 'woocommerce-cgateway' ),
        'options'     => array(
            'std' => 'Использовать глобальные настройки',
            'goods' => 'Товар',
            'excisable_goods' => 'Подакцизные товар',
            'work' => 'Работа',            
            "service" => 'Услуги',
            'gambling_bet' => 'Ставка азартной игры',
            'gambling_prize' => 'Выигрыш азартной игры',
            'lottery_ticket' => 'Лотерейный билет',
            'intellectual_property' => 'Предоставление результатов интеллектуальной деятельности',
            'payment' => 'Платеж',
            'agent_commission' => 'Агентское вознаграждение',
            'composite' => 'Составной предмет расчета',
            'other' => 'Другой предмет расчета',
        ),
    );

    woocommerce_wp_select( $args );
}

/**
 * Save the payment object field
 * @since 1.0.0
 */
 function cgateway_save_payment_object_field( $post_id ) {
    $product = wc_get_product( $post_id );
    $title = isset( $_POST['cgateway_payment_object_meta'] ) ? $_POST['cgateway_payment_object_meta'] : '';
    $product->update_meta_data( 'cgateway_payment_object_meta', sanitize_text_field( $title ) );
    $product->save();
}

