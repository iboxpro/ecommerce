<?php
/**
 * Gateway Settings Form Fields.
*/
if ( !defined('ABSPATH') ) {
    exit;
}


return array(
    'enabled' => array(
        'title'       => __( 'Enable/Disable', 'woocommerce' ),
        'type'        => 'checkbox',
        'label'       => __( 'Enable gateway', 'woocommerce-cgateway' ),
        'default'     => 'yes',
        'desc_tip'    => true
    ),
    'title' => array(
        'title'       => __( 'Title', 'woocommerce' ),
        'type'        => 'text',
        'description' => __( 'This controls the title which the user sees during checkout.', 'woocommerce' ),
        'default'     => __( 'Gateway Title', 'woocommerce-cgateway' ),
        'desc_tip'    => true
    ),
    'description' => array(
        'title'       => __( 'Description', 'woocommerce' ),
        'type'        => 'text',
        'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
        'default'     => __( 'Pay by credit / debit card.', 'woocommerce' ),
        'desc_tip'    => true
    ),

    'sandbox' => array(
        'title'       => __( 'Sandbox', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Enable sandbox (development) mode', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'desc_tip'    => false
    ),
    'debug' => array(
        'title'       => __( 'Debug', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Enable debug logging', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'desc_tip'    => false
    ),

    'verify_ssl' => array(
        'title'       => __( 'SSL Verification', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Verify host SSL', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'description' => __( 'Keep this turned off if selfsigned certificate is used on your API host.', 'woocommerce-cgateway' ),
        'desc_tip'    => true
    ),
    'api_url_live' => array(
        'title'       => __( 'Live API URI', 'woocommerce' ),
        'type'        => 'text',
        'description' => __( '', 'woocommerce' ),
        'default'     => '',
        'desc_tip'    => false
    ),
    'api_url_sandbox' => array(
        'title'       => __( 'Sandbox API URI', 'woocommerce' ),
        'type'        => 'text',
        'description' => __( '', 'woocommerce' ),
        'default'     => '',
        'desc_tip'    => false
    ),

    'use_cert' => array(
        'title'       => __( 'Use certificate', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Enable certificate usage', 'woocommerce-cgateway' ),
        'default'     => 'yes',
        'desc_tip'    => false
    ),
    'cert_file' => array(
        'title'       => __( 'Cert File Upload', 'woocommerce-cgateway' ),
        'type'        => 'file',
        'description' => __( 'Full path to Certificate File. You can move file out of public scope and manually change the Cert File Name value.', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),
    'cert_file_path' => array(
        'title'       => __( 'Cert File Name', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'Full path to certificate file. You can move file out of public scope and manually change this value.', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),
    'cert_pass' => array(
        'title'       => __( 'Cert Password', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'Certificate Password', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),
    'api_username' => array(
        'title'       => __( 'API Username', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'API Username', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),
    'api_pass' => array(
        'title'       => __( 'API Password', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'API Password', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),
    'terminal' => array(
        'title'       => __( 'Terminal ID', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'Terminal ID.', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),

    'gateway_lang' => array(
        'title'       => __( 'Gateway language', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Gateway language', 'woocommerce-cgateway' ),
        'default'     => '',
        'desc_tip'    => true,
        'options'     => array(
            '' => 'Default',
            'en' => 'English', 
            'ru' => 'Russian',
            'pl' => 'Polish'
        )
    ),

    'work_model' => array(
        'title'       => __( 'Work model', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Work model.', 'woocommerce-cgateway' ),
        'default'     => 0,
        'desc_tip'    => true,
        'options'     => array(
            0 => '&nbsp;',
            1 => 'Server to server',
            2 => 'Payment page'
        )
    ),

    'form_type' => array(
        'title'       => __( '- Form type', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Processing form type', 'woocommerce-cgateway' ),
        'default'     => 1,
        'desc_tip'    => true,
        'options'     => array(
            0 => 'Default', 
            1 => 'Standart',
            2 => 'Mobile',
            3 => 'Built-in',
            8 => 'Iframe',
            'Custom' => 'Custom'
        )
    ),

    'custom_form_id' => array(
        'title'       => __( '-- Custom form ID', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'Custom terminal form ID.', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),

    'require_card_holder' => array(
        'title'       => __( '- Require Card Holder', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'label'       => __( 'Show Card Holder field on checkout', 'woocommerce-cgateway' ),
        'description' => __( 'Card Holder is required on checkout.', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'desc_tip'    => true
    ),
    'auto_charge' => array(
        'title'       => __( 'Auto Charge', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'description' => __( 'Auto Charge', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'desc_tip'    => true
    ),
    'force3d' => array(
        'title'       => __( 'Force 3D', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'description' => __( 'Force 3D Secure', 'woocommerce-cgateway' ),
        'default'     => 'yes',
        'desc_tip'    => true
    ),
    'electronic_receipt' => array(
        'title'       => __( 'Send electronic reciept', 'woocommerce-cgateway' ),
        'type'        => 'checkbox',
        'description' => __( 'Send electronic reciept', 'woocommerce-cgateway' ),
        'default'     => 'no',
        'desc_tip'    => true
    ),
    
    'inn' => array(
        'title'       => __( '- Seller INN', 'woocommerce-cgateway' ),
        'type'        => 'text',
        'description' => __( 'Seller INN', 'woocommerce-cgateway' ),
        'default'     => "",
        'desc_tip'    => true
    ),

    'taxation_type' => array(
        'title'       => __( '- Система налогообложения', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Система налогообложения', 'woocommerce-cgateway' ),
        'default'     => 1,
        'desc_tip'    => true,
        'options'     => array(
            0 => 'Общая', 
            1 => 'Упрощенная (доходы)',
            2 => 'Упрощенная (доходы минус расходы)',
            3 => 'Единый налог на вмененный доход',
            4 => 'Единый сельскохозяйственный налог',
            5 => 'Патентная',
        )
    ),

//     'separate_tax' => array(
//         'title'       => __( 'Get Tax from each product', 'woocommerce-cgateway' ),
//         'type'        => 'checkbox',
//         'default'     => 'no',
//     ),

    'tax_type' => array(
        'title'       => __( '- Common Tax type', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Tax type if "Get Tax from each product" option unchecked', 'woocommerce-cgateway' ),
        'default'     => 1,
        'desc_tip'    => true,
        'options'     => array(
            'none' => 'None', 
            'vat' => 'VAT 0%',
            'vat20' => 'VAT 20%',
            'vat18' => 'VAT 18%',
            'vat10' => 'VAT 10%',
            'vat118' => 'VAT 18/118',
            'vat110' => 'VAT 10/110',
            'vat120' => 'VAT 10/120',
        )
    ),

    'payment_method' => array(
        'title'       => __( '- Common payment method', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Payment method', 'woocommerce-cgateway' ),
        'default'     => 1,
        'desc_tip'    => true,
        'options'     => array(
            'full_payment' => 'Полная оплата',
            'partial_payment' => 'Частичная оплата',
            'full_prepayment' => 'Полная предоплата',            
            "partial_prepayment" => 'Частичная предоплата',
            'advance_payment' => 'Аванс',
            'credit' => 'Передача в кредит',
            'credit_payment' => 'Оплата кредита',
        )
    ),

    'payment_object' => array(
        'title'       => __( '- Standart payment object ', 'woocommerce-cgateway' ),
        'type'        => 'select',
        'class'       => 'wc-enhanced-select',
        'description' => __( 'Payment object (could be overrided by setting same parameter for each article)', 'woocommerce-cgateway' ),
        'default'     => 1,
        'desc_tip'    => true,
        'options'     => array(
            'goods' => 'Товар',
            'excisable_goods' => 'Подакцизный товар',
            'work' => 'Работа',            
            "service" => 'Услуги',
            'gambling_bet' => 'Ставка азартной игры',
            'gambling_prize' => 'Выигрыш азартной игры',
            'lottery_ticket' => 'Лотерейный билет',
            'intellectual_property' => 'Предоставление результатов интеллектуальной деятельности',
            'payment' => 'Платеж',
            'agent_commission' => 'Агентское вознаграждение',
            'composite' => 'Составной предмет расчета',
            'other' => 'Другой предмет расчета',
        )
    ),
);